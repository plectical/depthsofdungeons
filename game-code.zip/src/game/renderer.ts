import { Tile, type GameState } from './types';
import { getTile, getTerrainAt } from './dungeon';
import { getNPCDef } from './npcs';
import { KEY_COLORS, MERCENARY_DEFS, TERRAIN_DEFS } from './constants';
import { getZoneDef, ZONE_TERRAIN_DEFS } from './zones';

// ── Richer tile characters (unicode for visual depth) ──
const TILE_CHARS: Record<Tile, string> = {
  [Tile.Wall]: '#',
  [Tile.Floor]: '·',
  [Tile.Corridor]: '·',
  [Tile.Door]: '▫',
  [Tile.StairsDown]: '▼',
  [Tile.StairsUp]: '▲',
  [Tile.Void]: ' ',
  [Tile.LockedDoor]: '▣',
  [Tile.BossGate]: '▩',
};

// ── Vivid foreground colors ──
const TILE_COLORS: Record<Tile, string> = {
  [Tile.Wall]: '#7a7a9e',
  [Tile.Floor]: '#4a4a5e',
  [Tile.Corridor]: '#555570',
  [Tile.Door]: '#d4a733',
  [Tile.StairsDown]: '#3eff7e',
  [Tile.StairsUp]: '#3edcdc',
  [Tile.Void]: '#000000',
  [Tile.LockedDoor]: '#ffd700',
  [Tile.BossGate]: '#ff3333',
};

// ── Subtle background tints per tile ──
const TILE_BG: Record<Tile, string> = {
  [Tile.Wall]: '#14142a',
  [Tile.Floor]: '#0a0a16',
  [Tile.Corridor]: '#0c0c1a',
  [Tile.Door]: '#1a1408',
  [Tile.StairsDown]: '#061a0c',
  [Tile.StairsUp]: '#061a1a',
  [Tile.Void]: '#000000',
  [Tile.LockedDoor]: '#1a1400',
  [Tile.BossGate]: '#1a0808',
};

const EXPLORED_DIM = 0.3;

export interface RenderCell {
  char: string;
  color: string;
  bg: string;
  glow?: string; // optional glow color for special tiles/entities
}

export function renderView(state: GameState, viewW: number, viewH: number): RenderCell[][] {
  const { player, monsters, items, floor, mercenaries, mapMercenaries } = state;
  const { visible, explored, width, height } = floor;

  const camX = Math.max(0, Math.min(player.pos.x - Math.floor(viewW / 2), width - viewW));
  const camY = Math.max(0, Math.min(player.pos.y - Math.floor(viewH / 2), height - viewH));

  const grid: RenderCell[][] = [];

  for (let vy = 0; vy < viewH; vy++) {
    const row: RenderCell[] = [];
    grid[vy] = row;
    for (let vx = 0; vx < viewW; vx++) {
      const mx = camX + vx;
      const my = camY + vy;

      if (mx < 0 || mx >= width || my < 0 || my >= height) {
        row[vx] = { char: ' ', color: '#000', bg: '#000' };
        continue;
      }

      const tile = getTile(floor, mx, my);
      const isVisible = visible[my]?.[mx] ?? false;
      const isExplored = explored[my]?.[mx] ?? false;

      if (!isVisible && !isExplored) {
        row[vx] = { char: ' ', color: '#000', bg: '#000' };
        continue;
      }

      // Zone palette overrides base tile colors
      const zoneDef = getZoneDef(state.zone);
      let char = TILE_CHARS[tile];
      let color = TILE_COLORS[tile];
      let bg = TILE_BG[tile];
      let glow: string | undefined;

      // Apply zone palette to walls and floors
      if (tile === Tile.Wall) {
        color = zoneDef.palette.wall;
        bg = zoneDef.palette.wallBg;
      } else if (tile === Tile.Floor || tile === Tile.Corridor) {
        color = zoneDef.palette.floor;
        bg = zoneDef.palette.floorBg;
      }

      // Terrain overlay — recolor walkable tiles that have terrain
      const allTerrainDefs = [...TERRAIN_DEFS, ...ZONE_TERRAIN_DEFS];
      const terrainType = getTerrainAt(floor, mx, my);
      if (terrainType && (tile === Tile.Floor || tile === Tile.Corridor)) {
        const tDef = allTerrainDefs.find((t) => t.type === terrainType);
        if (tDef) {
          color = tDef.color;
          bg = tDef.bg;
          if (tDef.glow) glow = tDef.glow;
          // Terrain-specific characters for extra visual distinction
          if (terrainType === 'water') char = '~';
          else if (terrainType === 'lava') char = '~';
          else if (terrainType === 'poison') char = '~';
          else if (terrainType === 'tall_grass') char = '"';
          else if (terrainType === 'ice') char = '·';
          else if (terrainType === 'mud') char = '·';
          else if (terrainType === 'holy') char = '✦';
          else if (terrainType === 'shadow') char = '·';
          else if (terrainType === 'frozen') char = '❄';
          else if (terrainType === 'spore') char = '○';
          else if (terrainType === 'brimstone') char = '▪';
          else if (terrainType === 'crystal') char = '◇';
          else if (terrainType === 'void_rift') char = '∞';
          else if (terrainType === 'mycelium') char = '≈';
        }
      }

      // Walls adopt the color of adjacent terrain tiles
      if (tile === Tile.Wall) {
        const adjTerrain = getAdjacentTerrain(floor, mx, my);
        if (adjTerrain) {
          const tDef = allTerrainDefs.find((t) => t.type === adjTerrain);
          if (tDef) {
            // Blend wall color with terrain — walls get a tinted version
            color = blendColor(zoneDef.palette.wall, tDef.color, 0.5);
            bg = blendColor(zoneDef.palette.wallBg, tDef.bg, 0.6);
          }
        }
      }

      // Locked doors show the key color
      if (tile === Tile.LockedDoor) {
        const vaultRoom = floor.rooms.find(r => r.isVault &&
          mx >= r.x - 1 && mx <= r.x + r.w && my >= r.y - 1 && my <= r.y + r.h);
        if (vaultRoom?.keyColor) {
          color = KEY_COLORS[vaultRoom.keyColor].color;
          glow = color;
        }
      }

      // Boss gate glows red
      if (tile === Tile.BossGate) {
        glow = '#ff3333';
      }

      if (isVisible) {
        // Shop keeper
        if (state.shop && mx === state.shop.pos.x && my === state.shop.pos.y) {
          char = '$';
          color = '#ffd700';
          glow = '#ffd700';
        }

        // NPCs
        const npc = state.npcs?.find((n) => !n.talked && n.pos.x === mx && n.pos.y === my);
        if (npc) {
          const npcDef = getNPCDef(npc.defId);
          if (npcDef) {
            char = npcDef.char;
            color = npcDef.color;
            glow = npcDef.color;
          }
        }

        // Map mercenaries (unhired)
        const mapMerc = mapMercenaries?.find((m) => !m.hired && m.pos.x === mx && m.pos.y === my);
        if (mapMerc) {
          const mercDef = MERCENARY_DEFS.find(d => d.id === mapMerc.defId);
          if (mercDef) {
            char = mercDef.char;
            color = mercDef.color;
            glow = '#88ccff';
          }
        }

        // Items on the ground
        const item = items.find((i) => i.pos.x === mx && i.pos.y === my);
        if (item) {
          char = item.item.char;
          color = item.item.color;
          glow = item.item.color;
        }

        // Monsters
        const monster = monsters.find((m) => !m.isDead && m.pos.x === mx && m.pos.y === my);
        if (monster) {
          char = monster.char;
          color = monster.color;
          if (monster.isBoss) {
            glow = '#ff3333';
            // Boss pulsing glow
          } else {
            const hpPct = monster.stats.hp / monster.stats.maxHp;
            if (hpPct < 0.4) glow = '#ff220033';
          }
          // Status effect visuals
          if (monster.statusEffects?.some(e => e.type === 'freeze')) {
            color = '#88ccff';
          } else if (monster.statusEffects?.some(e => e.type === 'poison')) {
            glow = '#33cc22';
          } else if (monster.statusEffects?.some(e => e.type === 'stun')) {
            color = '#ffff88';
          }
        }

        // Mercenaries (hired, in party)
        const merc = mercenaries?.find((m) => !m.isDead && m.pos.x === mx && m.pos.y === my);
        if (merc) {
          char = merc.char;
          color = merc.color;
          glow = '#88ccff';
        }

        // Stairs get a pulsing glow
        if (tile === Tile.StairsDown) {
          glow = '#3eff7e';
        } else if (tile === Tile.StairsUp) {
          glow = '#3edcdc';
        }

        // Player — bright white with a golden glow
        if (mx === player.pos.x && my === player.pos.y) {
          char = player.char;
          color = '#ffffff';
          glow = '#ffd700';
        }
      } else {
        // Explored but not visible — dim everything
        color = dimColor(color, EXPLORED_DIM);
        bg = dimColor(bg, EXPLORED_DIM);
      }

      row[vx] = { char, color, bg, glow };
    }
  }

  return grid;
}

export function viewToMap(state: GameState, viewW: number, viewH: number, vx: number, vy: number): { x: number; y: number } {
  const { player } = state;
  const { width, height } = state.floor;

  const camX = Math.max(0, Math.min(player.pos.x - Math.floor(viewW / 2), width - viewW));
  const camY = Math.max(0, Math.min(player.pos.y - Math.floor(viewH / 2), height - viewH));

  return { x: camX + vx, y: camY + vy };
}

function dimColor(hex: string, factor: number): string {
  if (hex.startsWith('rgb')) return hex;
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgb(${Math.floor(r * factor)},${Math.floor(g * factor)},${Math.floor(b * factor)})`;
}

// Find the dominant terrain type in the 4 cardinal + 4 diagonal neighbors
function getAdjacentTerrain(floor: GameState['floor'], x: number, y: number): string | undefined {
  const counts: Record<string, number> = {};
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      if (dx === 0 && dy === 0) continue;
      const t = getTerrainAt(floor, x + dx, y + dy);
      if (t) counts[t] = (counts[t] ?? 0) + 1;
    }
  }
  let best: string | undefined;
  let bestCount = 0;
  for (const [type, count] of Object.entries(counts)) {
    if (count > bestCount) {
      bestCount = count;
      best = type;
    }
  }
  return best;
}

function parseHex(hex: string): [number, number, number] {
  return [
    parseInt(hex.slice(1, 3), 16),
    parseInt(hex.slice(3, 5), 16),
    parseInt(hex.slice(5, 7), 16),
  ];
}

function blendColor(hexA: string, hexB: string, t: number): string {
  const [r1, g1, b1] = parseHex(hexA);
  const [r2, g2, b2] = parseHex(hexB);
  const r = Math.floor(r1 + (r2 - r1) * t);
  const g = Math.floor(g1 + (g2 - g1) * t);
  const b = Math.floor(b1 + (b2 - b1) * t);
  return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
}
