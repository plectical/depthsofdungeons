import type { MonsterDef, Item, ClassDef, MercenaryDef, KeyColor, TerrainDef } from './types';

// ── Map dimensions ──
export const MAP_WIDTH = 60;
export const MAP_HEIGHT = 40;

// ── Room generation ──
export const MIN_ROOM_SIZE = 4;
export const MAX_ROOM_SIZE = 10;
export const MAX_ROOMS = 12;

// ── Visibility ──
export const VIEW_RADIUS = 7;

// ── Player starting stats ──
export const PLAYER_BASE_STATS = {
  hp: 30,
  maxHp: 30,
  attack: 5,
  defense: 2,
  speed: 10,
};

// ── Hunger ──
export const HUNGER_MAX = 100;
export const HUNGER_PER_TURN = 0.5;
export const HUNGER_WARNING = 25;
export const STARVING_THRESHOLD = 0;
export const STARVING_DAMAGE = 1;

// ── HP Regen ──
export const REGEN_INTERVAL = 8;
export const REGEN_AMOUNT = 1;
export const REGEN_HUNGER_MIN = 50;

// ── XP per level (cumulative) ──
export const XP_PER_LEVEL = [0, 20, 50, 100, 180, 300, 480, 720, 1050, 1500];

// ── Monster definitions ──
export const MONSTER_DEFS: MonsterDef[] = [
  // ── Floor 1: Early game - simple monsters ──
  { name: 'Rat', char: 'r', color: '#c8875a', stats: { hp: 5, maxHp: 5, attack: 2, defense: 0, speed: 8 }, xpValue: 5, minFloor: 1, lootChance: 0.1,
    abilities: [{ type: 'callForHelp', monsterName: 'Rat', chance: 0.15, cooldown: 8 }] },
  { name: 'Bat', char: 'b', color: '#b06840', stats: { hp: 4, maxHp: 4, attack: 3, defense: 0, speed: 12 }, xpValue: 6, minFloor: 1, lootChance: 0.05,
    abilities: [{ type: 'dodge', chance: 0.2 }] },

  // ── Floor 2-3: Early threats ──
  { name: 'Kobold', char: 'k', color: '#ff7b5e', stats: { hp: 8, maxHp: 8, attack: 4, defense: 1, speed: 7 }, xpValue: 10, minFloor: 2, lootChance: 0.2,
    abilities: [{ type: 'callForHelp', monsterName: 'Kobold', chance: 0.2, cooldown: 6 }] },
  { name: 'Giant Spider', char: 's', color: '#88aa44', stats: { hp: 10, maxHp: 10, attack: 6, defense: 1, speed: 10 }, xpValue: 14, minFloor: 3, lootChance: 0.15,
    abilities: [{ type: 'poisonAttack', damage: 1, turns: 3, chance: 0.3 }] },
  { name: 'Goblin', char: 'g', color: '#50ff50', stats: { hp: 12, maxHp: 12, attack: 5, defense: 2, speed: 6 }, xpValue: 15, minFloor: 3, lootChance: 0.25,
    abilities: [{ type: 'enrage', hpThreshold: 0.3, atkMultiplier: 1.5 }] },

  // ── Floor 4: Mid-early ──
  { name: 'Skeleton', char: 'S', color: '#e8e8ff', stats: { hp: 15, maxHp: 15, attack: 7, defense: 3, speed: 5 }, xpValue: 20, minFloor: 4, lootChance: 0.3,
    abilities: [{ type: 'bleedAttack', damage: 1, turns: 3, chance: 0.2 }] },
  { name: 'Mimic', char: '?', color: '#ffdd44', stats: { hp: 22, maxHp: 22, attack: 11, defense: 6, speed: 1 }, xpValue: 35, minFloor: 4, lootChance: 0.8,
    abilities: [{ type: 'chargeAttack', multiplier: 2.0, chance: 0.25 }, { type: 'stunAttack', chance: 0.15 }] },
  { name: 'Cave Scorpion', char: 'x', color: '#cc8833', stats: { hp: 14, maxHp: 14, attack: 8, defense: 2, speed: 9 }, xpValue: 18, minFloor: 3, lootChance: 0.2,
    abilities: [{ type: 'poisonAttack', damage: 2, turns: 4, chance: 0.35 }] },

  // ── Floor 5: Mid game ──
  { name: 'Orc', char: 'o', color: '#7daa3e', stats: { hp: 20, maxHp: 20, attack: 8, defense: 4, speed: 5 }, xpValue: 30, minFloor: 5, lootChance: 0.35,
    abilities: [{ type: 'chargeAttack', multiplier: 1.8, chance: 0.2 }, { type: 'enrage', hpThreshold: 0.25, atkMultiplier: 1.6 }] },
  { name: 'Zombie', char: 'Z', color: '#a0cc44', stats: { hp: 25, maxHp: 25, attack: 6, defense: 5, speed: 3 }, xpValue: 25, minFloor: 5, lootChance: 0.2,
    abilities: [{ type: 'selfHeal', amount: 4, hpThreshold: 0.5, cooldown: 4 }] },
  { name: 'Dark Elf', char: 'e', color: '#9966cc', stats: { hp: 16, maxHp: 16, attack: 9, defense: 3, speed: 10 }, xpValue: 30, minFloor: 5, lootChance: 0.35,
    abilities: [{ type: 'dodge', chance: 0.25 }, { type: 'bleedAttack', damage: 2, turns: 3, chance: 0.2 }] },
  { name: 'War Hound', char: 'h', color: '#bb6644', stats: { hp: 18, maxHp: 18, attack: 9, defense: 2, speed: 13 }, xpValue: 28, minFloor: 4, lootChance: 0.2,
    abilities: [{ type: 'chargeAttack', multiplier: 1.5, chance: 0.3 }] },

  // ── Floor 6: Mid-late ──
  { name: 'Basilisk', char: 'B', color: '#66cc44', stats: { hp: 30, maxHp: 30, attack: 14, defense: 5, speed: 6 }, xpValue: 45, minFloor: 6, lootChance: 0.35,
    abilities: [{ type: 'stunAttack', chance: 0.25 }, { type: 'poisonAttack', damage: 2, turns: 3, chance: 0.2 }] },
  { name: 'Bone Knight', char: 'K', color: '#ddddff', stats: { hp: 28, maxHp: 28, attack: 11, defense: 8, speed: 5 }, xpValue: 40, minFloor: 6, lootChance: 0.35,
    abilities: [{ type: 'bleedAttack', damage: 2, turns: 4, chance: 0.25 }, { type: 'enrage', hpThreshold: 0.3, atkMultiplier: 1.4 }] },

  // ── Floor 7: Late ──
  { name: 'Wraith', char: 'W', color: '#c49eff', stats: { hp: 18, maxHp: 18, attack: 10, defense: 3, speed: 9 }, xpValue: 40, minFloor: 7, lootChance: 0.4,
    abilities: [{ type: 'drainLife', percent: 20, chance: 0.25 }, { type: 'dodge', chance: 0.2 }] },
  { name: 'Golem', char: 'O', color: '#aa8866', stats: { hp: 50, maxHp: 50, attack: 10, defense: 12, speed: 2 }, xpValue: 55, minFloor: 7, lootChance: 0.4,
    abilities: [{ type: 'chargeAttack', multiplier: 2.0, chance: 0.15 }, { type: 'selfHeal', amount: 8, hpThreshold: 0.4, cooldown: 6 }] },
  { name: 'Plague Bearer', char: 'P', color: '#88cc22', stats: { hp: 24, maxHp: 24, attack: 8, defense: 4, speed: 6 }, xpValue: 38, minFloor: 6, lootChance: 0.35,
    abilities: [{ type: 'poisonAttack', damage: 3, turns: 5, chance: 0.4 }] },

  // ── Floor 8: Late game ──
  { name: 'Troll', char: 'T', color: '#40c880', stats: { hp: 40, maxHp: 40, attack: 12, defense: 6, speed: 4 }, xpValue: 60, minFloor: 8, lootChance: 0.45,
    abilities: [{ type: 'selfHeal', amount: 6, hpThreshold: 0.6, cooldown: 3 }, { type: 'enrage', hpThreshold: 0.25, atkMultiplier: 1.8 }] },
  { name: 'Vampire', char: 'V', color: '#cc2244', stats: { hp: 28, maxHp: 28, attack: 12, defense: 4, speed: 11 }, xpValue: 50, minFloor: 8, lootChance: 0.45,
    abilities: [{ type: 'drainLife', percent: 25, chance: 0.3 }, { type: 'dodge', chance: 0.15 }] },
  { name: 'Manticore', char: 'M', color: '#dd7744', stats: { hp: 35, maxHp: 35, attack: 14, defense: 5, speed: 10 }, xpValue: 55, minFloor: 8, lootChance: 0.4,
    abilities: [{ type: 'poisonAttack', damage: 2, turns: 3, chance: 0.3 }, { type: 'chargeAttack', multiplier: 1.6, chance: 0.2 }] },

  // ── Floor 9-10: End game ──
  { name: 'Demon', char: 'D', color: '#ff3300', stats: { hp: 45, maxHp: 45, attack: 16, defense: 7, speed: 8 }, xpValue: 75, minFloor: 9, lootChance: 0.5,
    abilities: [{ type: 'chargeAttack', multiplier: 1.8, chance: 0.2 }, { type: 'enrage', hpThreshold: 0.3, atkMultiplier: 1.7 }, { type: 'stunAttack', chance: 0.1 }] },
  { name: 'Dragon', char: 'D', color: '#ff5522', stats: { hp: 60, maxHp: 60, attack: 18, defense: 10, speed: 7 }, xpValue: 100, minFloor: 10, lootChance: 0.6,
    abilities: [{ type: 'chargeAttack', multiplier: 2.0, chance: 0.2 }, { type: 'freezeAttack', chance: 0.15, turns: 2 }, { type: 'enrage', hpThreshold: 0.2, atkMultiplier: 2.0 }] },
  { name: 'Death Knight', char: 'N', color: '#4444aa', stats: { hp: 50, maxHp: 50, attack: 15, defense: 9, speed: 6 }, xpValue: 80, minFloor: 10, lootChance: 0.5,
    abilities: [{ type: 'drainLife', percent: 20, chance: 0.3 }, { type: 'bleedAttack', damage: 3, turns: 4, chance: 0.25 }, { type: 'selfHeal', amount: 10, hpThreshold: 0.3, cooldown: 8 }] },

  // ── Environmental attack monsters ──
  { name: 'Fire Elemental', char: 'F', color: '#ff6611', stats: { hp: 28, maxHp: 28, attack: 11, defense: 4, speed: 8 }, xpValue: 40, minFloor: 5, lootChance: 0.35, terrainOnHit: { terrain: 'lava', radius: 2, chance: 0.5 },
    abilities: [{ type: 'enrage', hpThreshold: 0.25, atkMultiplier: 1.5 }] },
  { name: 'Storm Wisp', char: 'w', color: '#44ddff', stats: { hp: 14, maxHp: 14, attack: 9, defense: 2, speed: 14 }, xpValue: 30, minFloor: 4, lootChance: 0.25, terrainOnHit: { terrain: 'water', radius: 2, chance: 0.45 },
    abilities: [{ type: 'stunAttack', chance: 0.2 }, { type: 'dodge', chance: 0.2 }] },
  { name: 'Poison Spitter', char: 'p', color: '#33cc11', stats: { hp: 18, maxHp: 18, attack: 7, defense: 3, speed: 7 }, xpValue: 25, minFloor: 3, lootChance: 0.3, terrainOnHit: { terrain: 'poison', radius: 2, chance: 0.5 },
    abilities: [{ type: 'poisonAttack', damage: 2, turns: 4, chance: 0.35 }] },
  { name: 'Frost Wraith', char: 'f', color: '#aaeeff', stats: { hp: 22, maxHp: 22, attack: 10, defense: 3, speed: 10 }, xpValue: 35, minFloor: 5, lootChance: 0.3, terrainOnHit: { terrain: 'ice', radius: 2, chance: 0.45 },
    abilities: [{ type: 'freezeAttack', chance: 0.25, turns: 2 }] },
  { name: 'Shadow Stalker', char: 'h', color: '#7744aa', stats: { hp: 20, maxHp: 20, attack: 13, defense: 2, speed: 12 }, xpValue: 40, minFloor: 6, lootChance: 0.35, terrainOnHit: { terrain: 'shadow', radius: 2, chance: 0.4 },
    abilities: [{ type: 'dodge', chance: 0.3 }, { type: 'chargeAttack', multiplier: 1.8, chance: 0.15 }] },
  { name: 'Mud Crawler', char: 'c', color: '#aa7733', stats: { hp: 35, maxHp: 35, attack: 8, defense: 8, speed: 3 }, xpValue: 30, minFloor: 4, lootChance: 0.25, terrainOnHit: { terrain: 'mud', radius: 2, chance: 0.55 },
    abilities: [{ type: 'selfHeal', amount: 5, hpThreshold: 0.5, cooldown: 5 }] },
];

// ── Boss definitions ──
export const BOSS_DEFS: MonsterDef[] = [
  { name: 'Goblin King', char: 'K', color: '#44ff44', stats: { hp: 60, maxHp: 60, attack: 10, defense: 5, speed: 6 }, xpValue: 100, minFloor: 3, lootChance: 1.0, isBoss: true, bossAbility: { type: 'summon', monsterName: 'Goblin', count: 2, cooldown: 5 }, guaranteedLoot: 'Crown of the Goblin King' },
  { name: 'Stone Guardian', char: 'G', color: '#bbaa88', stats: { hp: 100, maxHp: 100, attack: 12, defense: 14, speed: 3 }, xpValue: 180, minFloor: 5, lootChance: 1.0, isBoss: true, bossAbility: { type: 'aoe', damage: 8, radius: 2, cooldown: 4 }, guaranteedLoot: 'Guardian Core' },
  { name: 'Vampire Lord', char: 'V', color: '#ff1133', stats: { hp: 80, maxHp: 80, attack: 18, defense: 6, speed: 12 }, xpValue: 250, minFloor: 7, lootChance: 1.0, isBoss: true, bossAbility: { type: 'multi', abilities: [{ type: 'heal', amount: 15, cooldown: 6 }, { type: 'teleport', cooldown: 4 }] }, guaranteedLoot: 'Crimson Fang' },
  { name: 'Abyssal Worm', char: 'W', color: '#6633aa', stats: { hp: 150, maxHp: 150, attack: 22, defense: 10, speed: 5 }, xpValue: 400, minFloor: 9, lootChance: 1.0, isBoss: true, bossAbility: { type: 'multi', abilities: [{ type: 'rage', hpThreshold: 0.3, atkMultiplier: 2.0 }, { type: 'aoe', damage: 12, radius: 3, cooldown: 5 }] }, guaranteedLoot: 'Abyssal Eye' },
  { name: 'Lich Emperor', char: 'L', color: '#cc00ff', stats: { hp: 200, maxHp: 200, attack: 28, defense: 12, speed: 8 }, xpValue: 600, minFloor: 12, lootChance: 1.0, isBoss: true, bossAbility: { type: 'multi', abilities: [{ type: 'summon', monsterName: 'Skeleton', count: 3, cooldown: 6 }, { type: 'heal', amount: 25, cooldown: 8 }, { type: 'teleport', cooldown: 5 }] }, guaranteedLoot: 'Crown of the Lich' },
];

// ── Item templates ──
export const WEAPON_TEMPLATES: Omit<Item, 'id'>[] = [
  { name: 'Rusty Dagger', type: 'weapon', char: ')', color: '#d4975a', value: 5, equipSlot: 'weapon', statBonus: { attack: 2 }, description: 'A worn dagger' },
  { name: 'Short Sword', type: 'weapon', char: ')', color: '#d0d0e8', value: 15, equipSlot: 'weapon', statBonus: { attack: 4 }, description: 'A short blade' },
  { name: 'Long Sword', type: 'weapon', char: ')', color: '#ffe44d', value: 30, equipSlot: 'weapon', statBonus: { attack: 7 }, description: 'A fine sword' },
  { name: 'War Axe', type: 'weapon', char: ')', color: '#e83838', value: 50, equipSlot: 'weapon', statBonus: { attack: 10 }, description: 'A heavy axe' },
  { name: 'Magic Blade', type: 'weapon', char: ')', color: '#44ffff', value: 80, equipSlot: 'weapon', statBonus: { attack: 14 }, description: 'Glows faintly' },
  // New weapons with effects
  { name: 'Poisoned Stiletto', type: 'weapon', char: ')', color: '#55cc22', value: 20, equipSlot: 'weapon', statBonus: { attack: 3, speed: 2 }, description: 'Coated in venom', onHitEffect: { type: 'poison', damage: 2, turns: 3 } },
  { name: 'Flaming Mace', type: 'weapon', char: ')', color: '#ff8833', value: 45, equipSlot: 'weapon', statBonus: { attack: 8 }, description: 'Burns on impact', onHitEffect: { type: 'fireball', damage: 5, chance: 0.25 } },
  { name: 'Frost Hammer', type: 'weapon', char: ')', color: '#88ccff', value: 55, equipSlot: 'weapon', statBonus: { attack: 9, defense: 1 }, description: 'Chills to the bone', onHitEffect: { type: 'freeze', chance: 0.2, turns: 2 } },
  { name: 'Vampire Fang Blade', type: 'weapon', char: ')', color: '#cc1144', value: 65, equipSlot: 'weapon', statBonus: { attack: 11 }, description: 'Drains life on hit', onHitEffect: { type: 'lifesteal', percent: 15 } },
  { name: 'Executioner Greataxe', type: 'weapon', char: ')', color: '#aa2222', value: 75, equipSlot: 'weapon', statBonus: { attack: 13 }, description: 'Cleaves the weak', onHitEffect: { type: 'execute', hpThreshold: 0.2, chance: 0.3 } },
  { name: 'Thunderbrand', type: 'weapon', char: ')', color: '#ffff33', value: 90, equipSlot: 'weapon', statBonus: { attack: 15, speed: 2 }, description: 'Crackles with lightning', onHitEffect: { type: 'stun', chance: 0.15 } },
  { name: 'Abyssal Cleaver', type: 'weapon', char: ')', color: '#8844cc', value: 110, equipSlot: 'weapon', statBonus: { attack: 18 }, description: 'Forged in the abyss', onHitEffect: { type: 'bleed', damage: 3, turns: 4 } },
];

// Boss drop weapons (found via boss guaranteed loot, not random drops)
export const BOSS_LOOT_TEMPLATES: Omit<Item, 'id'>[] = [
  { name: 'Crown of the Goblin King', type: 'armor', char: '[', color: '#44ff44', value: 40, equipSlot: 'armor', statBonus: { defense: 5, attack: 2 }, description: 'Inspires fear in goblins' },
  { name: 'Guardian Core', type: 'armor', char: '[', color: '#bbaa88', value: 85, equipSlot: 'armor', statBonus: { defense: 12, maxHp: 15 }, description: 'A living stone shield' },
  { name: 'Crimson Fang', type: 'weapon', char: ')', color: '#ff1133', value: 100, equipSlot: 'weapon', statBonus: { attack: 16, speed: 3 }, description: 'Taken from the Vampire Lord', onHitEffect: { type: 'lifesteal', percent: 20 } },
  { name: 'Abyssal Eye', type: 'amulet', char: '"', color: '#6633aa', value: 150, equipSlot: 'amulet', statBonus: { attack: 6, defense: 6, speed: 3 }, description: 'Sees into the void' },
  { name: 'Crown of the Lich', type: 'amulet', char: '"', color: '#cc00ff', value: 200, equipSlot: 'amulet', statBonus: { attack: 8, defense: 4, maxHp: 20 }, description: 'Absolute dark power' },
];

export const ARMOR_TEMPLATES: Omit<Item, 'id'>[] = [
  { name: 'Leather Armor', type: 'armor', char: '[', color: '#b86b30', value: 10, equipSlot: 'armor', statBonus: { defense: 2 }, description: 'Basic protection' },
  { name: 'Chain Mail', type: 'armor', char: '[', color: '#b8b8d0', value: 25, equipSlot: 'armor', statBonus: { defense: 4 }, description: 'Linked rings of metal' },
  { name: 'Plate Armor', type: 'armor', char: '[', color: '#dcdcf0', value: 50, equipSlot: 'armor', statBonus: { defense: 7 }, description: 'Heavy but sturdy' },
  { name: 'Dragon Scale', type: 'armor', char: '[', color: '#ff6830', value: 90, equipSlot: 'armor', statBonus: { defense: 11 }, description: 'Forged from scales' },
  // New armor with effects
  { name: 'Thorn Mail', type: 'armor', char: '[', color: '#44aa44', value: 35, equipSlot: 'armor', statBonus: { defense: 4 }, description: 'Hurts attackers', onDefendEffect: { type: 'thorns', damage: 3 } },
  { name: 'Frost Plate', type: 'armor', char: '[', color: '#aaddff', value: 60, equipSlot: 'armor', statBonus: { defense: 8 }, description: 'Freezes attackers', onDefendEffect: { type: 'freeze', chance: 0.15, turns: 1 } },
  { name: 'Infernal Aegis', type: 'armor', char: '[', color: '#ff4400', value: 80, equipSlot: 'armor', statBonus: { defense: 10, maxHp: 10 }, description: 'Burns with hellfire', onDefendEffect: { type: 'fireball', damage: 4, chance: 0.2 } },
  { name: 'Abyssal Shell', type: 'armor', char: '[', color: '#6633aa', value: 120, equipSlot: 'armor', statBonus: { defense: 14 }, description: 'Near impervious', onDefendEffect: { type: 'thorns', damage: 5 } },
];

export const RING_TEMPLATES: Omit<Item, 'id'>[] = [
  { name: 'Ring of Strength', type: 'ring', char: '=', color: '#ff8866', value: 20, equipSlot: 'ring', statBonus: { attack: 3 }, description: 'Boosts power' },
  { name: 'Ring of Protection', type: 'ring', char: '=', color: '#66aadd', value: 20, equipSlot: 'ring', statBonus: { defense: 3 }, description: 'Boosts defense' },
  { name: 'Ring of Vitality', type: 'ring', char: '=', color: '#55ee88', value: 20, equipSlot: 'ring', statBonus: { maxHp: 10 }, description: 'Boosts health' },
  { name: 'Ring of Haste', type: 'ring', char: '=', color: '#88eeff', value: 25, equipSlot: 'ring', statBonus: { speed: 3 }, description: 'Move faster' },
  { name: 'Ring of Thorns', type: 'ring', char: '=', color: '#44cc44', value: 30, equipSlot: 'ring', statBonus: { defense: 1 }, description: 'Return 2 damage to attackers', onDefendEffect: { type: 'thorns', damage: 2 } },
  { name: 'Ring of Bloodlust', type: 'ring', char: '=', color: '#cc2244', value: 35, equipSlot: 'ring', statBonus: { attack: 2 }, description: 'Heal on every hit', onHitEffect: { type: 'lifesteal', percent: 10 } },
  { name: 'Ring of the Glacier', type: 'ring', char: '=', color: '#aaccff', value: 40, equipSlot: 'ring', statBonus: { defense: 2, speed: 1 }, description: 'Chance to freeze attackers', onDefendEffect: { type: 'freeze', chance: 0.1, turns: 1 } },
];

export const AMULET_TEMPLATES: Omit<Item, 'id'>[] = [
  { name: 'Amulet of Regen', type: 'amulet', char: '"', color: '#66ffaa', value: 30, equipSlot: 'amulet', statBonus: { hp: 1 }, description: 'Heals over time' },
  { name: 'Amulet of Might', type: 'amulet', char: '"', color: '#ff6644', value: 30, equipSlot: 'amulet', statBonus: { attack: 2, defense: 2 }, description: 'Power and protection' },
  { name: 'Amulet of Venom', type: 'amulet', char: '"', color: '#55cc22', value: 35, equipSlot: 'amulet', statBonus: { attack: 1 }, description: 'Poisons on hit', onHitEffect: { type: 'poison', damage: 2, turns: 3 } },
  { name: 'Amulet of the Inferno', type: 'amulet', char: '"', color: '#ff6600', value: 45, equipSlot: 'amulet', statBonus: { attack: 3 }, description: 'Chance to fireball', onHitEffect: { type: 'fireball', damage: 6, chance: 0.15 } },
];

export const POTION_TEMPLATES: Omit<Item, 'id'>[] = [
  { name: 'Health Potion', type: 'potion', char: '!', color: '#ff3344', value: 10, description: 'Restores 15 HP' },
  { name: 'Greater Health Potion', type: 'potion', char: '!', color: '#ff77bb', value: 25, description: 'Restores 30 HP' },
  { name: 'Strength Potion', type: 'potion', char: '!', color: '#ffbb33', value: 20, description: '+2 attack for 20 turns' },
  { name: 'Iron Skin Potion', type: 'potion', char: '!', color: '#aabbcc', value: 20, description: '+3 defense for 20 turns' },
  { name: 'Speed Elixir', type: 'potion', char: '!', color: '#88eeff', value: 20, description: '+4 speed for 15 turns' },
  { name: 'Potion of Rage', type: 'potion', char: '!', color: '#ff2200', value: 30, description: '+5 attack for 10 turns' },
  { name: 'Full Heal Potion', type: 'potion', char: '!', color: '#ff55ff', value: 50, description: 'Fully restores HP' },
  { name: 'Antidote', type: 'potion', char: '!', color: '#33cc66', value: 10, description: 'Cures poison and bleed' },
];

export const SCROLL_TEMPLATES: Omit<Item, 'id'>[] = [
  { name: 'Scroll of Mapping', type: 'scroll', char: '?', color: '#f5e8c8', value: 15, description: 'Reveals the floor' },
  { name: 'Scroll of Teleport', type: 'scroll', char: '?', color: '#e088e8', value: 20, description: 'Teleport randomly' },
  { name: 'Scroll of Fireball', type: 'scroll', char: '?', color: '#ff5500', value: 25, description: 'Deals 20 fire damage to nearby enemies' },
  { name: 'Scroll of Ice Storm', type: 'scroll', char: '?', color: '#88ccff', value: 25, description: 'Freezes all nearby enemies for 3 turns' },
  { name: 'Scroll of Summon', type: 'scroll', char: '?', color: '#cc44ff', value: 35, description: 'Summons a temporary ally' },
  { name: 'Scroll of Enchant', type: 'scroll', char: '?', color: '#ffdd44', value: 40, description: 'Permanently adds +2 attack to your weapon' },
];

export const FOOD_TEMPLATES: Omit<Item, 'id'>[] = [
  { name: 'Bread', type: 'food', char: '%', color: '#e8c888', value: 25, description: 'Fills you up a bit' },
  { name: 'Meat', type: 'food', char: '%', color: '#e07070', value: 40, description: 'A hearty meal' },
  { name: 'Fruit', type: 'food', char: '%', color: '#66dd66', value: 20, description: 'A fresh snack' },
  { name: 'Feast', type: 'food', char: '%', color: '#ffcc44', value: 60, description: 'A full belly!' },
  { name: 'Mushroom Stew', type: 'food', char: '%', color: '#bb8855', value: 35, description: 'Warm and filling' },
  { name: 'Dragon Jerky', type: 'food', char: '%', color: '#dd5533', value: 50, description: 'Spicy but delicious' },
];

// ── Key config ──
export const KEY_COLORS: Record<KeyColor, { name: string; char: string; color: string; minFloor: number; shopPrice: number }> = {
  iron:    { name: 'Iron Key',    char: 'k', color: '#bbbbbb', minFloor: 2, shopPrice: 25 },
  gold:    { name: 'Gold Key',    char: 'k', color: '#ffd700', minFloor: 4, shopPrice: 50 },
  crystal: { name: 'Crystal Key', char: 'k', color: '#88ddff', minFloor: 6, shopPrice: 80 },
  blood:   { name: 'Blood Key',   char: 'k', color: '#ff3344', minFloor: 8, shopPrice: 120 },
  void:    { name: 'Void Key',    char: 'k', color: '#aa44ff', minFloor: 10, shopPrice: 175 },
};

// ── Vault-exclusive treasures (only found behind locked doors) ──
export const VAULT_TREASURE_TEMPLATES: Omit<Item, 'id'>[] = [
  // Vault-exclusive scrolls
  { name: 'Scroll of Greater Enchant', type: 'scroll', char: '?', color: '#ffaa00', value: 80, description: 'Permanently adds +4 attack to your weapon' },
  { name: 'Scroll of Invulnerability', type: 'scroll', char: '?', color: '#ffffff', value: 100, description: 'Become immune to damage for 10 turns' },
  // Vault-exclusive rings
  { name: 'Ring of the Vault', type: 'ring', char: '=', color: '#ffcc66', value: 60, equipSlot: 'ring', statBonus: { attack: 4, defense: 4 }, description: 'Power sealed away in vaults' },
  { name: 'Ring of Fortune', type: 'ring', char: '=', color: '#ffd700', value: 55, equipSlot: 'ring', statBonus: { speed: 2 }, description: 'Monsters drop more gold near you' },
  // Vault-exclusive amulets
  { name: 'Amulet of the Ancients', type: 'amulet', char: '"', color: '#cc88ff', value: 70, equipSlot: 'amulet', statBonus: { attack: 4, defense: 3, maxHp: 10 }, description: 'Lost relic of a forgotten age' },
  { name: 'Soulstone Pendant', type: 'amulet', char: '"', color: '#ff44aa', value: 85, equipSlot: 'amulet', statBonus: { attack: 3, maxHp: 15 }, description: 'Pulses with trapped souls', onHitEffect: { type: 'lifesteal', percent: 12 } },
  // Vault-exclusive weapons
  { name: 'Runeforged Blade', type: 'weapon', char: ')', color: '#44ffcc', value: 95, equipSlot: 'weapon', statBonus: { attack: 16, speed: 3 }, description: 'Etched with ancient runes', onHitEffect: { type: 'stun', chance: 0.2 } },
  { name: 'Shadow Reaper', type: 'weapon', char: ')', color: '#6644aa', value: 105, equipSlot: 'weapon', statBonus: { attack: 18 }, description: 'Cuts through reality itself', onHitEffect: { type: 'bleed', damage: 4, turns: 5 } },
  // Vault-exclusive armor
  { name: 'Prismatic Plate', type: 'armor', char: '[', color: '#ff88ff', value: 100, equipSlot: 'armor', statBonus: { defense: 13, maxHp: 15 }, description: 'Shimmers with every color', onDefendEffect: { type: 'freeze', chance: 0.2, turns: 2 } },
  // Vault gold piles
  { name: 'Treasure Hoard', type: 'gold', char: '*', color: '#ffee44', value: 150, description: 'A massive pile of gold coins' },
  { name: 'Gem-Encrusted Chest', type: 'gold', char: '*', color: '#ff66cc', value: 200, description: 'Overflowing with precious gems' },
];

// ── Mercenary definitions ──
export const MERCENARY_DEFS: MercenaryDef[] = [
  { id: 'merc_shield_bearer', name: 'Garrak', title: 'Shield Bearer', char: 'M', color: '#88aacc', hireCost: 30, stats: { hp: 25, maxHp: 25, attack: 4, defense: 8, speed: 5 }, minFloor: 2, description: 'A sturdy defender who draws enemy attacks.', specialAbility: 'Taunt: enemies prefer attacking Garrak' },
  { id: 'merc_blade_dancer', name: 'Lyra', title: 'Blade Dancer', char: 'M', color: '#ffcc44', hireCost: 50, stats: { hp: 18, maxHp: 18, attack: 10, defense: 2, speed: 13 }, minFloor: 4, description: 'A fast fighter who strikes twice.', specialAbility: 'Double Strike: attacks twice per turn' },
  { id: 'merc_healer', name: 'Sera', title: 'War Priestess', char: 'M', color: '#55ff88', hireCost: 60, stats: { hp: 20, maxHp: 20, attack: 5, defense: 3, speed: 7 }, minFloor: 3, description: 'Heals you each turn.', specialAbility: 'Blessing: heals you 2 HP per turn' },
  { id: 'merc_berserker', name: 'Krug', title: 'Berserker', char: 'M', color: '#ff4422', hireCost: 70, stats: { hp: 30, maxHp: 30, attack: 14, defense: 1, speed: 8 }, minFloor: 5, description: 'Hits incredibly hard but takes extra damage.', specialAbility: 'Frenzy: deals double damage when below 50% HP' },
  { id: 'merc_assassin', name: 'Shade', title: 'Shadow Assassin', char: 'M', color: '#8866aa', hireCost: 80, stats: { hp: 15, maxHp: 15, attack: 12, defense: 2, speed: 15 }, minFloor: 6, description: 'Strikes from shadows with lethal precision.', specialAbility: 'Assassinate: 15% chance to instantly kill non-boss enemies' },
  { id: 'merc_golem', name: 'Atlas', title: 'War Golem', char: 'M', color: '#bbaa77', hireCost: 100, stats: { hp: 60, maxHp: 60, attack: 8, defense: 12, speed: 3 }, minFloor: 8, description: 'An ancient construct. Nearly indestructible.', specialAbility: 'Stone Skin: takes half damage from all sources' },
];

// ── Terrain definitions ──
export const TERRAIN_DEFS: TerrainDef[] = [
  { type: 'water',      name: 'Water',      color: '#3388cc', bg: '#081828', glow: '#3388cc', minFloor: 1 },
  { type: 'lava',       name: 'Lava',       color: '#ff5511', bg: '#2a0800', glow: '#ff5511', minFloor: 4 },
  { type: 'poison',     name: 'Poison',     color: '#44cc22', bg: '#0a1a04', glow: '#44cc22', minFloor: 3 },
  { type: 'ice',        name: 'Ice',        color: '#88ddff', bg: '#0a1a2a', glow: '#88ddff', minFloor: 2 },
  { type: 'tall_grass', name: 'Tall Grass', color: '#55aa33', bg: '#0a1a08',                  minFloor: 1 },
  { type: 'mud',        name: 'Mud',        color: '#8a6633', bg: '#1a1008',                  minFloor: 2 },
  { type: 'holy',       name: 'Holy Ground', color: '#ffdd66', bg: '#1a1808', glow: '#ffdd66', minFloor: 5 },
  { type: 'shadow',     name: 'Shadow',     color: '#554477', bg: '#0a0816', glow: '#554477', minFloor: 4 },
];

// ── Colors for messages ──
export const MSG_COLOR = {
  info: '#8888aa',
  good: '#44dd77',
  bad: '#ff5566',
  loot: '#ffe44d',
  xp: '#cc77ff',
  system: '#7799ff',
  boss: '#ff3333',
  key: '#ffd700',
  merc: '#88ccff',
};

// ── Class definitions ──
export const CLASS_DEFS: ClassDef[] = [
  {
    id: 'warrior', name: 'Warrior', char: '@', color: '#ff6644',
    description: 'High HP and defense. Built to take hits.',
    baseStats: { hp: 40, maxHp: 40, attack: 5, defense: 4, speed: 8 },
    levelBonusHp: 8, levelBonusAtk: 1, levelBonusDef: 2, requiresBestFloor: 0,
    passives: [
      { name: 'Thick Skin', description: 'Take 1 less damage from all hits', unlockLevel: 2 },
      { name: 'Berserker', description: 'Deal +50% damage when below 30% HP', unlockLevel: 4 },
      { name: 'Iron Will', description: 'Hunger drains 30% slower', unlockLevel: 7 },
    ],
  },
  {
    id: 'rogue', name: 'Rogue', char: '@', color: '#ffcc33',
    description: 'Fast and deadly. Strikes hard, dodges often.',
    baseStats: { hp: 25, maxHp: 25, attack: 6, defense: 1, speed: 14 },
    levelBonusHp: 4, levelBonusAtk: 2, levelBonusDef: 1, requiresBestFloor: 3,
    passives: [
      { name: 'Quick Feet', description: '+3 speed permanently', unlockLevel: 2 },
      { name: 'Backstab', description: '25% chance to deal double damage', unlockLevel: 4 },
      { name: 'Scavenger', description: 'Monsters drop loot more often', unlockLevel: 7 },
    ],
  },
  {
    id: 'mage', name: 'Mage', char: '@', color: '#8855ff',
    description: 'Fragile but powerful. Magic fuels every blow.',
    baseStats: { hp: 20, maxHp: 20, attack: 8, defense: 1, speed: 9 },
    levelBonusHp: 3, levelBonusAtk: 3, levelBonusDef: 0, requiresBestFloor: 7,
    passives: [
      { name: 'Arcane Sight', description: 'See 3 tiles further in the dark', unlockLevel: 2 },
      { name: 'Spell Strike', description: '20% chance to deal +5 bonus magic damage', unlockLevel: 4 },
      { name: 'Mana Shield', description: '15% chance to completely negate damage', unlockLevel: 7 },
    ],
  },
  {
    id: 'ranger', name: 'Ranger', char: '@', color: '#33cc66',
    description: 'Balanced survivor. Eats less, sees more.',
    baseStats: { hp: 30, maxHp: 30, attack: 5, defense: 2, speed: 11 },
    levelBonusHp: 5, levelBonusAtk: 1, levelBonusDef: 1, requiresBestFloor: 5,
    passives: [
      { name: 'Forager', description: 'Food restores 50% more hunger', unlockLevel: 2 },
      { name: 'Keen Eye', description: 'See monsters from further away', unlockLevel: 4 },
      { name: 'Survival Instinct', description: 'Auto-heal 50% HP once per floor when near death', unlockLevel: 7 },
    ],
  },
];
