import type { CSSProperties } from 'react';
import type { GameState } from './types';
import { XP_PER_LEVEL, HUNGER_WARNING, KEY_COLORS } from './constants';
import type { KeyColor } from './types';
import { getPlayerEffectiveStats, getClassDef } from './engine';
import { getZoneDef } from './zones';

interface HUDProps {
  state: GameState;
  generation?: number;
  isPremium?: boolean;
}

function AsciiBar({ current, max, color, width = 12 }: { current: number; max: number; color: string; width?: number }) {
  const filled = Math.round((current / max) * width);
  const empty = width - filled;
  return (
    <span style={{ fontFamily: 'monospace', fontSize: 11, letterSpacing: 0 }}>
      <span style={{ color: '#0a3a0a' }}>[</span>
      <span style={{ color }}>{'\u2588'.repeat(filled)}</span>
      <span style={{ color: '#0a1a0a' }}>{'\u2591'.repeat(empty)}</span>
      <span style={{ color: '#0a3a0a' }}>]</span>
    </span>
  );
}

export function HUD({ state, generation, isPremium }: HUDProps) {
  const { player, playerClass, floorNumber, score, hunger } = state;
  const classDef = getClassDef(playerClass);
  const eStats = getPlayerEffectiveStats(state);
  const eAtk = eStats.attack;
  const eDef = eStats.defense;
  const eMaxHp = eStats.maxHp;
  const eSpd = eStats.speed;
  const eRegen = eStats.regenBonus;

  const hpPct = Math.max(0, player.stats.hp / eMaxHp);
  const hpColor = hpPct > 0.6 ? '#33ff66' : hpPct > 0.3 ? '#ccaa22' : '#ff3333';

  const hungerPct = Math.max(0, hunger.current / hunger.max);
  const hungerColor = hungerPct > 0.5 ? '#33cc55' : hungerPct > HUNGER_WARNING / hunger.max ? '#ccaa22' : '#ff3333';

  const nextXp = player.level < XP_PER_LEVEL.length ? (XP_PER_LEVEL[player.level] ?? 9999) : 9999;

  return (
    <div style={hudStyle}>
      <div style={rowStyle}>
        <span style={{ color: classDef?.color ?? '#33ff66', fontWeight: 'bold', fontSize: 13, textShadow: `0 0 4px ${classDef?.color ?? '#33ff66'}44` }}>@</span>
        {isPremium && <span style={premiumBadgeStyle} title="Premium active">&#x2B50;</span>}
        <span style={{ ...labelStyle, color: classDef?.color ?? '#33ff66' }}>{classDef?.name ?? '??'}</span>
        <span style={{ ...labelStyle, color: '#33ff66' }}>Lv{player.level}</span>
        <span style={{ ...labelStyle, color: hpColor }}>HP</span>
        <AsciiBar current={player.stats.hp} max={eMaxHp} color={hpColor} width={10} />
        <span style={{ ...statStyle, color: hpColor }}>
          {player.stats.hp}/{eMaxHp}
        </span>
      </div>
      <div style={rowStyle}>
        <span style={{ ...labelStyle, color: hungerColor }}>Food</span>
        <AsciiBar current={hunger.current} max={hunger.max} color={hungerColor} width={10} />
        <span style={{ ...statStyle, color: hungerColor }}>
          {Math.floor(hunger.current)}/{hunger.max}
        </span>
        <span style={{ color: '#0a3a0a', margin: '0 2px' }}>|</span>
        <span style={{ ...labelStyle, color: '#22aa44' }}>XP</span>
        <AsciiBar current={player.xp} max={nextXp} color={'#22aa44'} width={6} />
      </div>
      <div style={rowStyle}>
        <span style={{ ...statStyle, color: '#33ff66' }}>Atk:{eAtk}</span>
        <span style={{ ...statStyle, color: '#33ff66' }}>Def:{eDef}</span>
        <span style={{ ...statStyle, color: '#33ff66' }}>Spd:{eSpd}</span>
        {eRegen > 0 && <span style={{ ...statStyle, color: '#66ffaa' }}>Rgn:+{eRegen}</span>}
        <span style={{ color: '#0a3a0a' }}>|</span>
        <span style={{ ...statStyle, color: '#ccaa22' }}>Gold:{score}</span>
        <span style={{ ...statStyle, color: '#33ff66' }}>F:{floorNumber}</span>
        {state.zone !== 'stone_depths' && (
          <span style={{ ...statStyle, color: getZoneDef(state.zone).color, opacity: 0.8 }}>{getZoneDef(state.zone).name.split(' ')[0]}</span>
        )}
        {state.mercenaries && state.mercenaries.filter(m => !m.isDead).length > 0 && (
          <span style={{ ...statStyle, color: '#88ccff' }}>Party:{state.mercenaries.filter(m => !m.isDead).length}</span>
        )}
        {state.keysHeld && Object.entries(state.keysHeld).some(([, v]) => v > 0) && (
          <span style={{ ...statStyle, display: 'inline-flex', gap: 2 }}>
            {(Object.entries(state.keysHeld) as [KeyColor, number][])
              .filter(([, count]) => count > 0)
              .map(([color, count]) => (
                <span key={color} style={{ color: KEY_COLORS[color].color }}>
                  {KEY_COLORS[color].char}{count > 1 ? `x${count}` : ''}
                </span>
              ))
            }
          </span>
        )}
        {generation != null && generation > 0 && (
          <span style={{ ...statStyle, color: '#c49eff', opacity: 0.7 }}>G:{generation}</span>
        )}
      </div>
      {player.statusEffects && player.statusEffects.length > 0 && (
        <div style={rowStyle}>
          {player.statusEffects.map((e, i) => {
            const effectColors: Record<string, string> = { poison: '#33cc11', bleed: '#ff4444', stun: '#ffff44', freeze: '#88ccff' };
            const effectIcons: Record<string, string> = { poison: '\u2620', bleed: '\u2764', stun: '\u26A1', freeze: '\u2744' };
            return (
              <span key={i} style={{ ...statStyle, color: effectColors[e.type] ?? '#fff' }}>
                {effectIcons[e.type] ?? '?'}{e.type}({e.turnsRemaining})
              </span>
            );
          })}
        </div>
      )}
    </div>
  );
}

const hudStyle: CSSProperties = {
  width: '100%',
  padding: '3px 8px',
  background: '#000',
  borderBottom: '1px solid #1a5a2a',
  display: 'flex',
  flexDirection: 'column',
  gap: 1,
  fontFamily: 'monospace',
  fontSize: 11,
  userSelect: 'none',
};

const rowStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 5,
};

const labelStyle: CSSProperties = {
  color: '#1a8a3a',
  fontSize: 11,
  minWidth: 20,
};

const statStyle: CSSProperties = {
  fontSize: 11,
  whiteSpace: 'nowrap',
};

const premiumBadgeStyle: CSSProperties = {
  fontSize: 10,
  lineHeight: 1,
  filter: 'drop-shadow(0 0 3px #ffd700)',
};
