import type { Pos } from './types';

let _idCounter = 0;

export function uid(): string {
  return `e${++_idCounter}_${((Math.random() * 0xffff) | 0).toString(16)}`;
}

export function resetIdCounter(): void {
  _idCounter = 0;
}

export function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function pick<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)] as T;
}

export function manhattan(a: Pos, b: Pos): number {
  return Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
}

export function chebyshev(a: Pos, b: Pos): number {
  return Math.max(Math.abs(a.x - b.x), Math.abs(a.y - b.y));
}

export function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

export function findPath(
  start: Pos,
  goal: Pos,
  isWalkable: (x: number, y: number) => boolean,
  maxSteps = 30,
): Pos | null {
  const key = (x: number, y: number) => `${x},${y}`;
  const open: { pos: Pos; g: number; f: number }[] = [{ pos: start, g: 0, f: chebyshev(start, goal) }];
  const cameFrom = new Map<string, Pos>();
  const gScore = new Map<string, number>();
  gScore.set(key(start.x, start.y), 0);

  const dirs = [
    { x: 0, y: -1 },
    { x: 0, y: 1 },
    { x: -1, y: 0 },
    { x: 1, y: 0 },
  ];

  let iterations = 0;
  while (open.length > 0 && iterations < maxSteps * 10) {
    iterations++;
    open.sort((a, b) => a.f - b.f);
    const current = open.shift()!;

    if (current.pos.x === goal.x && current.pos.y === goal.y) {
      let step = current.pos;
      let k = key(step.x, step.y);
      while (cameFrom.has(k)) {
        const prev = cameFrom.get(k)!;
        if (prev.x === start.x && prev.y === start.y) return step;
        step = prev;
        k = key(step.x, step.y);
      }
      return step;
    }

    for (const d of dirs) {
      const nx = current.pos.x + d.x;
      const ny = current.pos.y + d.y;
      if (!isWalkable(nx, ny)) continue;
      const tentG = current.g + 1;
      const nk = key(nx, ny);
      const existing = gScore.get(nk);
      if (existing === undefined || tentG < existing) {
        gScore.set(nk, tentG);
        cameFrom.set(nk, current.pos);
        open.push({ pos: { x: nx, y: ny }, g: tentG, f: tentG + chebyshev({ x: nx, y: ny }, goal) });
      }
    }
  }
  return null;
}

export function linePoints(x0: number, y0: number, x1: number, y1: number): Pos[] {
  const points: Pos[] = [];
  const dx = Math.abs(x1 - x0);
  const dy = Math.abs(y1 - y0);
  const sx = x0 < x1 ? 1 : -1;
  const sy = y0 < y1 ? 1 : -1;
  let err = dx - dy;
  let cx = x0;
  let cy = y0;

  while (true) {
    points.push({ x: cx, y: cy });
    if (cx === x1 && cy === y1) break;
    const e2 = 2 * err;
    if (e2 > -dy) {
      err -= dy;
      cx += sx;
    }
    if (e2 < dx) {
      err += dx;
      cy += sy;
    }
  }
  return points;
}
