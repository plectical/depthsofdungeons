import { Tile, type DungeonFloor, type Room, type KeyColor, type TerrainMap, type TerrainType, type ZoneId } from './types';
import { MAP_WIDTH, MAP_HEIGHT, MIN_ROOM_SIZE, MAX_ROOM_SIZE, MAX_ROOMS } from './constants';
import { randInt, pick } from './utils';
import { getZoneTerrainDefs } from './zones';

function roomsOverlap(a: Room, b: Room): boolean {
  return a.x - 1 < b.x + b.w + 1 && a.x + a.w + 1 > b.x - 1 && a.y - 1 < b.y + b.h + 1 && a.y + a.h + 1 > b.y - 1;
}

function tileAt(tiles: Tile[][], y: number, x: number): Tile {
  return tiles[y]?.[x] ?? Tile.Void;
}

function setTile(tiles: Tile[][], y: number, x: number, val: Tile): void {
  const row = tiles[y];
  if (row) row[x] = val;
}

function hCorridor(tiles: Tile[][], x1: number, x2: number, y: number) {
  const minX = Math.min(x1, x2);
  const maxX = Math.max(x1, x2);
  for (let x = minX; x <= maxX; x++) {
    const t = tileAt(tiles, y, x);
    if (t === Tile.Void || t === Tile.Wall) {
      setTile(tiles, y, x, Tile.Corridor);
    }
  }
}

function vCorridor(tiles: Tile[][], y1: number, y2: number, x: number) {
  const minY = Math.min(y1, y2);
  const maxY = Math.max(y1, y2);
  for (let y = minY; y <= maxY; y++) {
    const t = tileAt(tiles, y, x);
    if (t === Tile.Void || t === Tile.Wall) {
      setTile(tiles, y, x, Tile.Corridor);
    }
  }
}

function pickKeyColor(floorNumber: number): KeyColor {
  if (floorNumber >= 10) return 'void';
  if (floorNumber >= 8) return 'blood';
  if (floorNumber >= 6) return 'crystal';
  if (floorNumber >= 4) return 'gold';
  return 'iron';
}

export function generateFloor(floorNumber: number, zone: ZoneId = 'stone_depths'): DungeonFloor {
  const width = MAP_WIDTH;
  const height = MAP_HEIGHT;

  const tiles: Tile[][] = [];
  for (let y = 0; y < height; y++) {
    tiles[y] = [];
    for (let x = 0; x < width; x++) {
      tiles[y]![x] = Tile.Void;
    }
  }

  const rooms: Room[] = [];
  const maxAttempts = 200;
  const targetRooms = Math.min(MAX_ROOMS, 6 + floorNumber);

  for (let attempt = 0; attempt < maxAttempts && rooms.length < targetRooms; attempt++) {
    const w = randInt(MIN_ROOM_SIZE, MAX_ROOM_SIZE);
    const h = randInt(MIN_ROOM_SIZE, MAX_ROOM_SIZE);
    const x = randInt(1, width - w - 2);
    const y = randInt(1, height - h - 2);

    const room: Room = { x, y, w, h, centerX: Math.floor(x + w / 2), centerY: Math.floor(y + h / 2) };
    if (rooms.some((r) => roomsOverlap(r, room))) continue;

    rooms.push(room);

    for (let ry = y - 1; ry <= y + h; ry++) {
      for (let rx = x - 1; rx <= x + w; rx++) {
        if (ry < 0 || ry >= height || rx < 0 || rx >= width) continue;
        if (ry === y - 1 || ry === y + h || rx === x - 1 || rx === x + w) {
          if (tileAt(tiles, ry, rx) === Tile.Void) setTile(tiles, ry, rx, Tile.Wall);
        } else {
          setTile(tiles, ry, rx, Tile.Floor);
        }
      }
    }
  }

  for (let i = 1; i < rooms.length; i++) {
    const prev = rooms[i - 1]!;
    const curr = rooms[i]!;
    if (Math.random() < 0.5) {
      hCorridor(tiles, prev.centerX, curr.centerX, prev.centerY);
      vCorridor(tiles, prev.centerY, curr.centerY, curr.centerX);
    } else {
      vCorridor(tiles, prev.centerY, curr.centerY, prev.centerX);
      hCorridor(tiles, prev.centerX, curr.centerX, curr.centerY);
    }
  }

  // Doors at room-corridor boundaries
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      if (tileAt(tiles, y, x) !== Tile.Corridor) continue;
      const hFloor = tileAt(tiles, y, x - 1) === Tile.Floor || tileAt(tiles, y, x + 1) === Tile.Floor;
      const vFloor = tileAt(tiles, y - 1, x) === Tile.Floor || tileAt(tiles, y + 1, x) === Tile.Floor;
      const hWall = tileAt(tiles, y, x - 1) === Tile.Wall || tileAt(tiles, y, x + 1) === Tile.Wall;
      const vWall = tileAt(tiles, y - 1, x) === Tile.Wall || tileAt(tiles, y + 1, x) === Tile.Wall;
      if ((hFloor && vWall) || (vFloor && hWall)) {
        if (Math.random() < 0.4) setTile(tiles, y, x, Tile.Door);
      }
    }
  }

  // Vault room (locked, requires key) on floors 2+
  if (floorNumber >= 2 && rooms.length >= 4 && Math.random() < 0.6) {
    const vaultIdx = randInt(1, rooms.length - 2);
    const vault = rooms[vaultIdx]!;
    vault.isVault = true;
    vault.keyColor = pickKeyColor(floorNumber);

    for (let ry = vault.y - 1; ry <= vault.y + vault.h; ry++) {
      for (let rx = vault.x - 1; rx <= vault.x + vault.w; rx++) {
        if (ry < 0 || ry >= height || rx < 0 || rx >= width) continue;
        const t = tileAt(tiles, ry, rx);
        if (t === Tile.Door || t === Tile.Corridor) {
          const onBoundary = ry === vault.y - 1 || ry === vault.y + vault.h ||
                            rx === vault.x - 1 || rx === vault.x + vault.w;
          if (onBoundary) setTile(tiles, ry, rx, Tile.LockedDoor);
        }
      }
    }
  }

  // Boss arena every 3 floors starting at floor 3
  if (floorNumber >= 3 && floorNumber % 3 === 0 && rooms.length >= 3) {
    for (let i = rooms.length - 2; i >= 1; i--) {
      const room = rooms[i]!;
      if (!room.isVault) {
        room.isBossArena = true;
        let gatePlaced = false;
        for (let ry = room.y - 1; ry <= room.y + room.h && !gatePlaced; ry++) {
          for (let rx = room.x - 1; rx <= room.x + room.w && !gatePlaced; rx++) {
            if (ry < 0 || ry >= height || rx < 0 || rx >= width) continue;
            const t = tileAt(tiles, ry, rx);
            if (t === Tile.Door || t === Tile.Corridor) {
              const onBoundary = ry === room.y - 1 || ry === room.y + room.h ||
                                rx === room.x - 1 || rx === room.x + room.w;
              if (onBoundary) {
                setTile(tiles, ry, rx, Tile.BossGate);
                gatePlaced = true;
              }
            }
          }
        }
        break;
      }
    }
  }

  // Stairs down — always placed in a non-vault room to keep stairs freely accessible
  if (rooms.length > 0) {
    // Prefer the last room; fall back to any non-vault room if needed
    let stairsRoom = rooms[rooms.length - 1]!;
    if (stairsRoom.isVault) {
      const fallback = [...rooms].reverse().find(r => !r.isVault && !r.isBossArena);
      if (fallback) stairsRoom = fallback;
    }
    setTile(tiles, stairsRoom.centerY, stairsRoom.centerX, Tile.StairsDown);
  }

  const visible: boolean[][] = [];
  const explored: boolean[][] = [];
  for (let y = 0; y < height; y++) {
    visible[y] = new Array<boolean>(width).fill(false);
    explored[y] = new Array<boolean>(width).fill(false);
  }

  // Fill walls around corridors
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const t = tileAt(tiles, y, x);
      if (t === Tile.Corridor || t === Tile.Door || t === Tile.LockedDoor || t === Tile.BossGate) {
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            const ny = y + dy;
            const nx = x + dx;
            if (ny >= 0 && ny < height && nx >= 0 && nx < width && tileAt(tiles, ny, nx) === Tile.Void) {
              setTile(tiles, ny, nx, Tile.Wall);
            }
          }
        }
      }
    }
  }

  const terrain = generateTerrain(tiles, rooms, floorNumber, width, height, zone);

  return { width, height, tiles, rooms, visible, explored, terrain };
}

// ── Terrain generation ──

function generateTerrain(
  tiles: Tile[][],
  rooms: Room[],
  floorNumber: number,
  width: number,
  height: number,
  zone: ZoneId = 'stone_depths',
): TerrainMap {
  const terrain: TerrainMap = {};
  // Use zone-specific terrain pool
  const zoneTerrainDefs = getZoneTerrainDefs(zone);
  const eligible = zoneTerrainDefs.filter((t) => t.minFloor <= floorNumber);
  if (eligible.length === 0) return terrain;

  // Most rooms get terrain — skip room 0 (player spawn), vaults, and boss arenas
  const candidateRooms = rooms.filter((r, i) => i > 0 && !r.isVault && !r.isBossArena);

  // 60-80% of eligible rooms get terrain, with multiple patches possible per room
  const roomsToFill = Math.max(1, Math.floor(candidateRooms.length * (0.6 + Math.random() * 0.2)));
  const shuffled = [...candidateRooms].sort(() => Math.random() - 0.5).slice(0, roomsToFill);

  for (const room of shuffled) {
    // Each room gets 1-2 terrain types
    const typesInRoom = Math.random() < 0.25 ? 2 : 1;

    for (let t = 0; t < typesInRoom; t++) {
      const def = pick(eligible);

      // Cover 40-90% of the room's floor area (much bigger patches)
      const maxFill = Math.floor(room.w * room.h * (0.4 + Math.random() * 0.5));
      const clusterSize = Math.max(4, maxFill);
      const startX = randInt(room.x, room.x + room.w - 1);
      const startY = randInt(room.y, room.y + room.h - 1);

      // Flood-fill-style spread from the starting point
      const open: Array<{ x: number; y: number }> = [{ x: startX, y: startY }];
      const placed = new Set<string>();
      let count = 0;

      while (open.length > 0 && count < clusterSize) {
        const idx = randInt(0, open.length - 1);
        const pos = open[idx]!;
        open.splice(idx, 1);

        const key = `${pos.x},${pos.y}`;
        if (placed.has(key)) continue;
        if (terrain[key]) continue; // Don't overwrite other terrain
        if (pos.x < room.x || pos.x >= room.x + room.w) continue;
        if (pos.y < room.y || pos.y >= room.y + room.h) continue;

        const tile = tiles[pos.y]?.[pos.x];
        if (tile !== Tile.Floor) continue;

        terrain[key] = def.type;
        placed.add(key);
        count++;

        // Expand to neighbors
        for (const [dx, dy] of [[0, 1], [0, -1], [1, 0], [-1, 0]] as const) {
          const nk = `${pos.x + dx},${pos.y + dy}`;
          if (!placed.has(nk)) {
            open.push({ x: pos.x + dx, y: pos.y + dy });
          }
        }
      }
    }
  }

  // Corridors also get terrain — 12% chance per corridor tile (much more common)
  // Use the first 4 terrain types from the zone pool that are eligible
  const corridorTerrains: TerrainType[] = eligible
    .slice(0, 4)
    .map(e => e.type);
  if (corridorTerrains.length > 0) {
    // Pick a dominant corridor terrain for consistency
    const dominantCorrTerrain = pick(corridorTerrains);
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        if (tiles[y]?.[x] === Tile.Corridor && !terrain[`${x},${y}`] && Math.random() < 0.12) {
          // 70% dominant, 30% random
          terrain[`${x},${y}`] = Math.random() < 0.7 ? dominantCorrTerrain : pick(corridorTerrains);
        }
      }
    }
  }

  return terrain;
}

export function getTerrainAt(floor: DungeonFloor, x: number, y: number): TerrainType | undefined {
  return floor.terrain[`${x},${y}`];
}

export function isWalkableTile(tile: Tile): boolean {
  return tile === Tile.Floor || tile === Tile.Corridor || tile === Tile.Door
    || tile === Tile.StairsDown || tile === Tile.StairsUp || tile === Tile.BossGate;
}

export function getTile(floor: { tiles: Tile[][]; width: number; height: number }, x: number, y: number): Tile {
  if (x < 0 || x >= floor.width || y < 0 || y >= floor.height) return Tile.Void;
  return floor.tiles[y]?.[x] ?? Tile.Void;
}
