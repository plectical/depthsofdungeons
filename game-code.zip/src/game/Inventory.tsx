import { useState } from 'react';
import type { CSSProperties } from 'react';
import type { GameState, EquipSlot } from './types';
import { useItem, equipItem, unequipItem, dropItem } from './engine';

interface InventoryProps {
  state: GameState;
  onChange: (s: GameState) => void;
  onClose: () => void;
}

export function Inventory({ state, onChange, onClose }: InventoryProps) {
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [tab, setTab] = useState<'items' | 'equip'>('items');

  const handleUse = (idx: number) => {
    const next = structuredClone(state);
    if (useItem(next, idx)) {
      setSelectedIdx(null);
      onChange(next);
    }
  };

  const handleEquip = (idx: number) => {
    const next = structuredClone(state);
    if (equipItem(next, idx)) {
      setSelectedIdx(null);
      onChange(next);
    }
  };

  const handleUnequip = (slot: EquipSlot) => {
    const next = structuredClone(state);
    if (unequipItem(next, slot)) {
      onChange(next);
    }
  };

  const handleDrop = (idx: number) => {
    const next = structuredClone(state);
    if (dropItem(next, idx)) {
      setSelectedIdx(null);
      onChange(next);
    }
  };

  const { inventory, equipment } = state.player;

  return (
    <div style={overlayStyle}>
      <div style={panelStyle}>
        <pre style={panelBorderStyle}>{'+=== INVENTORY =======================+'}</pre>
        <div style={headerStyle}>
          <div style={tabsStyle}>
            <button style={tab === 'items' ? tabActiveStyle : tabStyle} onClick={() => setTab('items')}>
              {'[ Items '}{inventory.length}/20{' ]'}
            </button>
            <button style={tab === 'equip' ? tabActiveStyle : tabStyle} onClick={() => setTab('equip')}>
              {'[ Equipped ]'}
            </button>
          </div>
          <button style={closeBtnStyle} onClick={onClose}>
            [X]
          </button>
        </div>

        {tab === 'items' && (
          <div style={listStyle}>
            {inventory.length === 0 && <div style={emptyStyle}>{'-- No items --'}</div>}
            {inventory.map((item, idx) => (
              <div key={item.id} style={itemRowStyle} onClick={() => setSelectedIdx(selectedIdx === idx ? null : idx)}>
                <span style={{ color: item.color, marginRight: 6, fontFamily: 'monospace' }}>{item.char}</span>
                <span style={itemNameStyle}>{item.name}</span>
                {selectedIdx === idx && (
                  <div style={actionsStyle}>
                    {(item.type === 'potion' || item.type === 'scroll' || item.type === 'food') && (
                      <button style={itemActionBtnStyle} onClick={() => handleUse(idx)}>
                        [Use]
                      </button>
                    )}
                    {item.equipSlot && (
                      <button style={itemActionBtnStyle} onClick={() => handleEquip(idx)}>
                        [Equip]
                      </button>
                    )}
                    <button style={{ ...itemActionBtnStyle, color: '#ff3333', borderColor: '#4a0a0a' }} onClick={() => handleDrop(idx)}>
                      [Drop]
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {tab === 'equip' && (
          <div style={listStyle}>
            {(['weapon', 'armor', 'ring', 'amulet'] as EquipSlot[]).map((slot) => {
              const item = equipment[slot];
              return (
                <div key={slot} style={itemRowStyle}>
                  <span style={slotLabelStyle}>{slot.charAt(0).toUpperCase() + slot.slice(1)}:</span>
                  {item ? (
                    <>
                      <span style={{ color: item.color, marginRight: 4, fontFamily: 'monospace' }}>{item.char}</span>
                      <span style={itemNameStyle}>{item.name}</span>
                      <span style={bonusStyle}>
                        {item.statBonus?.attack ? `+${item.statBonus.attack}atk` : ''}
                        {item.statBonus?.defense ? `+${item.statBonus.defense}def` : ''}
                        {item.statBonus?.maxHp ? `+${item.statBonus.maxHp}hp` : ''}
                      </span>
                      <button style={itemActionBtnStyle} onClick={() => handleUnequip(slot)}>
                        [Remove]
                      </button>
                    </>
                  ) : (
                    <span style={emptySlotStyle}>{'-- empty --'}</span>
                  )}
                </div>
              );
            })}
          </div>
        )}
        <pre style={{ ...panelBorderStyle, padding: '0 8px 4px' }}>{'+=== ================================-+'}</pre>
      </div>
    </div>
  );
}

const overlayStyle: CSSProperties = {
  position: 'absolute',
  inset: 0,
  background: 'rgba(0,0,0,0.92)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 50,
  padding: 12,
};

const panelStyle: CSSProperties = {
  width: '100%',
  maxWidth: 380,
  maxHeight: '80%',
  background: '#000',
  border: '1px solid #1a5a2a',
  borderRadius: 0,
  display: 'flex',
  flexDirection: 'column',
  overflow: 'hidden',
};

const panelBorderStyle: CSSProperties = {
  color: '#1a8a3a',
  fontSize: 11,
  margin: 0,
  padding: '4px 8px 0',
  fontFamily: 'monospace',
  textShadow: '0 0 4px #33ff6622',
  overflow: 'hidden',
  whiteSpace: 'nowrap',
};

const headerStyle: CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '4px 8px',
  borderBottom: '1px solid #0a3a0a',
};

const tabsStyle: CSSProperties = {
  display: 'flex',
  gap: 4,
};

const tabStyle: CSSProperties = {
  padding: '4px 8px',
  fontSize: 11,
  background: 'transparent',
  color: '#0a5a1a',
  border: '1px solid #0a3a0a',
  borderRadius: 0,
  fontFamily: 'monospace',
  cursor: 'pointer',
  letterSpacing: 1,
};

const tabActiveStyle: CSSProperties = {
  ...tabStyle,
  color: '#33ff66',
  border: '1px solid #1a5a2a',
  textShadow: '0 0 4px #33ff6644',
};

const closeBtnStyle: CSSProperties = {
  padding: '4px 6px',
  fontSize: 12,
  fontWeight: 'bold',
  background: 'transparent',
  color: '#ff3333',
  border: '1px solid #4a0a0a',
  borderRadius: 0,
  fontFamily: 'monospace',
  cursor: 'pointer',
  letterSpacing: 1,
};

const listStyle: CSSProperties = {
  flex: 1,
  overflowY: 'auto',
  padding: 8,
};

const itemRowStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  flexWrap: 'wrap',
  padding: '5px 6px',
  borderBottom: '1px solid #0a1a0a',
  cursor: 'pointer',
  fontSize: 12,
  fontFamily: 'monospace',
  gap: 4,
};

const itemNameStyle: CSSProperties = {
  color: '#33ff66',
  flex: 1,
  minWidth: 0,
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
};

const slotLabelStyle: CSSProperties = {
  color: '#1a8a3a',
  fontSize: 11,
  minWidth: 60,
  textTransform: 'capitalize',
};

const emptySlotStyle: CSSProperties = {
  color: '#0a3a0a',
  fontSize: 11,
};

const bonusStyle: CSSProperties = {
  color: '#66ffaa',
  fontSize: 10,
  marginLeft: 4,
};

const actionsStyle: CSSProperties = {
  width: '100%',
  display: 'flex',
  gap: 4,
  marginTop: 4,
  paddingTop: 4,
  borderTop: '1px solid #0a2a0a',
};

const itemActionBtnStyle: CSSProperties = {
  padding: '2px 8px',
  fontSize: 11,
  background: 'transparent',
  color: '#33ff66',
  border: '1px solid #1a5a2a',
  borderRadius: 0,
  fontFamily: 'monospace',
  cursor: 'pointer',
  letterSpacing: 1,
};

const emptyStyle: CSSProperties = {
  color: '#0a3a0a',
  textAlign: 'center',
  padding: 20,
  fontFamily: 'monospace',
  fontSize: 12,
};
