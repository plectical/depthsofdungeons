import { useRef, useEffect } from 'react';
import type { CSSProperties } from 'react';
import type { LogMessage } from './types';

interface MessageLogProps {
  messages: LogMessage[];
}

export function MessageLog({ messages }: MessageLogProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages.length]);

  const recent = messages.slice(-6);

  return (
    <div ref={scrollRef} style={logStyle}>
      {recent.map((m, i) => (
        <div key={i} style={{ color: m.color, fontSize: 11, fontFamily: 'monospace', lineHeight: '14px' }}>
          <span style={{ color: '#0a3a0a' }}>{'> '}</span>{m.text}
        </div>
      ))}
    </div>
  );
}

const logStyle: CSSProperties = {
  width: '100%',
  maxHeight: 90,
  overflowY: 'auto',
  padding: '4px 8px',
  background: '#000',
  borderTop: '1px solid #1a5a2a',
};
