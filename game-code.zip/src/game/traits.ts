import type { BloodlineData, RunStats, TraitDef, TraitEffect, Stats } from './types';
import { pick } from './utils';

// ── Name generation for ancestors ──

const FIRST_NAMES = [
  'Aran', 'Kira', 'Goran', 'Liara', 'Theron', 'Mira', 'Dren', 'Syla',
  'Vex', 'Nyx', 'Brom', 'Ela', 'Torr', 'Zara', 'Finn', 'Lysa',
  'Kael', 'Rhea', 'Joss', 'Thia',
];

const TITLES = [
  'the Bold', 'the Swift', 'the Brave', 'the Wise', 'the Fierce',
  'the Quiet', 'the Lost', 'the Hungry', 'the Lucky', 'the Grim',
  'the Fallen', 'the Cursed', 'the Stubborn',
];

export function generateAncestorName(): string {
  return `${pick(FIRST_NAMES)} ${pick(TITLES)}`;
}

// ── Empty data constructors ──

export function createEmptyRunStats(): RunStats {
  return {
    kills: 0,
    damageDealt: 0,
    damageTaken: 0,
    potionsUsed: 0,
    foodEaten: 0,
    scrollsUsed: 0,
    itemsFound: 0,
    goldEarned: 0,
    floorsCleared: 0,
    npcsTalkedTo: 0,
    monsterKills: {},
    bossesKilled: 0,
    keysUsed: 0,
    mercenariesHired: 0,
  };
}

export function createDefaultBloodline(): BloodlineData {
  return {
    version: 1,
    generation: 0,
    ancestors: [],
    cumulative: {
      totalDeaths: 0,
      totalKills: 0,
      totalDamageDealt: 0,
      totalDamageTaken: 0,
      totalFloors: 0,
      totalScore: 0,
      totalTurns: 0,
      totalPotionsUsed: 0,
      totalFoodEaten: 0,
      totalScrollsUsed: 0,
      totalItemsFound: 0,
      totalGoldEarned: 0,
      totalNpcsTalkedTo: 0,
      totalMonsterKills: {},
      classDeaths: { warrior: 0, rogue: 0, mage: 0, ranger: 0, necromancer: 0, revenant: 0 },
      highestFloor: 0,
      highestScore: 0,
    },
    unlockedTraits: [],
    npcChoicesMade: {},
    bossKillLog: [],
  };
}

// ── The 20 Traits ──

export const TRAIT_DEFS: TraitDef[] = [
  // Death traits
  {
    id: 'first_fall',
    name: 'First Fall',
    description: 'Die once. +2 max HP.',
    icon: '+',
    color: '#ff5566',
    category: 'death',
    condition: (b) => b.cumulative.totalDeaths >= 1,
    effect: { type: 'statBonus', stat: 'maxHp', value: 2 },
  },
  {
    id: 'stubborn',
    name: 'Stubborn',
    description: 'Die 5 times. +1 defense.',
    icon: '!',
    color: '#ff7744',
    category: 'death',
    condition: (b) => b.cumulative.totalDeaths >= 5,
    effect: { type: 'statBonus', stat: 'defense', value: 1 },
  },
  {
    id: 'undying_will',
    name: 'Undying Will',
    description: 'Die 10 times. +5 max HP.',
    icon: '*',
    color: '#ff3333',
    category: 'death',
    condition: (b) => b.cumulative.totalDeaths >= 10,
    effect: { type: 'statBonus', stat: 'maxHp', value: 5 },
  },
  {
    id: 'death_defier',
    name: 'Death Defier',
    description: 'Die 25 times. Start with a Health Potion.',
    icon: '%',
    color: '#ff2222',
    category: 'death',
    condition: (b) => b.cumulative.totalDeaths >= 25,
    effect: { type: 'startingItem', itemName: 'Health Potion' },
  },

  // Combat traits
  {
    id: 'blooded',
    name: 'Blooded',
    description: 'Kill 10 monsters total. +1 attack.',
    icon: '/',
    color: '#ff6644',
    category: 'combat',
    condition: (b) => b.cumulative.totalKills >= 10,
    effect: { type: 'statBonus', stat: 'attack', value: 1 },
  },
  {
    id: 'slayer',
    name: 'Slayer',
    description: 'Kill 50 monsters total. +2 attack.',
    icon: 'X',
    color: '#ff4422',
    category: 'combat',
    condition: (b) => b.cumulative.totalKills >= 50,
    effect: { type: 'statBonus', stat: 'attack', value: 2 },
  },
  {
    id: 'dragonbane',
    name: 'Dragonbane',
    description: 'Slay 3 Dragons across all runs. +3 attack.',
    icon: 'D',
    color: '#ff5522',
    category: 'combat',
    condition: (b) => (b.cumulative.totalMonsterKills['Dragon'] ?? 0) >= 3,
    effect: { type: 'statBonus', stat: 'attack', value: 3 },
  },
  {
    id: 'thick_hide',
    name: 'Thick Hide',
    description: 'Take 500 damage across all runs. +2 defense.',
    icon: '[',
    color: '#88aacc',
    category: 'combat',
    condition: (b) => b.cumulative.totalDamageTaken >= 500,
    effect: { type: 'statBonus', stat: 'defense', value: 2 },
  },

  // Exploration traits
  {
    id: 'deep_diver',
    name: 'Deep Diver',
    description: 'Clear 20 floors total across all runs. +1 speed.',
    icon: '>',
    color: '#3eff7e',
    category: 'exploration',
    condition: (b) => b.cumulative.totalFloors >= 20,
    effect: { type: 'statBonus', stat: 'speed', value: 1 },
  },
  {
    id: 'abyss_walker',
    name: 'Abyss Walker',
    description: 'Reach floor 10 in a single run. +5 HP, +1 def.',
    icon: 'V',
    color: '#22ddaa',
    category: 'exploration',
    condition: (b) => b.cumulative.highestFloor >= 10,
    effect: { type: 'multi', effects: [
      { type: 'statBonus', stat: 'maxHp', value: 5 },
      { type: 'statBonus', stat: 'defense', value: 1 },
    ]},
  },
  {
    id: 'hoarder',
    name: 'Hoarder',
    description: 'Find 100 items across all runs. Start with 25 gold.',
    icon: '$',
    color: '#ffd700',
    category: 'exploration',
    condition: (b) => b.cumulative.totalItemsFound >= 100,
    effect: { type: 'startingGold', amount: 25 },
  },
  {
    id: 'well_fed',
    name: 'Well Fed',
    description: 'Eat 30 food items across all runs. +20 max hunger.',
    icon: '%',
    color: '#e8c888',
    category: 'exploration',
    condition: (b) => b.cumulative.totalFoodEaten >= 30,
    effect: { type: 'hungerBonus', value: 20 },
  },

  // Class legacy traits
  {
    id: 'warriors_legacy',
    name: "Warrior's Legacy",
    description: 'Die as Warrior 3 times. +3 max HP for all.',
    icon: '@',
    color: '#ff6644',
    category: 'class',
    condition: (b) => (b.cumulative.classDeaths.warrior ?? 0) >= 3,
    effect: { type: 'statBonus', stat: 'maxHp', value: 3 },
  },
  {
    id: 'rogues_legacy',
    name: "Rogue's Legacy",
    description: 'Die as Rogue 3 times. +1 speed for all.',
    icon: '@',
    color: '#ffcc33',
    category: 'class',
    condition: (b) => (b.cumulative.classDeaths.rogue ?? 0) >= 3,
    effect: { type: 'statBonus', stat: 'speed', value: 1 },
  },
  {
    id: 'mages_legacy',
    name: "Mage's Legacy",
    description: 'Die as Mage 3 times. +1 attack for all.',
    icon: '@',
    color: '#8855ff',
    category: 'class',
    condition: (b) => (b.cumulative.classDeaths.mage ?? 0) >= 3,
    effect: { type: 'statBonus', stat: 'attack', value: 1 },
  },
  {
    id: 'rangers_legacy',
    name: "Ranger's Legacy",
    description: 'Die as Ranger 3 times. +10 max hunger for all.',
    icon: '@',
    color: '#33cc66',
    category: 'class',
    condition: (b) => (b.cumulative.classDeaths.ranger ?? 0) >= 3,
    effect: { type: 'hungerBonus', value: 10 },
  },

  // NPC dialogue traits
  {
    id: 'hermits_wisdom',
    name: "Hermit's Wisdom",
    description: 'Listen to the Hermit. +10% XP.',
    icon: '?',
    color: '#88aaff',
    category: 'npc',
    condition: (b) => b.npcChoicesMade['hermit'] === 'listen',
    effect: { type: 'xpMultiplier', value: 1.1 },
  },
  {
    id: 'merchants_favor',
    name: "Merchant's Favor",
    description: 'Trade with the Wandering Merchant. Start with Bread + 15g.',
    icon: '$',
    color: '#ffd700',
    category: 'npc',
    condition: (b) => b.npcChoicesMade['merchant'] === 'trade',
    effect: { type: 'multi', effects: [
      { type: 'startingItem', itemName: 'Bread' },
      { type: 'startingGold', amount: 15 },
    ]},
  },

  // Legacy (multi-generation)
  {
    id: 'bloodline_awakened',
    name: 'Bloodline Awakened',
    description: '10 generations. +1 to all stats.',
    icon: '~',
    color: '#c49eff',
    category: 'legacy',
    condition: (b) => b.generation >= 10,
    effect: { type: 'multi', effects: [
      { type: 'statBonus', stat: 'maxHp', value: 1 },
      { type: 'statBonus', stat: 'attack', value: 1 },
      { type: 'statBonus', stat: 'defense', value: 1 },
      { type: 'statBonus', stat: 'speed', value: 1 },
    ]},
  },
  {
    id: 'dynasty',
    name: 'Dynasty',
    description: '25 generations + 200 kills. +2 all stats, start with Short Sword.',
    icon: '^',
    color: '#ffdd44',
    category: 'legacy',
    condition: (b) => b.generation >= 25 && b.cumulative.totalKills >= 200,
    effect: { type: 'multi', effects: [
      { type: 'statBonus', stat: 'maxHp', value: 2 },
      { type: 'statBonus', stat: 'attack', value: 2 },
      { type: 'statBonus', stat: 'defense', value: 2 },
      { type: 'statBonus', stat: 'speed', value: 2 },
      { type: 'startingItem', itemName: 'Short Sword' },
    ]},
  },
];

// ── Helpers ──

export function getUnlockedTraits(bloodline: BloodlineData): TraitDef[] {
  return TRAIT_DEFS.filter((t) => bloodline.unlockedTraits.includes(t.id));
}

export function checkForNewTraits(bloodline: BloodlineData): TraitDef[] {
  return TRAIT_DEFS.filter(
    (t) => !bloodline.unlockedTraits.includes(t.id) && t.condition(bloodline),
  );
}

export interface BloodlineBonuses {
  statBonuses: Partial<Stats>;
  startingItems: string[];
  startingGold: number;
  hungerBonus: number;
  xpMultiplier: number;
}

function applyEffect(result: BloodlineBonuses, effect: TraitEffect) {
  switch (effect.type) {
    case 'statBonus':
      result.statBonuses[effect.stat] =
        (result.statBonuses[effect.stat] ?? 0) + effect.value;
      break;
    case 'startingItem':
      result.startingItems.push(effect.itemName);
      break;
    case 'startingGold':
      result.startingGold += effect.amount;
      break;
    case 'hungerBonus':
      result.hungerBonus += effect.value;
      break;
    case 'xpMultiplier':
      result.xpMultiplier *= effect.value;
      break;
    case 'multi':
      for (const e of effect.effects) applyEffect(result, e);
      break;
  }
}

export function computeBloodlineBonuses(bloodline: BloodlineData): BloodlineBonuses {
  const result: BloodlineBonuses = {
    statBonuses: {},
    startingItems: [],
    startingGold: 0,
    hungerBonus: 0,
    xpMultiplier: 1.0,
  };

  for (const traitId of bloodline.unlockedTraits) {
    const def = TRAIT_DEFS.find((t) => t.id === traitId);
    if (!def) continue;
    applyEffect(result, def.effect);
  }

  return result;
}

/** Get progress info for a trait (numerator/denominator for display). */
export function getTraitProgress(
  trait: TraitDef,
  bloodline: BloodlineData,
): { current: number; target: number } | null {
  const c = bloodline.cumulative;
  switch (trait.id) {
    case 'first_fall': return { current: c.totalDeaths, target: 1 };
    case 'stubborn': return { current: c.totalDeaths, target: 5 };
    case 'undying_will': return { current: c.totalDeaths, target: 10 };
    case 'death_defier': return { current: c.totalDeaths, target: 25 };
    case 'blooded': return { current: c.totalKills, target: 10 };
    case 'slayer': return { current: c.totalKills, target: 50 };
    case 'dragonbane': return { current: c.totalMonsterKills['Dragon'] ?? 0, target: 3 };
    case 'thick_hide': return { current: c.totalDamageTaken, target: 500 };
    case 'deep_diver': return { current: c.totalFloors, target: 20 };
    case 'abyss_walker': return { current: c.highestFloor, target: 10 };
    case 'hoarder': return { current: c.totalItemsFound, target: 100 };
    case 'well_fed': return { current: c.totalFoodEaten, target: 30 };
    case 'warriors_legacy': return { current: c.classDeaths.warrior ?? 0, target: 3 };
    case 'rogues_legacy': return { current: c.classDeaths.rogue ?? 0, target: 3 };
    case 'mages_legacy': return { current: c.classDeaths.mage ?? 0, target: 3 };
    case 'rangers_legacy': return { current: c.classDeaths.ranger ?? 0, target: 3 };
    case 'bloodline_awakened': return { current: bloodline.generation, target: 10 };
    case 'dynasty': return { current: bloodline.generation, target: 25 };
    default: return null;
  }
}

/** Merge run stats into cumulative bloodline data. */
export function mergeRunIntoBloodline(
  bloodline: BloodlineData,
  runStats: RunStats,
): void {
  const c = bloodline.cumulative;
  c.totalDeaths++;
  c.totalKills += runStats.kills;
  c.totalDamageDealt += runStats.damageDealt;
  c.totalDamageTaken += runStats.damageTaken;
  c.totalFloors += runStats.floorsCleared;
  c.totalTurns += 1; // counted per run
  c.totalPotionsUsed += runStats.potionsUsed;
  c.totalFoodEaten += runStats.foodEaten;
  c.totalScrollsUsed += runStats.scrollsUsed;
  c.totalItemsFound += runStats.itemsFound;
  c.totalGoldEarned += runStats.goldEarned;
  c.totalNpcsTalkedTo += runStats.npcsTalkedTo;

  for (const [name, count] of Object.entries(runStats.monsterKills)) {
    c.totalMonsterKills[name] = (c.totalMonsterKills[name] ?? 0) + count;
  }
}
