import { Tile, type GameState, type Entity, type EquipSlot, type PlayerClass, type BloodlineData, type DialogueEffect, type BossAbility, type ZoneId, type TerrainType, type MonsterAbility } from './types';
import { generateFloor, isWalkableTile, getTile, getTerrainAt } from './dungeon';
import { createPlayer, spawnMonsters, spawnItems, randomItem, spawnShop, findItemTemplate, spawnKeys, spawnBoss, spawnMercenaries, spawnVaultTreasures } from './entities';
import { VIEW_RADIUS, XP_PER_LEVEL, MSG_COLOR, MONSTER_DEFS, CLASS_DEFS, HUNGER_MAX, HUNGER_PER_TURN, HUNGER_WARNING, STARVING_THRESHOLD, STARVING_DAMAGE, REGEN_INTERVAL, REGEN_HUNGER_MIN, BOSS_DEFS, KEY_COLORS, MERCENARY_DEFS } from './constants';
import { uid, resetIdCounter, manhattan, findPath, linePoints, clamp } from './utils';
import { computeBloodlineBonuses, createEmptyRunStats } from './traits';
import { spawnNPCs } from './npcs';
import { getNecropolisClasses, getNecropolisMonsters } from './necropolis';
import { getNecropolisState } from './necropolisService';
import { getZoneDef, ZONE_BOSSES, ZONE_BOSS_LOOT } from './zones';

function findZoneBossLoot(name: string): Omit<import('./types').Item, 'id'> | undefined {
  return ZONE_BOSS_LOOT.find(t => t.name === name);
}

// ─── Terrain Placement ───

/** Place terrain tiles in a radius around a position on walkable floor tiles. */
function placeTerrain(state: GameState, cx: number, cy: number, terrain: TerrainType, radius: number, count: number) {
  const candidates: { x: number; y: number }[] = [];
  for (let dy = -radius; dy <= radius; dy++) {
    for (let dx = -radius; dx <= radius; dx++) {
      const x = cx + dx;
      const y = cy + dy;
      if (x < 0 || x >= state.floor.width || y < 0 || y >= state.floor.height) continue;
      const tile = getTile(state.floor, x, y);
      if (tile !== Tile.Floor && tile !== Tile.Corridor) continue;
      const key = `${x},${y}`;
      // Don't overwrite existing terrain
      if (state.floor.terrain[key]) continue;
      candidates.push({ x, y });
    }
  }
  // Shuffle and pick up to count tiles
  for (let i = candidates.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [candidates[i], candidates[j]] = [candidates[j]!, candidates[i]!];
  }
  const placed = Math.min(count, candidates.length);
  for (let i = 0; i < placed; i++) {
    const pos = candidates[i]!;
    state.floor.terrain[`${pos.x},${pos.y}`] = terrain;
  }
  return placed;
}

// ─── Game Init ───

export function getClassDef(cls: PlayerClass) {
  // Check base classes first, then necropolis classes
  const base = CLASS_DEFS.find((c) => c.id === cls);
  if (base) return base;
  const necroClasses = getNecropolisClasses(getNecropolisState().communalDeaths);
  return necroClasses.find((c) => c.id === cls) ?? CLASS_DEFS[0]!;
}

export function hasPassive(state: GameState, passiveName: string): boolean {
  const def = getClassDef(state.playerClass);
  return def.passives.some((p) => p.name === passiveName && state.player.level >= p.unlockLevel);
}

export function newGame(playerClass: PlayerClass = 'warrior', bloodline?: BloodlineData, zone: ZoneId = 'stone_depths'): GameState {
  resetIdCounter();
  const classDef = getClassDef(playerClass);
  const zoneDef = getZoneDef(zone);
  const floorNumber = 1;
  const floor = generateFloor(floorNumber, zone);
  const firstRoom = floor.rooms[0]!;
  const playerPos = { x: firstRoom.centerX, y: firstRoom.centerY };

  const occupied = new Set<string>();
  occupied.add(`${playerPos.x},${playerPos.y}`);
  const lastRoom = floor.rooms[floor.rooms.length - 1]!;
  occupied.add(`${lastRoom.centerX},${lastRoom.centerY}`);

  const player = createPlayer(playerPos, classDef);

  // Apply bloodline bonuses
  let bonusGold = 0;
  let hungerBonus = 0;
  let xpMult = 1.0;
  if (bloodline) {
    const bonuses = computeBloodlineBonuses(bloodline);
    player.stats.maxHp += bonuses.statBonuses.maxHp ?? 0;
    player.stats.hp += bonuses.statBonuses.maxHp ?? 0;
    player.stats.attack += bonuses.statBonuses.attack ?? 0;
    player.stats.defense += bonuses.statBonuses.defense ?? 0;
    player.stats.speed += bonuses.statBonuses.speed ?? 0;
    bonusGold = bonuses.startingGold;
    hungerBonus = bonuses.hungerBonus;
    xpMult = bonuses.xpMultiplier;

    for (const itemName of bonuses.startingItems) {
      const template = findItemTemplate(itemName);
      if (template && player.inventory.length < 20) {
        player.inventory.push({ ...template, id: uid() });
      }
    }
  }

  const monsters = spawnMonsters(floor, floorNumber, occupied, zone);
  const items = spawnItems(floor, floorNumber, occupied, zone);
  const keyItems = spawnKeys(floor, occupied);
  const vaultTreasures = spawnVaultTreasures(floor, floorNumber, occupied);
  const shop = spawnShop(floor, floorNumber, occupied, zone);
  const npcs = bloodline ? spawnNPCs(floor, floorNumber, occupied, bloodline) : [];
  const mapMercenaries = spawnMercenaries(floor, floorNumber, occupied);

  const bossesDefeatedThisRun: string[] = [];
  const boss = spawnBoss(floor, floorNumber, occupied, bossesDefeatedThisRun, zone);
  const allMonsters = boss ? [...monsters, boss] : monsters;

  const state: GameState = {
    player,
    playerClass,
    zone,
    monsters: allMonsters,
    items: [...items, ...keyItems, ...vaultTreasures],
    floor,
    floorNumber,
    turn: 0,
    messages: [],
    gameOver: false,
    score: bonusGold,
    hunger: { current: HUNGER_MAX + hungerBonus, max: HUNGER_MAX + hungerBonus },
    shop,
    runStats: createEmptyRunStats(),
    npcs,
    pendingNPC: null,
    xpMultiplier: xpMult,
    _bloodlineRef: bloodline,
    keysHeld: { iron: 0, gold: 0, crystal: 0, blood: 0, void: 0 },
    mercenaries: [],
    mapMercenaries,
    pendingMercenary: null,
    bossesDefeatedThisRun,
  };

  if (bloodline && bloodline.generation > 0) {
    const lastAncestor = bloodline.ancestors[bloodline.ancestors.length - 1];
    if (lastAncestor) {
      addMessage(state, `You carry the blood of ${lastAncestor.name} (Gen ${bloodline.generation}).`, '#c49eff');
    }
  }

  addMessage(state, `You enter ${zoneDef.name} as a ${classDef.name}!`, MSG_COLOR.system);
  addMessage(state, 'Tap to move. Find the stairs (>) to descend.', MSG_COLOR.system);
  updateFOV(state);
  return state;
}

// ─── Messages ───

export function addMessage(state: GameState, text: string, color = MSG_COLOR.info) {
  state.messages.push({ text, color, turn: state.turn });
  if (state.messages.length > 100) state.messages.shift();
}

// ─── FOV ───

export function updateFOV(state: GameState) {
  const { floor, player } = state;
  const { width, height } = floor;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const row = floor.visible[y];
      if (row) row[x] = false;
    }
  }

  let viewBonus = 0;
  if (hasPassive(state, 'Arcane Sight')) viewBonus += 3;
  if (hasPassive(state, 'Keen Eye')) viewBonus += 2;
  const viewRadius = VIEW_RADIUS + viewBonus;

  for (let angle = 0; angle < 360; angle += 2) {
    const rad = (angle * Math.PI) / 180;
    const ex = Math.round(player.pos.x + Math.cos(rad) * viewRadius);
    const ey = Math.round(player.pos.y + Math.sin(rad) * viewRadius);

    const points = linePoints(player.pos.x, player.pos.y, ex, ey);
    for (const p of points) {
      if (p.x < 0 || p.x >= width || p.y < 0 || p.y >= height) break;
      const vRow = floor.visible[p.y];
      const eRow = floor.explored[p.y];
      if (vRow) vRow[p.x] = true;
      if (eRow) eRow[p.x] = true;
      const t = getTile(floor, p.x, p.y);
      if (t === Tile.Wall || t === Tile.Void) break;
    }
  }
}

// ─── Combat ───

function getEffectiveStats(entity: Entity) {
  let attack = entity.stats.attack;
  let defense = entity.stats.defense;
  let speed = entity.stats.speed;
  const maxHp = entity.stats.maxHp;
  let regenBonus = 0;

  for (const item of Object.values(entity.equipment)) {
    if (item?.statBonus) {
      attack += item.statBonus.attack ?? 0;
      defense += item.statBonus.defense ?? 0;
      speed += item.statBonus.speed ?? 0;
      regenBonus += item.statBonus.hp ?? 0;
    }
  }

  return { attack, defense, maxHp, speed, regenBonus };
}

export function getPlayerEffectiveStats(state: GameState) {
  return getEffectiveStats(state.player);
}

function attackEntity(state: GameState, attacker: Entity, defender: Entity) {
  // Monster dodge ability — non-boss monsters can dodge player attacks
  if (!defender.isPlayer && !defender.isBoss && defender.abilities) {
    const dodgeAbility = defender.abilities.find(a => a.type === 'dodge') as Extract<MonsterAbility, { type: 'dodge' }> | undefined;
    if (dodgeAbility && Math.random() < dodgeAbility.chance) {
      addMessage(state, `${defender.name} dodges your attack!`, MSG_COLOR.info);
      return;
    }
  }

  // Mana Shield — mage can negate incoming damage
  if (defender.isPlayer && hasPassive(state, 'Mana Shield') && Math.random() < 0.15) {
    addMessage(state, `Mana Shield absorbs ${attacker.name}'s attack!`, MSG_COLOR.system);
    return;
  }

  const aStats = getEffectiveStats(attacker);
  const dStats = getEffectiveStats(defender);

  let baseDmg = Math.max(1, aStats.attack - Math.floor(dStats.defense * 0.6));

  // Berserker — warrior deals +50% when below 30% HP
  if (attacker.isPlayer && hasPassive(state, 'Berserker') && attacker.stats.hp / attacker.stats.maxHp < 0.3) {
    baseDmg = Math.floor(baseDmg * 1.5);
    addMessage(state, 'Berserker rage!', '#ff6644');
  }

  // Deathless Fury — revenant deals +100% when below 20% HP
  if (attacker.isPlayer && hasPassive(state, 'Deathless Fury') && attacker.stats.hp / attacker.stats.maxHp < 0.2) {
    baseDmg *= 2;
    addMessage(state, 'Deathless Fury!', '#ff4444');
  }

  // Backstab — rogue 25% chance for double damage
  if (attacker.isPlayer && hasPassive(state, 'Backstab') && Math.random() < 0.25) {
    baseDmg *= 2;
    addMessage(state, 'Backstab!', '#ffcc33');
  }

  // Spell Strike — mage 20% chance for +5 bonus magic damage
  if (attacker.isPlayer && hasPassive(state, 'Spell Strike') && Math.random() < 0.2) {
    baseDmg += 5;
    addMessage(state, 'Spell Strike!', '#8855ff');
  }

  // Monster charge attack — bonus damage on hit
  if (!attacker.isPlayer && attacker.abilities) {
    const charge = attacker.abilities.find(a => a.type === 'chargeAttack') as Extract<MonsterAbility, { type: 'chargeAttack' }> | undefined;
    if (charge && Math.random() < charge.chance) {
      baseDmg = Math.floor(baseDmg * charge.multiplier);
      addMessage(state, `${attacker.name} charges with a powerful attack!`, MSG_COLOR.bad);
    }
  }

  // Monster enrage — permanent attack boost at low HP (damage modifier)
  if (!attacker.isPlayer && attacker.abilities && !attacker.isMonsterEnraged) {
    const enrageAbility = attacker.abilities.find(a => a.type === 'enrage') as Extract<MonsterAbility, { type: 'enrage' }> | undefined;
    if (enrageAbility && attacker.stats.hp / attacker.stats.maxHp <= enrageAbility.hpThreshold) {
      attacker.isMonsterEnraged = true;
      attacker.stats.attack = Math.floor(attacker.stats.attack * enrageAbility.atkMultiplier);
      addMessage(state, `${attacker.name} becomes enraged!`, MSG_COLOR.boss);
      // Recalculate damage with the new attack stat
      const newAStats = getEffectiveStats(attacker);
      baseDmg = Math.max(1, newAStats.attack - Math.floor(dStats.defense * 0.6));
    }
  }

  const variance = Math.max(1, Math.floor(baseDmg * 0.3));
  let dmg = clamp(baseDmg + Math.floor(Math.random() * variance * 2) - variance, 1, 999);

  // ── Terrain combat modifiers ──
  const defenderTerrain = getTerrainAt(state.floor, defender.pos.x, defender.pos.y);
  const attackerTerrain = getTerrainAt(state.floor, attacker.pos.x, attacker.pos.y);

  // Lava amplifies fire damage — attacker on lava gets +40% damage with fire weapons, +20% base
  if (attackerTerrain === 'lava') {
    const hasFireWeapon = attacker.equipment?.weapon?.onHitEffect?.type === 'fireball';
    if (hasFireWeapon) {
      dmg = Math.floor(dmg * 1.4);
      addMessage(state, 'Lava empowers your fire attack!', '#ff5511');
    } else {
      dmg = Math.floor(dmg * 1.2);
    }
  }

  // Poison amplifies toxic damage — attacker on poison gets +40% damage with poison weapons, +20% base
  if (attackerTerrain === 'poison') {
    const hasPoisonWeapon = attacker.equipment?.weapon?.onHitEffect?.type === 'poison';
    if (hasPoisonWeapon) {
      dmg = Math.floor(dmg * 1.4);
      addMessage(state, 'Toxic fumes amplify your poisonous strike!', '#44cc22');
    } else {
      dmg = Math.floor(dmg * 1.2);
    }
  }

  // Water amplifies electric/magic attacks — Spell Strike and Thunderbrand benefit
  if (defenderTerrain === 'water') {
    const weaponEffect = attacker.equipment?.weapon?.onHitEffect;
    if (weaponEffect && weaponEffect.type === 'stun') {
      // Electric weapon on water = 2x damage
      dmg = Math.floor(dmg * 2);
      addMessage(state, 'Electricity surges through the water!', '#ffff33');
    } else if (attacker.isPlayer && hasPassive(state, 'Spell Strike')) {
      dmg = Math.floor(dmg * 1.3);
    }
  }

  // Ice makes it hard to dodge — bonus damage
  if (defenderTerrain === 'ice') {
    dmg = Math.floor(dmg * 1.2);
  }

  // Tall grass gives defenders a dodge chance
  if (defenderTerrain === 'tall_grass' && !defender.isPlayer) {
    if (Math.random() < 0.25) {
      addMessage(state, `${defender.name} hides in the tall grass and dodges!`, '#55aa33');
      return;
    }
  }
  // Player also gets dodge bonus in tall grass
  if (defenderTerrain === 'tall_grass' && defender.isPlayer) {
    if (Math.random() < 0.2) {
      addMessage(state, 'You dodge behind the tall grass!', '#55aa33');
      return;
    }
  }

  // Shadow terrain — attacker in shadow gets +30% damage (stealth bonus)
  if (attackerTerrain === 'shadow') {
    dmg = Math.floor(dmg * 1.3);
  }

  // Holy ground — weakens undead-type attackers (Skeleton, Zombie, Wraith, Vampire, Lich)
  const undeadNames = ['Skeleton', 'Zombie', 'Wraith', 'Vampire', 'Vampire Lord', 'Lich Emperor'];
  if (attackerTerrain === 'holy' && undeadNames.includes(attacker.name)) {
    dmg = Math.floor(dmg * 0.5);
    addMessage(state, `${attacker.name} is weakened by holy ground!`, '#ffdd66');
  }

  // Mud slows — reduce defender's effective speed (makes them easier to hit)
  // Represented as a small damage bonus
  if (defenderTerrain === 'mud') {
    dmg = Math.floor(dmg * 1.1);
  }

  // Frozen terrain — defender takes +15% damage, slowed
  if (defenderTerrain === 'frozen') {
    dmg = Math.floor(dmg * 1.15);
  }

  // Crystal terrain — amplifies magic attacks (+25% for mage/magic weapons)
  if (attackerTerrain === 'crystal' || defenderTerrain === 'crystal') {
    const hasMagicWeapon = attacker.equipment?.weapon?.onHitEffect?.type === 'fireball';
    if (hasMagicWeapon || (attacker.isPlayer && hasPassive(state, 'Spell Strike'))) {
      dmg = Math.floor(dmg * 1.25);
    }
  }

  // Void rift — attacker on void rift deals +50% damage
  if (attackerTerrain === 'void_rift') {
    dmg = Math.floor(dmg * 1.5);
  }

  // Brimstone — attacker on brimstone gets +50% fire weapon damage, +25% base
  if (attackerTerrain === 'brimstone') {
    const hasFireWeapon = attacker.equipment?.weapon?.onHitEffect?.type === 'fireball';
    if (hasFireWeapon) {
      dmg = Math.floor(dmg * 1.5);
      addMessage(state, 'Brimstone fuels your fire attack!', '#ff8833');
    } else {
      dmg = Math.floor(dmg * 1.25);
    }
  }

  // Spore cloud — attacker on spore gets +35% poison weapon damage, +15% base
  if (attackerTerrain === 'spore') {
    const hasPoisonWeapon = attacker.equipment?.weapon?.onHitEffect?.type === 'poison';
    if (hasPoisonWeapon) {
      dmg = Math.floor(dmg * 1.35);
      addMessage(state, 'Spores amplify your toxic strike!', '#88cc44');
    } else {
      dmg = Math.floor(dmg * 1.15);
    }
  }

  // Thick Skin — warrior takes 1 less damage
  if (defender.isPlayer && hasPassive(state, 'Thick Skin')) {
    dmg = Math.max(1, dmg - 1);
  }

  defender.stats.hp -= dmg;

  // Track run stats
  if (attacker.isPlayer) {
    state.runStats.damageDealt += dmg;
    addMessage(state, `You hit ${defender.name} for ${dmg} damage!`, MSG_COLOR.good);
  } else {
    state.runStats.damageTaken += dmg;
    addMessage(state, `${attacker.name} hits you for ${dmg} damage!`, MSG_COLOR.bad);
  }

  // Environmental attack — monster creates terrain around the defender on hit
  if (!attacker.isPlayer && attacker.terrainOnHit && Math.random() < attacker.terrainOnHit.chance) {
    const { terrain, radius } = attacker.terrainOnHit;
    const count = Math.floor(Math.random() * 3) + 2; // 2-4 tiles
    const placed = placeTerrain(state, defender.pos.x, defender.pos.y, terrain, radius, count);
    if (placed > 0) {
      const terrainNames: Record<string, string> = {
        lava: 'fire', water: 'electricity', poison: 'toxic pools',
        ice: 'frost', shadow: 'shadow', mud: 'mud',
        brimstone: 'brimstone', void_rift: 'void energy', spore: 'spores',
        crystal: 'crystals', frozen: 'permafrost', holy: 'holy light',
        tall_grass: 'vines', mycelium: 'fungus',
      };
      addMessage(state, `${attacker.name} spreads ${terrainNames[terrain] ?? terrain} around you!`, MSG_COLOR.bad);
    }
  }

  // Monster innate on-hit abilities — apply status effects to the defender
  if (!attacker.isPlayer && attacker.abilities && defender.stats.hp > 0) {
    if (!defender.statusEffects) defender.statusEffects = [];
    for (const ability of attacker.abilities) {
      switch (ability.type) {
        case 'poisonAttack':
          if (Math.random() < ability.chance && !defender.statusEffects.some(e => e.type === 'poison')) {
            defender.statusEffects.push({ type: 'poison', turnsRemaining: ability.turns, damage: ability.damage });
            addMessage(state, `${attacker.name} poisons you!`, '#33cc11');
          }
          break;
        case 'stunAttack':
          if (Math.random() < ability.chance && !defender.statusEffects.some(e => e.type === 'stun')) {
            defender.statusEffects.push({ type: 'stun', turnsRemaining: 1 });
            addMessage(state, `${attacker.name} stuns you!`, '#ffff44');
          }
          break;
        case 'bleedAttack':
          if (Math.random() < ability.chance && !defender.statusEffects.some(e => e.type === 'bleed')) {
            defender.statusEffects.push({ type: 'bleed', turnsRemaining: ability.turns, damage: ability.damage });
            addMessage(state, `${attacker.name} makes you bleed!`, '#ff4444');
          }
          break;
        case 'freezeAttack':
          if (Math.random() < ability.chance && !defender.statusEffects.some(e => e.type === 'freeze')) {
            defender.statusEffects.push({ type: 'freeze', turnsRemaining: ability.turns });
            addMessage(state, `${attacker.name} freezes you!`, '#88ccff');
          }
          break;
        case 'drainLife': {
          if (Math.random() < ability.chance) {
            const healAmt = Math.floor(dmg * ability.percent / 100);
            if (healAmt > 0) {
              attacker.stats.hp = Math.min(attacker.stats.maxHp, attacker.stats.hp + healAmt);
              addMessage(state, `${attacker.name} drains ${healAmt} HP from you!`, '#cc2244');
            }
          }
          break;
        }
        default:
          break;
      }
    }
  }

  // Survival Instinct — ranger auto-heals once per floor when near death
  if (defender.isPlayer && defender.stats.hp > 0 && defender.stats.hp <= defender.stats.maxHp * 0.15
      && hasPassive(state, 'Survival Instinct') && !state.survivalUsedThisFloor) {
    const healAmt = Math.floor(defender.stats.maxHp * 0.5);
    defender.stats.hp = Math.min(defender.stats.maxHp, defender.stats.hp + healAmt);
    state.survivalUsedThisFloor = true;
    addMessage(state, `Survival Instinct! Healed ${healAmt} HP!`, '#33cc66');
  }

  // Undying Will — necromancer survives a fatal blow once per floor with 1 HP
  if (defender.isPlayer && defender.stats.hp <= 0 && hasPassive(state, 'Undying Will') && !state.undyingWillUsedThisFloor) {
    defender.stats.hp = 1;
    state.undyingWillUsedThisFloor = true;
    addMessage(state, 'Undying Will! You cling to life!', '#aa44dd');
  }

  // Beyond Death — revenant gets a free revive per floor
  if (defender.isPlayer && defender.stats.hp <= 0 && hasPassive(state, 'Beyond Death') && !state.beyondDeathUsedThisFloor) {
    defender.stats.hp = Math.floor(defender.stats.maxHp * 0.3);
    state.beyondDeathUsedThisFloor = true;
    addMessage(state, 'Beyond Death! You rise again!', '#ff4444');
  }

  if (defender.stats.hp <= 0) {
    defender.isDead = true;
    if (defender.isPlayer) {
      addMessage(state, 'You have died!', MSG_COLOR.bad);
      state.gameOver = true;
    } else {
      addMessage(state, `${defender.name} is defeated!`, MSG_COLOR.good);
      state.score += defender.xp;
      state.runStats.kills++;
      state.runStats.monsterKills[defender.name] = (state.runStats.monsterKills[defender.name] ?? 0) + 1;
      gainXP(state, defender.xp);

      // Boss kill — drop guaranteed loot and a key, open the boss gate
      if (defender.isBoss) {
        state.runStats.bossesKilled++;
        state.bossesDefeatedThisRun.push(defender.name);
        addMessage(state, `BOSS DEFEATED: ${defender.name}!`, MSG_COLOR.boss);

        // Drop guaranteed loot (check base bosses + zone bosses)
        const zoneBosses = ZONE_BOSSES[state.zone] ?? [];
        const allBossDefs = [...BOSS_DEFS, ...zoneBosses];
        const bossDef = allBossDefs.find(b => b.name === defender.name);
        if (bossDef?.guaranteedLoot) {
          const template = findItemTemplate(bossDef.guaranteedLoot) ?? findZoneBossLoot(bossDef.guaranteedLoot);
          if (template) {
            const lootItem = { ...template, id: uid() };
            state.items.push({ id: uid(), pos: { ...defender.pos }, item: lootItem });
            addMessage(state, `${defender.name} dropped ${lootItem.name}!`, MSG_COLOR.loot);
          }
        }

        // Drop a key for any locked vault on this floor
        const vault = state.floor.rooms.find(r => r.isVault && r.keyColor);
        if (vault?.keyColor) {
          const cfg = KEY_COLORS[vault.keyColor];
          state.keysHeld[vault.keyColor]++;
          addMessage(state, `${defender.name} dropped ${cfg.name}!`, MSG_COLOR.key);
        }

        // Open boss gates on the floor
        for (let fy = 0; fy < state.floor.height; fy++) {
          for (let fx = 0; fx < state.floor.width; fx++) {
            if (getTile(state.floor, fx, fy) === Tile.BossGate) {
              const tileRow = state.floor.tiles[fy];
              if (tileRow) tileRow[fx] = Tile.Door;
            }
          }
        }
      }

      // Life Drain — necromancer heals 3 HP on every kill
      if (attacker.isPlayer && hasPassive(state, 'Life Drain')) {
        const healAmt = Math.min(3, attacker.stats.maxHp - attacker.stats.hp);
        if (healAmt > 0) {
          attacker.stats.hp += healAmt;
          addMessage(state, `Life Drain! +${healAmt} HP`, '#aa44dd');
        }
      }

      // Soul Siphon — revenant 10% chance to fully restore HP on kill
      if (attacker.isPlayer && hasPassive(state, 'Soul Siphon') && Math.random() < 0.1) {
        attacker.stats.hp = attacker.stats.maxHp;
        addMessage(state, 'Soul Siphon! Full HP restored!', '#ff4444');
      }

      // Regular monster loot
      if (!defender.isBoss) {
        const allDefs = [...MONSTER_DEFS, ...getNecropolisMonsters(getNecropolisState().communalDeaths)];
        const def = allDefs.find((m) => m.name === defender.name);
        const lootBonus = hasPassive(state, 'Scavenger') ? 0.2 : 0;
        if (def && Math.random() < def.lootChance + lootBonus) {
          const loot = randomItem(state.floorNumber, state.zone);
          state.items.push({ id: uid(), pos: { ...defender.pos }, item: loot });
          addMessage(state, `${defender.name} dropped ${loot.name}!`, MSG_COLOR.loot);
        }
      }
    }
  }
}

// ─── XP & Leveling ───

function gainXP(state: GameState, amount: number) {
  const effectiveAmount = Math.floor(amount * (state.xpMultiplier ?? 1.0));
  state.player.xp += effectiveAmount;
  addMessage(state, `+${effectiveAmount} XP`, MSG_COLOR.xp);

  const nextLevelIdx = state.player.level;
  const threshold = XP_PER_LEVEL[nextLevelIdx];
  if (threshold !== undefined && state.player.xp >= threshold) {
    const classDef = getClassDef(state.playerClass);
    state.player.level++;
    state.player.stats.maxHp += classDef.levelBonusHp;
    state.player.stats.hp = state.player.stats.maxHp;
    state.player.stats.attack += classDef.levelBonusAtk;
    state.player.stats.defense += classDef.levelBonusDef;

    addMessage(state, `Level up! You are now level ${state.player.level}! HP fully restored!`, MSG_COLOR.xp);

    // Check for newly unlocked passives
    for (const passive of classDef.passives) {
      if (passive.unlockLevel === state.player.level) {
        addMessage(state, `New passive unlocked: ${passive.name} - ${passive.description}`, MSG_COLOR.system);

        // Quick Feet — permanent speed boost on unlock
        if (passive.name === 'Quick Feet') {
          state.player.stats.speed += 3;
        }
      }
    }
  }
}

// ─── Item Use ───

export function useItem(state: GameState, itemIndex: number): boolean {
  const item = state.player.inventory[itemIndex];
  if (!item) return false;

  if (item.type === 'potion') {
    state.runStats.potionsUsed++;
    let healAmt = 0;
    if (item.name === 'Health Potion') healAmt = 15;
    else if (item.name === 'Greater Health Potion') healAmt = 30;
    else if (item.name === 'Strength Potion') {
      state.player.stats.attack += 2;
      addMessage(state, 'You feel stronger!', MSG_COLOR.good);
      state.player.inventory.splice(itemIndex, 1);
      return true;
    }
    if (healAmt > 0) {
      const eStats = getEffectiveStats(state.player);
      const healed = Math.min(healAmt, eStats.maxHp - state.player.stats.hp);
      state.player.stats.hp += healed;
      addMessage(state, `Healed ${healed} HP!`, MSG_COLOR.good);
    }
    state.player.inventory.splice(itemIndex, 1);
    return true;
  }

  if (item.type === 'food') {
    state.runStats.foodEaten++;
    const foragerBonus = hasPassive(state, 'Forager') ? 1.5 : 1;
    const hungerRestore = Math.floor(item.value * foragerBonus);
    const restored = Math.min(hungerRestore, state.hunger.max - state.hunger.current);
    state.hunger.current += restored;

    // Food also heals a small amount of HP
    const healAmt = Math.floor(hungerRestore * 0.2);
    const eStats = getEffectiveStats(state.player);
    const healed = Math.min(healAmt, eStats.maxHp - state.player.stats.hp);
    state.player.stats.hp += healed;

    if (healed > 0) {
      addMessage(state, `Ate ${item.name}. +${restored} fullness, +${healed} HP.`, MSG_COLOR.good);
    } else {
      addMessage(state, `Ate ${item.name}. +${restored} fullness.`, MSG_COLOR.good);
    }
    state.player.inventory.splice(itemIndex, 1);
    return true;
  }

  if (item.type === 'scroll') {
    state.runStats.scrollsUsed++;
    if (item.name === 'Scroll of Mapping') {
      for (let y = 0; y < state.floor.height; y++) {
        for (let x = 0; x < state.floor.width; x++) {
          if (getTile(state.floor, x, y) !== Tile.Void) {
            const row = state.floor.explored[y];
            if (row) row[x] = true;
          }
        }
      }
      addMessage(state, 'The dungeon map is revealed!', MSG_COLOR.system);
    } else if (item.name === 'Scroll of Teleport') {
      const room = state.floor.rooms[Math.floor(Math.random() * state.floor.rooms.length)];
      if (room) {
        state.player.pos = { x: room.centerX, y: room.centerY };
        addMessage(state, 'You teleport to a new location!', MSG_COLOR.system);
        updateFOV(state);
      }
    } else if (item.name === 'Scroll of Greater Enchant') {
      const weapon = state.player.equipment.weapon;
      if (weapon) {
        if (!weapon.statBonus) weapon.statBonus = {};
        weapon.statBonus.attack = (weapon.statBonus.attack ?? 0) + 4;
        addMessage(state, `${weapon.name} glows brightly! +4 attack!`, '#ffaa00');
      } else {
        addMessage(state, 'You need a weapon equipped to use this scroll.', MSG_COLOR.bad);
        return false;
      }
    } else if (item.name === 'Scroll of Invulnerability') {
      // Fully restore HP and grant a massive temporary defense boost
      state.player.stats.hp = state.player.stats.maxHp;
      state.player.stats.defense += 20;
      addMessage(state, 'A golden shield surrounds you! Full HP and +20 defense!', '#ffffff');
    }
    state.player.inventory.splice(itemIndex, 1);
    return true;
  }

  return false;
}

export function equipItem(state: GameState, itemIndex: number): boolean {
  const item = state.player.inventory[itemIndex];
  if (!item || !item.equipSlot) return false;

  const slot = item.equipSlot;
  const current = state.player.equipment[slot];

  if (current) {
    state.player.inventory.push(current);
    addMessage(state, `Unequipped ${current.name}`, MSG_COLOR.info);
  }

  state.player.equipment[slot] = item;
  state.player.inventory.splice(itemIndex, 1);

  if (item.statBonus?.maxHp) {
    state.player.stats.maxHp += item.statBonus.maxHp;
    state.player.stats.hp += item.statBonus.maxHp;
  }

  addMessage(state, `Equipped ${item.name}`, MSG_COLOR.good);
  return true;
}

export function unequipItem(state: GameState, slot: EquipSlot): boolean {
  const item = state.player.equipment[slot];
  if (!item) return false;

  if (state.player.inventory.length >= 20) {
    addMessage(state, 'Inventory full!', MSG_COLOR.bad);
    return false;
  }

  if (item.statBonus?.maxHp) {
    state.player.stats.maxHp -= item.statBonus.maxHp;
    state.player.stats.hp = Math.min(state.player.stats.hp, state.player.stats.maxHp);
  }

  delete state.player.equipment[slot];
  state.player.inventory.push(item);
  addMessage(state, `Unequipped ${item.name}`, MSG_COLOR.info);
  return true;
}

export function dropItem(state: GameState, itemIndex: number): boolean {
  const item = state.player.inventory[itemIndex];
  if (!item) return false;

  state.items.push({
    id: uid(),
    pos: { ...state.player.pos },
    item,
  });
  state.player.inventory.splice(itemIndex, 1);
  addMessage(state, `Dropped ${item.name}`, MSG_COLOR.info);
  return true;
}

// ─── Terrain Step Effects ───

function applyTerrainStepEffects(state: GameState, entity: Entity) {
  const terrain = getTerrainAt(state.floor, entity.pos.x, entity.pos.y);
  if (!terrain) return;

  switch (terrain) {
    case 'lava': {
      if (entity.isPlayer) {
        addMessage(state, '[Lava] Heat radiates through you. Fire attacks deal +40% damage here!', '#ff5511');
      }
      break;
    }
    case 'poison': {
      if (entity.isPlayer) {
        addMessage(state, '[Poison] Toxic fumes empower your strikes. Poison damage +40% here!', '#44cc22');
      }
      break;
    }
    case 'ice': {
      if (entity.isPlayer) {
        if (Math.random() < 0.15) {
          addMessage(state, '[Ice] You slip on the frozen ground!', '#88ddff');
        } else {
          addMessage(state, '[Ice] The ground is slick with frost. Enemies here take extra damage.', '#88ddff');
        }
      }
      break;
    }
    case 'holy': {
      if (entity.isPlayer) {
        const heal = Math.min(2, entity.stats.maxHp - entity.stats.hp);
        if (heal > 0) {
          entity.stats.hp += heal;
          addMessage(state, `[Holy Ground] Warm light soothes you. +${heal} HP. Undead beware.`, '#ffdd66');
        } else {
          addMessage(state, '[Holy Ground] Sacred energy fills this place. Undead are weakened here.', '#ffdd66');
        }
      }
      break;
    }
    case 'water': {
      if (entity.isPlayer) {
        addMessage(state, '[Water] You wade through shallow water. Electric attacks are amplified here.', '#3388cc');
      }
      break;
    }
    case 'mud': {
      if (entity.isPlayer) {
        addMessage(state, '[Mud] Thick mud slows your movement. Enemies here are easier to hit.', '#8a6633');
      }
      break;
    }
    case 'tall_grass': {
      if (entity.isPlayer) {
        addMessage(state, '[Tall Grass] Dense foliage provides cover. Dodge chance increased for all.', '#55aa33');
      }
      break;
    }
    case 'shadow': {
      if (entity.isPlayer) {
        addMessage(state, '[Shadow] Darkness surrounds you. Attacks from here deal +30% damage.', '#554477');
      }
      break;
    }
    case 'frozen': {
      if (entity.isPlayer) {
        if (Math.random() < 0.2) {
          addMessage(state, '[Permafrost] The ground is frozen solid. You slip!', '#aaeeff');
        } else {
          addMessage(state, '[Permafrost] Bitter cold seeps from below. Enemies are slowed here.', '#aaeeff');
        }
      }
      break;
    }
    case 'spore': {
      if (entity.isPlayer) {
        addMessage(state, '[Spore Cloud] Toxic spores cling to your weapon. Nature/poison damage +35% here!', '#88cc44');
      }
      break;
    }
    case 'brimstone': {
      if (entity.isPlayer) {
        addMessage(state, '[Brimstone] Sulfurous energy surges through you. Fire damage +50% here!', '#ff8833');
      }
      break;
    }
    case 'crystal': {
      if (entity.isPlayer) {
        addMessage(state, '[Crystal Floor] Arcane energy hums beneath you. Magic attacks +25% here!', '#cc88ff');
      }
      break;
    }
    case 'void_rift': {
      if (entity.isPlayer) {
        addMessage(state, '[Void Rift] Reality warps around you. All attacks deal +50% damage here!', '#7733cc');
      }
      break;
    }
    case 'mycelium': {
      if (entity.isPlayer) {
        // Small heal from mycelium network
        const heal = Math.min(1, entity.stats.maxHp - entity.stats.hp);
        if (heal > 0) {
          entity.stats.hp += heal;
          addMessage(state, `[Mycelium] The fungal network nourishes you. +${heal} HP.`, '#aa8844');
        } else {
          addMessage(state, '[Mycelium] A living fungal carpet connects the ground.', '#aa8844');
        }
      }
      break;
    }
  }
}

// ─── Movement & Turns ───

export function movePlayer(state: GameState, dx: number, dy: number): boolean {
  if (state.gameOver) return false;

  // Stun/freeze — player cannot move, but turn still passes
  if (state.player.statusEffects?.some(e => e.type === 'stun' || e.type === 'freeze')) {
    processTurn(state);
    return true;
  }

  const nx = state.player.pos.x + dx;
  const ny = state.player.pos.y + dy;

  if (nx < 0 || nx >= state.floor.width || ny < 0 || ny >= state.floor.height) return false;

  const tile = getTile(state.floor, nx, ny);

  // Locked door — requires a matching key
  if (tile === Tile.LockedDoor) {
    const vaultRoom = state.floor.rooms.find(r => r.isVault &&
      nx >= r.x - 1 && nx <= r.x + r.w && ny >= r.y - 1 && ny <= r.y + r.h);
    const keyColor = vaultRoom?.keyColor;
    if (keyColor && state.keysHeld[keyColor] > 0) {
      state.keysHeld[keyColor]--;
      state.runStats.keysUsed++;
      // Replace locked door with normal floor
      const row = state.floor.tiles[ny];
      if (row) row[nx] = Tile.Door;
      addMessage(state, `Used ${KEY_COLORS[keyColor].name} to unlock the door!`, MSG_COLOR.key);
      // Don't move into the tile this turn — just unlock it
      processTurn(state);
      return true;
    } else {
      const colorName = keyColor ? KEY_COLORS[keyColor].name : 'a key';
      addMessage(state, `The door is locked. You need ${colorName}.`, MSG_COLOR.bad);
      return false;
    }
  }

  // Boss gate — blocked until the boss in the arena is dead
  if (tile === Tile.BossGate) {
    const arena = state.floor.rooms.find(r => r.isBossArena);
    if (arena) {
      const bossAlive = state.monsters.some(m => !m.isDead && m.isBoss);
      if (bossAlive) {
        addMessage(state, 'A powerful presence blocks this gate. Defeat the boss!', MSG_COLOR.boss);
        return false;
      }
      // Boss defeated — open the gate
      const row = state.floor.tiles[ny];
      if (row) row[nx] = Tile.Door;
      addMessage(state, 'The boss gate crumbles open!', MSG_COLOR.good);
    }
  }

  // Check for map mercenary at target
  const mapMerc = state.mapMercenaries?.find((m) => !m.hired && m.pos.x === nx && m.pos.y === ny);
  if (mapMerc) {
    state.pendingMercenary = mapMerc.id;
    addMessage(state, 'A mercenary offers their services...', MSG_COLOR.merc);
    return true;
  }

  // Check for NPC at target
  const npc = state.npcs.find((n) => !n.talked && n.pos.x === nx && n.pos.y === ny);
  if (npc) {
    state.pendingNPC = npc.id;
    addMessage(state, 'You encounter someone...', MSG_COLOR.system);
    return true;
  }

  const monster = state.monsters.find((m) => !m.isDead && m.pos.x === nx && m.pos.y === ny);
  if (monster) {
    attackEntity(state, state.player, monster);
    processTurn(state);
    return true;
  }

  if (!isWalkableTile(tile)) return false;

  state.player.pos.x = nx;
  state.player.pos.y = ny;

  // ── Terrain step effects ──
  applyTerrainStepEffects(state, state.player);

  const itemsHere = state.items.filter((i) => i.pos.x === nx && i.pos.y === ny);
  for (const mi of itemsHere) {
    if (mi.item.type === 'gold') {
      state.score += mi.item.value;
      state.runStats.goldEarned += mi.item.value;
      addMessage(state, `Picked up ${mi.item.value} gold!`, MSG_COLOR.loot);
    } else if (mi.item.type === 'key' && mi.item.keyColor) {
      // Keys go into keysHeld, not inventory
      state.keysHeld[mi.item.keyColor]++;
      addMessage(state, `Picked up ${mi.item.name}!`, MSG_COLOR.key);
    } else {
      if (state.player.inventory.length < 20) {
        state.player.inventory.push(mi.item);
        state.runStats.itemsFound++;
        addMessage(state, `Picked up ${mi.item.name}`, MSG_COLOR.loot);
      } else {
        addMessage(state, `Inventory full! Can't pick up ${mi.item.name}`, MSG_COLOR.bad);
        continue;
      }
    }
    state.items = state.items.filter((i) => i.id !== mi.id);
  }

  // Check if player is on shop tile
  if (state.shop && nx === state.shop.pos.x && ny === state.shop.pos.y && state.shop.stock.length > 0) {
    addMessage(state, 'A shopkeeper! Browse their wares.', MSG_COLOR.system);
  }

  if (tile === Tile.StairsDown) {
    descend(state);
    return true;
  }

  processTurn(state);
  return true;
}

export function handleTapMove(state: GameState, targetX: number, targetY: number): boolean {
  if (state.gameOver) return false;

  const px = state.player.pos.x;
  const py = state.player.pos.y;

  if (targetX === px && targetY === py) return false;

  const dx = targetX - px;
  const dy = targetY - py;
  if (Math.abs(dx) <= 1 && Math.abs(dy) <= 1) {
    return movePlayer(state, dx, dy);
  }

  const isWalkable = (x: number, y: number) => {
    if (x < 0 || x >= state.floor.width || y < 0 || y >= state.floor.height) return false;
    if (state.monsters.some((m) => !m.isDead && m.pos.x === x && m.pos.y === y)) return false;
    return isWalkableTile(getTile(state.floor, x, y));
  };

  const next = findPath(state.player.pos, { x: targetX, y: targetY }, isWalkable);
  if (next) {
    return movePlayer(state, next.x - px, next.y - py);
  }

  return false;
}

// ─── Monster AI ───

function processBossAbility(state: GameState, boss: Entity, ability: BossAbility): boolean {
  switch (ability.type) {
    case 'summon': {
      const allDefs = [...MONSTER_DEFS, ...getNecropolisMonsters(getNecropolisState().communalDeaths)];
      const summonDef = allDefs.find(m => m.name === ability.monsterName);
      if (!summonDef) return false;
      let summoned = 0;
      for (let i = 0; i < ability.count; i++) {
        // Spawn near the boss
        for (let attempt = 0; attempt < 20; attempt++) {
          const sx = boss.pos.x + Math.floor(Math.random() * 5) - 2;
          const sy = boss.pos.y + Math.floor(Math.random() * 5) - 2;
          if (sx < 0 || sx >= state.floor.width || sy < 0 || sy >= state.floor.height) continue;
          if (!isWalkableTile(getTile(state.floor, sx, sy))) continue;
          if (state.monsters.some(m => !m.isDead && m.pos.x === sx && m.pos.y === sy)) continue;
          if (sx === state.player.pos.x && sy === state.player.pos.y) continue;
          state.monsters.push({
            id: uid(), pos: { x: sx, y: sy }, name: summonDef.name,
            char: summonDef.char, color: summonDef.color,
            stats: { ...summonDef.stats }, xp: summonDef.xpValue,
            level: state.floorNumber, inventory: [], equipment: {},
            isPlayer: false, isDead: false,
          });
          summoned++;
          break;
        }
      }
      if (summoned > 0) {
        addMessage(state, `${boss.name} summons ${summoned} ${ability.monsterName}${summoned > 1 ? 's' : ''}!`, MSG_COLOR.boss);
      }
      return summoned > 0;
    }
    case 'rage': {
      const hpPct = boss.stats.hp / boss.stats.maxHp;
      if (hpPct <= ability.hpThreshold && !boss.isEnraged) {
        boss.isEnraged = true;
        boss.stats.attack = Math.floor(boss.stats.attack * ability.atkMultiplier);
        addMessage(state, `${boss.name} enters a rage! Attack power surges!`, MSG_COLOR.boss);
        return true;
      }
      return false;
    }
    case 'heal': {
      if (boss.stats.hp < boss.stats.maxHp) {
        const healed = Math.min(ability.amount, boss.stats.maxHp - boss.stats.hp);
        boss.stats.hp += healed;
        addMessage(state, `${boss.name} heals for ${healed} HP!`, MSG_COLOR.boss);
        return true;
      }
      return false;
    }
    case 'aoe': {
      const dist = manhattan(boss.pos, state.player.pos);
      if (dist <= ability.radius) {
        state.player.stats.hp -= ability.damage;
        addMessage(state, `${boss.name}'s area attack hits you for ${ability.damage} damage!`, MSG_COLOR.boss);
        state.runStats.damageTaken += ability.damage;
        if (state.player.stats.hp <= 0) {
          state.player.isDead = true;
          state.player.stats.hp = 0;
          addMessage(state, 'You have been slain!', MSG_COLOR.bad);
          state.gameOver = true;
        }
        // Also damage mercenaries in range
        for (const merc of state.mercenaries) {
          if (!merc.isDead && manhattan(boss.pos, merc.pos) <= ability.radius) {
            merc.stats.hp -= ability.damage;
            if (merc.stats.hp <= 0) {
              merc.isDead = true;
              addMessage(state, `${merc.mercName ?? merc.name} is slain by the blast!`, MSG_COLOR.bad);
            }
          }
        }
        return true;
      }
      return false;
    }
    case 'teleport': {
      // Teleport near the player
      for (let attempt = 0; attempt < 30; attempt++) {
        const tx = state.player.pos.x + Math.floor(Math.random() * 5) - 2;
        const ty = state.player.pos.y + Math.floor(Math.random() * 5) - 2;
        if (tx < 0 || tx >= state.floor.width || ty < 0 || ty >= state.floor.height) continue;
        if (!isWalkableTile(getTile(state.floor, tx, ty))) continue;
        if (state.monsters.some(m => m !== boss && !m.isDead && m.pos.x === tx && m.pos.y === ty)) continue;
        if (tx === state.player.pos.x && ty === state.player.pos.y) continue;
        boss.pos.x = tx;
        boss.pos.y = ty;
        addMessage(state, `${boss.name} teleports nearby!`, MSG_COLOR.boss);
        return true;
      }
      return false;
    }
    case 'terrain_attack': {
      const dist = manhattan(boss.pos, state.player.pos);
      if (dist <= ability.radius + 2) {
        const placed = placeTerrain(state, state.player.pos.x, state.player.pos.y, ability.terrain, ability.radius, ability.count);
        if (placed > 0) {
          const terrainNames: Record<string, string> = {
            lava: 'fire', water: 'electricity', poison: 'toxic pools',
            ice: 'frost', shadow: 'darkness', mud: 'mud',
            brimstone: 'brimstone', void_rift: 'void rifts', spore: 'spores',
            crystal: 'crystals', frozen: 'permafrost', holy: 'holy light',
            tall_grass: 'vines', mycelium: 'fungus',
          };
          addMessage(state, `${boss.name} engulfs the area in ${terrainNames[ability.terrain] ?? ability.terrain}!`, MSG_COLOR.boss);
          return true;
        }
      }
      return false;
    }
    case 'multi': {
      let used = false;
      for (const sub of ability.abilities) {
        if (processBossAbility(state, boss, sub)) {
          used = true;
          break; // Only use one ability per turn
        }
      }
      return used;
    }
  }
}

function processMonsterTurn(state: GameState, monster: Entity) {
  if (monster.isDead) return;

  const dist = manhattan(monster.pos, state.player.pos);
  if (dist > 10) return;

  // Boss special abilities
  if (monster.isBoss && monster.bossAbility && dist <= 6) {
    // Decrement cooldown
    if (monster.bossAbilityCooldown && monster.bossAbilityCooldown > 0) {
      monster.bossAbilityCooldown--;
    } else {
      // Try to use ability
      const used = processBossAbility(state, monster, monster.bossAbility);
      if (used) {
        // Set cooldown based on ability type
        const cd = monster.bossAbility.type === 'multi' ? 3 :
          ('cooldown' in monster.bossAbility ? (monster.bossAbility as { cooldown: number }).cooldown : 4);
        monster.bossAbilityCooldown = cd;
        if (state.gameOver) return;
        // Boss still gets to move/attack after some abilities
        if (monster.bossAbility.type === 'rage') {
          // Rage doesn't consume the turn
        } else {
          return; // Ability used, turn spent
        }
      }
    }
  }

  // Monster innate passive abilities — self-heal and call-for-help
  if (monster.abilities && !monster.isBoss) {
    if (!monster.abilityCooldowns) monster.abilityCooldowns = {};

    // Decrement ability cooldowns
    for (const key of Object.keys(monster.abilityCooldowns)) {
      if (monster.abilityCooldowns[key]! > 0) monster.abilityCooldowns[key]!--;
    }

    for (const ability of monster.abilities) {
      if (ability.type === 'selfHeal') {
        const cdKey = 'selfHeal';
        if (monster.stats.hp / monster.stats.maxHp <= ability.hpThreshold
            && (monster.abilityCooldowns[cdKey] ?? 0) <= 0) {
          monster.stats.hp = Math.min(monster.stats.maxHp, monster.stats.hp + ability.amount);
          monster.abilityCooldowns[cdKey] = ability.cooldown;
          addMessage(state, `${monster.name} heals itself!`, MSG_COLOR.bad);
        }
      }
      if (ability.type === 'callForHelp' && dist <= 6) {
        const cdKey = 'callForHelp';
        if (Math.random() < ability.chance && (monster.abilityCooldowns[cdKey] ?? 0) <= 0) {
          // Spawn a helper monster near this monster
          const allDefs = [...MONSTER_DEFS];
          const helperDef = allDefs.find(m => m.name === ability.monsterName);
          if (helperDef) {
            // Find a walkable spot near the calling monster
            const offsets = [[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[1,1],[-1,1],[1,-1]];
            for (const [dx, dy] of offsets) {
              const nx = monster.pos.x + dx!;
              const ny = monster.pos.y + dy!;
              if (nx >= 0 && nx < state.floor.width && ny >= 0 && ny < state.floor.height
                  && isWalkableTile(getTile(state.floor, nx, ny))
                  && !state.monsters.some(m => !m.isDead && m.pos.x === nx && m.pos.y === ny)
                  && !(state.player.pos.x === nx && state.player.pos.y === ny)) {
                const scale = 1 + (state.floorNumber - helperDef.minFloor) * 0.1;
                const helper: Entity = {
                  id: uid(),
                  pos: { x: nx, y: ny },
                  name: helperDef.name,
                  char: helperDef.char,
                  color: helperDef.color,
                  stats: {
                    hp: Math.round(helperDef.stats.hp * scale),
                    maxHp: Math.round(helperDef.stats.maxHp * scale),
                    attack: Math.round(helperDef.stats.attack * scale),
                    defense: Math.round(helperDef.stats.defense * scale),
                    speed: helperDef.stats.speed,
                  },
                  xp: helperDef.xpValue,
                  level: state.floorNumber,
                  inventory: [],
                  equipment: {},
                  isPlayer: false,
                  isDead: false,
                };
                if (helperDef.terrainOnHit) helper.terrainOnHit = helperDef.terrainOnHit;
                if (helperDef.abilities) helper.abilities = helperDef.abilities;
                state.monsters.push(helper);
                addMessage(state, `${monster.name} calls for help! A ${helperDef.name} appears!`, MSG_COLOR.bad);
                monster.abilityCooldowns[cdKey] = ability.cooldown;
                break;
              }
            }
          }
        }
      }
    }
  }

  if (dist === 1) {
    attackEntity(state, monster, state.player);
    return;
  }

  const isWalkable = (x: number, y: number) => {
    if (x < 0 || x >= state.floor.width || y < 0 || y >= state.floor.height) return false;
    if (x === state.player.pos.x && y === state.player.pos.y) return true;
    if (state.monsters.some((m) => m !== monster && !m.isDead && m.pos.x === x && m.pos.y === y)) return false;
    return isWalkableTile(getTile(state.floor, x, y));
  };

  const next = findPath(monster.pos, state.player.pos, isWalkable, 15);
  if (next) {
    if (next.x === state.player.pos.x && next.y === state.player.pos.y) {
      attackEntity(state, monster, state.player);
    } else {
      monster.pos.x = next.x;
      monster.pos.y = next.y;

      // Terrain effects on monsters — holy ground still hurts undead
      const mTerrain = getTerrainAt(state.floor, monster.pos.x, monster.pos.y);
      if (mTerrain === 'holy') {
        // Undead take damage on holy ground
        const undeadNames = ['Skeleton', 'Zombie', 'Wraith', 'Vampire', 'Vampire Lord', 'Lich Emperor'];
        if (undeadNames.includes(monster.name)) {
          monster.stats.hp -= 3;
          if (monster.stats.hp <= 0) {
            monster.isDead = true;
            addMessage(state, `${monster.name} is destroyed by holy ground!`, '#ffdd66');
            state.score += monster.xp;
            state.runStats.kills++;
            gainXP(state, monster.xp);
          }
        }
      }
      // Lava, poison, brimstone, void_rift, spore are all damage amplifiers — monsters on them hit harder too
    }
  }
}

// ─── Turn processing ───

function processTurn(state: GameState) {
  state.turn++;
  const pStats = getEffectiveStats(state.player);

  // ── Process player status effects ──
  if (state.player.statusEffects && state.player.statusEffects.length > 0) {
    for (const effect of state.player.statusEffects) {
      switch (effect.type) {
        case 'poison':
          if (effect.damage) {
            state.player.stats.hp -= effect.damage;
            addMessage(state, `Poison deals ${effect.damage} damage!`, '#33cc11');
          }
          break;
        case 'bleed':
          if (effect.damage) {
            state.player.stats.hp -= effect.damage;
            addMessage(state, `Bleeding deals ${effect.damage} damage!`, '#ff4444');
          }
          break;
        case 'stun':
          addMessage(state, 'You are stunned and cannot act!', '#ffff44');
          break;
        case 'freeze':
          addMessage(state, 'You are frozen!', '#88ccff');
          break;
      }
      effect.turnsRemaining--;
    }
    // Remove expired effects
    state.player.statusEffects = state.player.statusEffects.filter(e => e.turnsRemaining > 0);

    // Check for death from status effects
    if (state.player.stats.hp <= 0) {
      state.player.isDead = true;
      addMessage(state, 'You have died!', MSG_COLOR.bad);
      state.gameOver = true;
      return;
    }
  }

  // Death Aura — necromancer deals 1 damage to nearby enemies each turn
  if (hasPassive(state, 'Death Aura')) {
    for (const m of state.monsters) {
      if (!m.isDead && manhattan(m.pos, state.player.pos) <= 2) {
        m.stats.hp -= 1;
        if (m.stats.hp <= 0) {
          m.isDead = true;
          addMessage(state, `Death Aura kills ${m.name}!`, '#aa44dd');
          state.score += m.xp;
          state.runStats.kills++;
          state.runStats.monsterKills[m.name] = (state.runStats.monsterKills[m.name] ?? 0) + 1;
          gainXP(state, m.xp);
        }
      }
    }
    state.monsters = state.monsters.filter((m) => !m.isDead);
  }

  // ── Terrain per-turn effects on player ──
  const playerTerrain = getTerrainAt(state.floor, state.player.pos.x, state.player.pos.y);
  // Lava and poison are now damage buffs, not damage sources — no per-turn damage
  if (playerTerrain === 'holy') {
    const heal = Math.min(1, state.player.stats.maxHp - state.player.stats.hp);
    if (heal > 0) {
      state.player.stats.hp += heal;
    }
  }
  // Brimstone, void_rift, and spore are damage amplifiers — no per-turn damage
  if (playerTerrain === 'mycelium') {
    const heal = Math.min(1, state.player.stats.maxHp - state.player.stats.hp);
    if (heal > 0) {
      state.player.stats.hp += heal;
    }
  }

  // Hunger drain — Iron Will slows it by 30%, premium slows it by 50%
  let hungerRate = HUNGER_PER_TURN;
  if (state.premiumActive) hungerRate *= 0.5;
  if (hasPassive(state, 'Iron Will')) hungerRate *= 0.7;
  state.hunger.current = Math.max(0, state.hunger.current - hungerRate);

  if (state.hunger.current <= STARVING_THRESHOLD) {
    state.player.stats.hp -= STARVING_DAMAGE;
    addMessage(state, 'You are starving!', MSG_COLOR.bad);
    if (state.player.stats.hp <= 0) {
      state.player.isDead = true;
      addMessage(state, 'You starved to death!', MSG_COLOR.bad);
      state.gameOver = true;
      return;
    }
  } else if (state.hunger.current <= HUNGER_WARNING && state.turn % 10 === 0) {
    addMessage(state, 'You are getting hungry...', '#e8a844');
  }

  // HP regen only from Amulet of Regen (equipment bonus)
  if (pStats.regenBonus > 0 && state.hunger.current >= REGEN_HUNGER_MIN) {
    const regenRate = Math.max(1, REGEN_INTERVAL - pStats.regenBonus * 2);
    if (state.turn % regenRate === 0 && state.player.stats.hp < pStats.maxHp) {
      state.player.stats.hp = Math.min(pStats.maxHp, state.player.stats.hp + pStats.regenBonus);
    }
  }

  // Mercenary turns — they fight nearby monsters and follow the player
  for (const merc of state.mercenaries) {
    if (merc.isDead) continue;
    processMercenaryTurn(state, merc);
  }
  state.mercenaries = state.mercenaries.filter(m => !m.isDead);

  // Mercenary special: Sera heals the player each turn
  for (const merc of state.mercenaries) {
    if (merc.isDead) continue;
    const mercDef = MERCENARY_DEFS.find(d => d.name === merc.name);
    if (mercDef?.id === 'merc_healer' && state.player.stats.hp < pStats.maxHp) {
      const heal = Math.min(2, pStats.maxHp - state.player.stats.hp);
      state.player.stats.hp += heal;
    }
  }

  // Monster turns — speed comparison determines if a monster acts
  for (const m of state.monsters) {
    // If player is faster, monsters have a chance to skip their turn
    const speedDiff = pStats.speed - m.stats.speed;
    if (speedDiff > 0 && Math.random() < speedDiff * 0.08) {
      continue; // Monster is too slow, skips this turn
    }

    // Taunt: if Garrak is alive, monsters prefer attacking him
    const garrak = state.mercenaries.find(mc => !mc.isDead && mc.name === 'Garrak');
    if (garrak && !m.isBoss && manhattan(m.pos, garrak.pos) <= 1 && Math.random() < 0.6) {
      attackEntity(state, m, garrak);
      if (garrak.stats.hp <= 0) {
        garrak.isDead = true;
        addMessage(state, `${garrak.mercName ?? garrak.name} has fallen!`, MSG_COLOR.bad);
      }
    } else {
      processMonsterTurn(state, m);
    }
    if (state.gameOver) return;
  }

  state.monsters = state.monsters.filter((m) => !m.isDead);
  updateFOV(state);
}

function processMercenaryTurn(state: GameState, merc: Entity) {
  // Find nearest alive monster
  let nearestMonster: Entity | null = null;
  let nearestDist = Infinity;
  for (const m of state.monsters) {
    if (m.isDead) continue;
    const d = manhattan(merc.pos, m.pos);
    if (d < nearestDist) {
      nearestDist = d;
      nearestMonster = m;
    }
  }

  // Attack if adjacent
  if (nearestMonster && nearestDist === 1) {
    const mercDef = MERCENARY_DEFS.find(d => d.name === merc.name);

    // Blade Dancer — double strike
    if (mercDef?.id === 'merc_blade_dancer') {
      mercAttack(state, merc, nearestMonster);
      if (!nearestMonster.isDead) {
        mercAttack(state, merc, nearestMonster);
      }
      return;
    }

    // Berserker — double damage when below 50% HP
    let dmgMult = 1;
    if (mercDef?.id === 'merc_berserker' && merc.stats.hp < merc.stats.maxHp * 0.5) {
      dmgMult = 2;
    }

    // Assassin — 15% instant kill on non-bosses
    if (mercDef?.id === 'merc_assassin' && !nearestMonster.isBoss && Math.random() < 0.15) {
      nearestMonster.isDead = true;
      nearestMonster.stats.hp = 0;
      addMessage(state, `${merc.name} assassinates ${nearestMonster.name}!`, MSG_COLOR.merc);
      state.score += nearestMonster.xp;
      state.runStats.kills++;
      gainXP(state, nearestMonster.xp);
      return;
    }

    mercAttack(state, merc, nearestMonster, dmgMult);

    // War Golem takes half damage passively (handled in attackEntity for defenders)
    return;
  }

  // Move toward nearest monster if close, otherwise follow the player
  const target = (nearestMonster && nearestDist <= 6) ? nearestMonster.pos : state.player.pos;
  const isWalkable = (x: number, y: number) => {
    if (x < 0 || x >= state.floor.width || y < 0 || y >= state.floor.height) return false;
    if (state.monsters.some(m => !m.isDead && m.pos.x === x && m.pos.y === y)) return true;
    if (x === state.player.pos.x && y === state.player.pos.y) return false;
    return isWalkableTile(getTile(state.floor, x, y));
  };

  const next = findPath(merc.pos, target, isWalkable, 10);
  if (next && !(next.x === state.player.pos.x && next.y === state.player.pos.y)) {
    // Don't walk onto monsters
    if (!state.monsters.some(m => !m.isDead && m.pos.x === next.x && m.pos.y === next.y)) {
      merc.pos.x = next.x;
      merc.pos.y = next.y;
    }
  }
}

function mercAttack(state: GameState, merc: Entity, target: Entity, dmgMult = 1) {
  const baseDmg = Math.max(1, merc.stats.attack - Math.floor(target.stats.defense * 0.5));
  const variance = Math.max(1, Math.floor(baseDmg * 0.2));
  const dmg = clamp((baseDmg + Math.floor(Math.random() * variance * 2) - variance) * dmgMult, 1, 999);

  target.stats.hp -= dmg;
  addMessage(state, `${merc.name} hits ${target.name} for ${dmg}!`, MSG_COLOR.merc);
  state.runStats.damageDealt += dmg;

  if (target.stats.hp <= 0) {
    target.isDead = true;
    addMessage(state, `${merc.name} defeats ${target.name}!`, MSG_COLOR.merc);
    state.score += target.xp;
    state.runStats.kills++;
    state.runStats.monsterKills[target.name] = (state.runStats.monsterKills[target.name] ?? 0) + 1;
    gainXP(state, target.xp);
  }
}

// ─── Descend to next floor ───

function descend(state: GameState) {
  state.floorNumber++;
  state.runStats.floorsCleared++;
  state.survivalUsedThisFloor = false;
  state.undyingWillUsedThisFloor = false;
  state.beyondDeathUsedThisFloor = false;
  addMessage(state, `Descending to floor ${state.floorNumber}...`, MSG_COLOR.system);

  const floor = generateFloor(state.floorNumber, state.zone);
  state.floor = floor;

  const firstRoom = floor.rooms[0]!;
  state.player.pos = { x: firstRoom.centerX, y: firstRoom.centerY };

  const row = floor.tiles[firstRoom.centerY];
  if (row) row[firstRoom.centerX] = Tile.StairsUp;

  const occupied = new Set<string>();
  occupied.add(`${state.player.pos.x},${state.player.pos.y}`);
  const lastRoom = floor.rooms[floor.rooms.length - 1]!;
  occupied.add(`${lastRoom.centerX},${lastRoom.centerY}`);

  const monsters = spawnMonsters(floor, state.floorNumber, occupied, state.zone);
  const keyItems = spawnKeys(floor, occupied);
  const vaultTreasures = spawnVaultTreasures(floor, state.floorNumber, occupied);
  const boss = spawnBoss(floor, state.floorNumber, occupied, state.bossesDefeatedThisRun, state.zone);
  state.monsters = boss ? [...monsters, boss] : monsters;
  state.items = [...spawnItems(floor, state.floorNumber, occupied, state.zone), ...keyItems, ...vaultTreasures];
  state.shop = spawnShop(floor, state.floorNumber, occupied, state.zone);
  state.mapMercenaries = spawnMercenaries(floor, state.floorNumber, occupied);
  if (state._bloodlineRef) {
    state.npcs = spawnNPCs(floor, state.floorNumber, occupied, state._bloodlineRef);
  } else {
    state.npcs = [];
  }

  // Mercenaries carry over but reposition near the player
  for (const merc of state.mercenaries) {
    if (!merc.isDead) {
      merc.pos = { x: state.player.pos.x, y: state.player.pos.y };
    }
  }

  if (boss) {
    addMessage(state, `A powerful presence lurks on this floor...`, MSG_COLOR.boss);
  }

  state.score += state.floorNumber * 10;
  updateFOV(state);
}

// ─── Shop ───

export function isAtShop(state: GameState): boolean {
  if (!state.shop) return false;
  return state.player.pos.x === state.shop.pos.x && state.player.pos.y === state.shop.pos.y;
}

export function buyItem(state: GameState, stockIndex: number): boolean {
  if (!state.shop) return false;
  const shopItem = state.shop.stock[stockIndex];
  if (!shopItem) return false;

  if (state.score < shopItem.price) {
    addMessage(state, "You can't afford that!", MSG_COLOR.bad);
    return false;
  }

  // Keys go directly into keysHeld, not inventory — no inventory space needed
  if (shopItem.item.type === 'key' && shopItem.item.keyColor) {
    state.score -= shopItem.price;
    state.keysHeld[shopItem.item.keyColor]++;
    state.shop.stock.splice(stockIndex, 1);
    addMessage(state, `Bought ${shopItem.item.name} for ${shopItem.price} gold.`, MSG_COLOR.key);
    return true;
  }

  if (state.player.inventory.length >= 20) {
    addMessage(state, 'Inventory full!', MSG_COLOR.bad);
    return false;
  }

  state.score -= shopItem.price;
  state.player.inventory.push({ ...shopItem.item, id: uid() });
  state.shop.stock.splice(stockIndex, 1);
  addMessage(state, `Bought ${shopItem.item.name} for ${shopItem.price} gold.`, MSG_COLOR.loot);
  return true;
}

// ─── NPC Dialogue Effects ───

export function applyDialogueEffects(
  state: GameState,
  effects: DialogueEffect[],
  bloodline: BloodlineData,
): void {
  for (const effect of effects) {
    switch (effect.type) {
      case 'heal': {
        const eStats = getEffectiveStats(state.player);
        const healed = Math.min(effect.amount, eStats.maxHp - state.player.stats.hp);
        state.player.stats.hp += healed;
        break;
      }
      case 'gold':
        state.score = Math.max(0, state.score + effect.amount);
        break;
      case 'item': {
        const template = findItemTemplate(effect.itemName);
        if (template && state.player.inventory.length < 20) {
          state.player.inventory.push({ ...template, id: uid() });
        }
        break;
      }
      case 'statBuff':
        state.player.stats[effect.stat] += effect.amount;
        break;
      case 'hunger':
        state.hunger.current = Math.min(state.hunger.max, state.hunger.current + effect.amount);
        break;
      case 'npcChoice':
        bloodline.npcChoicesMade[effect.eventId] = effect.choiceId;
        break;
      case 'message':
        addMessage(state, effect.text, effect.color);
        break;
    }
  }
  state.runStats.npcsTalkedTo++;
}

// ─── Cause of Death ───

export function extractCauseOfDeath(state: GameState): string {
  const msgs = state.messages;
  for (let i = msgs.length - 1; i >= 0; i--) {
    const text = msgs[i]!.text;
    if (text.includes('starved')) return 'Starved to death';
    const hitMatch = text.match(/^(.+) hits you/);
    if (hitMatch) return `Slain by ${hitMatch[1]}`;
  }
  return 'Unknown causes';
}

// ─── Wait action (skip turn) ───

export function waitTurn(state: GameState): boolean {
  if (state.gameOver) return false;
  addMessage(state, 'You wait...', MSG_COLOR.info);
  processTurn(state);
  return true;
}

// ─── Mercenary System ───

export function hireMercenary(state: GameState, mapMercId: string): boolean {
  const mapMerc = state.mapMercenaries.find(m => m.id === mapMercId);
  if (!mapMerc || mapMerc.hired) return false;

  const def = MERCENARY_DEFS.find(d => d.id === mapMerc.defId);
  if (!def) return false;

  if (state.score < def.hireCost) {
    addMessage(state, "You can't afford to hire them!", MSG_COLOR.bad);
    return false;
  }

  const activeCount = state.mercenaries.filter(m => !m.isDead).length;
  if (activeCount >= 2) {
    addMessage(state, 'Your party is full! (max 2 mercenaries)', MSG_COLOR.bad);
    return false;
  }

  state.score -= def.hireCost;
  mapMerc.hired = true;
  state.runStats.mercenariesHired++;

  const mercEntity: Entity = {
    id: uid(),
    pos: { ...mapMerc.pos },
    name: def.name,
    char: def.char,
    color: def.color,
    stats: { ...def.stats },
    xp: 0,
    level: state.floorNumber,
    inventory: [],
    equipment: {},
    isPlayer: false,
    isDead: false,
    isMercenary: true,
    mercName: `${def.name} the ${def.title}`,
  };

  state.mercenaries.push(mercEntity);
  addMessage(state, `${def.name} the ${def.title} joins your party!`, MSG_COLOR.merc);
  return true;
}
