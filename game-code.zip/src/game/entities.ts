import type { Entity, Item, MapItem, MonsterDef, Pos, DungeonFloor, ClassDef, Shop, ShopItem, KeyColor, MapMercenary, ZoneId } from './types';
import {
  MONSTER_DEFS,
  WEAPON_TEMPLATES,
  ARMOR_TEMPLATES,
  RING_TEMPLATES,
  AMULET_TEMPLATES,
  POTION_TEMPLATES,
  SCROLL_TEMPLATES,
  FOOD_TEMPLATES,
  PLAYER_BASE_STATS,
  KEY_COLORS,
  BOSS_DEFS,
  BOSS_LOOT_TEMPLATES,
  MERCENARY_DEFS,
  VAULT_TREASURE_TEMPLATES,
} from './constants';
import { uid, randInt, pick } from './utils';
import { isWalkableTile, getTile } from './dungeon';
import {
  getNecropolisMonsters,
  getNecropolisWeapons,
  getNecropolisArmor,
  getNecropolisItems,
} from './necropolis';
import { getNecropolisState } from './necropolisService';
import { ZONE_MONSTERS, ZONE_BOSSES, ZONE_WEAPONS, ZONE_ARMOR, ZONE_POTIONS, ZONE_FOOD, ZONE_BOSS_LOOT } from './zones';

export function createPlayer(pos: Pos, classDef?: ClassDef): Entity {
  const stats = classDef ? { ...classDef.baseStats } : { ...PLAYER_BASE_STATS };
  return {
    id: uid(),
    pos: { ...pos },
    name: 'You',
    char: '@',
    color: classDef?.color ?? '#ffffff',
    stats,
    xp: 0,
    level: 1,
    inventory: [],
    equipment: {},
    isPlayer: true,
    isDead: false,
  };
}

function randomWalkable(floor: DungeonFloor, occupied: Set<string>): Pos | null {
  for (let attempt = 0; attempt < 100; attempt++) {
    const room = floor.rooms[randInt(0, floor.rooms.length - 1)];
    if (!room) continue;
    const x = randInt(room.x, room.x + room.w - 1);
    const y = randInt(room.y, room.y + room.h - 1);
    const key = `${x},${y}`;
    if (isWalkableTile(getTile(floor, x, y)) && !occupied.has(key)) {
      occupied.add(key);
      return { x, y };
    }
  }
  return null;
}

/**
 * Return a random walkable position inside a specific room.
 * The position must not already be in the occupied set.
 */
function randomWalkableInRoom(
  floor: DungeonFloor,
  room: { x: number; y: number; w: number; h: number },
  occupied: Set<string>,
): Pos | null {
  for (let attempt = 0; attempt < 80; attempt++) {
    const x = randInt(room.x, room.x + room.w - 1);
    const y = randInt(room.y, room.y + room.h - 1);
    const key = `${x},${y}`;
    if (isWalkableTile(getTile(floor, x, y)) && !occupied.has(key)) {
      occupied.add(key);
      return { x, y };
    }
  }
  return null;
}

/** Get all available monster definitions (base + necropolis + zone). */
function getAllMonsterDefs(zone: ZoneId = 'stone_depths'): MonsterDef[] {
  const necroDeaths = getNecropolisState().communalDeaths;
  const zoneMonsters = ZONE_MONSTERS[zone] ?? [];
  if (zone === 'stone_depths') {
    return [...MONSTER_DEFS, ...getNecropolisMonsters(necroDeaths)];
  }
  // Non-stone_depths zones use their own monsters
  return zoneMonsters.length > 0 ? zoneMonsters : [...MONSTER_DEFS, ...getNecropolisMonsters(necroDeaths)];
}

/** Get all available weapon templates (base + necropolis + zone). */
function getAllWeapons(zone: ZoneId = 'stone_depths'): Omit<Item, 'id'>[] {
  const necroDeaths = getNecropolisState().communalDeaths;
  const zoneWeapons = ZONE_WEAPONS[zone] ?? [];
  if (zone === 'stone_depths') {
    return [...WEAPON_TEMPLATES, ...getNecropolisWeapons(necroDeaths)];
  }
  // Zone weapons + base weapons for variety
  return [...zoneWeapons, ...WEAPON_TEMPLATES, ...getNecropolisWeapons(necroDeaths)];
}

/** Get all available armor templates (base + necropolis + zone). */
function getAllArmor(zone: ZoneId = 'stone_depths'): Omit<Item, 'id'>[] {
  const necroDeaths = getNecropolisState().communalDeaths;
  const zoneArmor = ZONE_ARMOR[zone] ?? [];
  if (zone === 'stone_depths') {
    return [...ARMOR_TEMPLATES, ...getNecropolisArmor(necroDeaths)];
  }
  return [...zoneArmor, ...ARMOR_TEMPLATES, ...getNecropolisArmor(necroDeaths)];
}

/** Get all necropolis items available as loot. */
function getExtraItems(): Omit<Item, 'id'>[] {
  const necroDeaths = getNecropolisState().communalDeaths;
  return getNecropolisItems(necroDeaths);
}

/** Get zone-specific potions. */
function getZonePotions(zone: ZoneId): Omit<Item, 'id'>[] {
  return ZONE_POTIONS[zone] ?? [];
}

/** Get zone-specific food. */
function getZoneFood(zone: ZoneId): Omit<Item, 'id'>[] {
  return ZONE_FOOD[zone] ?? [];
}

export function spawnMonsters(floor: DungeonFloor, floorNumber: number, occupied: Set<string>, zone: ZoneId = 'stone_depths'): Entity[] {
  const allDefs = getAllMonsterDefs(zone);
  const eligible = allDefs.filter((m) => m.minFloor <= floorNumber);
  if (eligible.length === 0) return [];

  const count = randInt(4, 6 + Math.floor(floorNumber * 1.5));
  const monsters: Entity[] = [];

  for (let i = 0; i < count; i++) {
    const def: MonsterDef = pick(eligible);
    const pos = randomWalkable(floor, occupied);
    if (!pos) break;

    const scale = 1 + (floorNumber - def.minFloor) * 0.1;

    const entity: Entity = {
      id: uid(),
      pos,
      name: def.name,
      char: def.char,
      color: def.color,
      stats: {
        hp: Math.round(def.stats.hp * scale),
        maxHp: Math.round(def.stats.maxHp * scale),
        attack: Math.round(def.stats.attack * scale),
        defense: Math.round(def.stats.defense * scale),
        speed: def.stats.speed,
      },
      xp: def.xpValue,
      level: floorNumber,
      inventory: [],
      equipment: {},
      isPlayer: false,
      isDead: false,
    };
    if (def.terrainOnHit) entity.terrainOnHit = def.terrainOnHit;
    if (def.abilities) entity.abilities = def.abilities;
    monsters.push(entity);
  }

  return monsters;
}

export function randomItem(floorNumber: number, zone: ZoneId = 'stone_depths'): Item {
  const roll = Math.random();
  let template: Omit<Item, 'id'> | undefined;

  const allWeapons = getAllWeapons(zone);
  const allArmor = getAllArmor(zone);
  const extraItems = getExtraItems();
  const zonePotions = getZonePotions(zone);
  const zoneFood = getZoneFood(zone);

  if (roll < 0.13) {
    const maxIdx = Math.min(allWeapons.length - 1, Math.floor(floorNumber / 2));
    template = allWeapons[randInt(0, maxIdx)];
  } else if (roll < 0.24) {
    const maxIdx = Math.min(allArmor.length - 1, Math.floor(floorNumber / 3));
    template = allArmor[randInt(0, maxIdx)];
  } else if (roll < 0.30) {
    template = pick(RING_TEMPLATES);
  } else if (roll < 0.35) {
    // Include necropolis accessories in amulet pool
    const pool = [...AMULET_TEMPLATES, ...extraItems.filter((i) => i.type === 'amulet' || i.type === 'ring')];
    template = pick(pool.length > 0 ? pool : AMULET_TEMPLATES);
  } else if (roll < 0.52) {
    // Include necropolis potions + zone potions
    const pool = [...POTION_TEMPLATES, ...zonePotions, ...extraItems.filter((i) => i.type === 'potion')];
    template = pick(pool);
  } else if (roll < 0.62) {
    template = pick(SCROLL_TEMPLATES);
  } else if (roll < 0.8) {
    // Zone-specific food + base food
    const foodPool = [...FOOD_TEMPLATES, ...zoneFood];
    template = pick(foodPool);
  }

  if (!template) {
    template = {
      name: 'Gold',
      type: 'gold',
      char: '*',
      color: '#ffd700',
      value: randInt(5, 15 + floorNumber * 5),
      description: 'Shiny coins',
    };
  }

  return { ...template, id: uid() };
}

export function spawnItems(floor: DungeonFloor, floorNumber: number, occupied: Set<string>, zone: ZoneId = 'stone_depths'): MapItem[] {
  const count = randInt(4, 7 + Math.floor(floorNumber * 0.5));
  const items: MapItem[] = [];

  for (let i = 0; i < count; i++) {
    const pos = randomWalkable(floor, occupied);
    if (!pos) break;
    items.push({
      id: uid(),
      pos,
      item: randomItem(floorNumber, zone),
    });
  }

  return items;
}

/**
 * Spawn keys for vault rooms.
 *
 * For each room flagged with `isVault` and a `keyColor`, place the matching
 * key as a MapItem in a random walkable position inside a *different* room
 * on the same floor.
 */
export function spawnKeys(floor: DungeonFloor, occupied: Set<string>): MapItem[] {
  const keys: MapItem[] = [];

  for (const room of floor.rooms) {
    if (!room.isVault || !room.keyColor) continue;

    const colorKey: KeyColor = room.keyColor;
    const cfg = KEY_COLORS[colorKey];
    if (!cfg) continue;

    // Pick a non-vault room to place the key in
    const candidateRooms = floor.rooms.filter((r) => r !== room && !r.isVault);
    if (candidateRooms.length === 0) continue;

    const targetRoom = pick(candidateRooms);
    const pos = randomWalkableInRoom(floor, targetRoom, occupied);
    if (!pos) continue;

    const keyItem: Item = {
      id: uid(),
      name: cfg.name,
      type: 'key',
      char: cfg.char,
      color: cfg.color,
      value: 0,
      description: `Unlocks ${colorKey} doors`,
      keyColor: colorKey,
    };

    keys.push({
      id: uid(),
      pos,
      item: keyItem,
    });
  }

  return keys;
}

/**
 * Spawn vault-exclusive treasures inside vault rooms.
 *
 * For each vault room, spawn 2-4 unique treasures that can ONLY be found
 * behind locked doors. Treasure quality scales with floor depth.
 */
export function spawnVaultTreasures(
  floor: DungeonFloor,
  floorNumber: number,
  occupied: Set<string>,
): MapItem[] {
  const treasures: MapItem[] = [];

  for (const room of floor.rooms) {
    if (!room.isVault) continue;

    // Spawn 2-4 unique treasures inside the vault
    const count = randInt(2, 4);
    // Higher floors unlock rarer treasures from the pool
    const maxIdx = Math.min(
      VAULT_TREASURE_TEMPLATES.length - 1,
      Math.floor(floorNumber / 2) + 3,
    );

    for (let i = 0; i < count; i++) {
      const pos = randomWalkableInRoom(floor, room, occupied);
      if (!pos) break;

      const template = VAULT_TREASURE_TEMPLATES[randInt(0, maxIdx)]!;
      // Scale gold treasures with floor depth
      const item: Item = { ...template, id: uid() };
      if (item.type === 'gold') {
        item.value = Math.floor(item.value * (1 + floorNumber * 0.15));
      }

      treasures.push({ id: uid(), pos, item });
    }
  }

  return treasures;
}

/**
 * Attempt to spawn a boss in a boss arena room on this floor.
 *
 * Picks an eligible boss whose `minFloor` is <= floorNumber and whose name
 * is not in `defeatedBosses`. The boss is placed inside the room tagged
 * `isBossArena`. Returns `null` when no arena exists or no eligible boss
 * is available.
 */
export function spawnBoss(
  floor: DungeonFloor,
  floorNumber: number,
  occupied: Set<string>,
  defeatedBosses: string[],
  zone: ZoneId = 'stone_depths',
): Entity | null {
  // Find the boss arena room
  const arena = floor.rooms.find((r) => r.isBossArena);
  if (!arena) return null;

  // Use zone-specific bosses, or base bosses for stone_depths
  const zoneBosses = ZONE_BOSSES[zone] ?? [];
  const bossDefs = zone === 'stone_depths' ? BOSS_DEFS : (zoneBosses.length > 0 ? zoneBosses : BOSS_DEFS);

  // Filter eligible bosses
  const defeated = new Set(defeatedBosses);
  const eligible = bossDefs.filter(
    (b) => b.minFloor <= floorNumber && !defeated.has(b.name),
  );
  if (eligible.length === 0) return null;

  const def = pick(eligible);
  const pos = randomWalkableInRoom(floor, arena, occupied);
  if (!pos) return null;

  const scale = 1 + (floorNumber - def.minFloor) * 0.05;

  return {
    id: uid(),
    pos,
    name: def.name,
    char: def.char,
    color: def.color,
    stats: {
      hp: Math.round(def.stats.hp * scale),
      maxHp: Math.round(def.stats.maxHp * scale),
      attack: Math.round(def.stats.attack * scale),
      defense: Math.round(def.stats.defense * scale),
      speed: def.stats.speed,
    },
    xp: def.xpValue,
    level: floorNumber,
    inventory: [],
    equipment: {},
    isPlayer: false,
    isDead: false,
    isBoss: true,
    bossAbility: def.bossAbility,
    bossAbilityCooldown: 0,
  };
}

/**
 * Spawn 0-1 mercenaries on the floor.
 *
 * Each eligible mercenary (minFloor <= floorNumber) has roughly a 40% chance
 * of appearing. At most one mercenary spawns per floor.
 */
export function spawnMercenaries(
  floor: DungeonFloor,
  floorNumber: number,
  occupied: Set<string>,
): MapMercenary[] {
  const eligible = MERCENARY_DEFS.filter((m) => m.minFloor <= floorNumber);
  if (eligible.length === 0) return [];

  // ~40% chance to spawn a mercenary on this floor
  if (Math.random() > 0.4) return [];

  const def = pick(eligible);
  const pos = randomWalkable(floor, occupied);
  if (!pos) return [];

  return [
    {
      id: uid(),
      pos,
      defId: def.id,
      hired: false,
    },
  ];
}

/** Pick a random item from the top portion of a sorted-by-power array, scaled to floor depth.
 *  Returns an item near the player's expected tier with a bit of variance. */
function pickScaled<T>(pool: T[], floorNumber: number, divisor: number): T {
  if (pool.length === 0) return pool[0]!;
  const idealIdx = Math.min(pool.length - 1, Math.floor(floorNumber / divisor));
  // Allow picking from a small window around the ideal tier for variety
  const lo = Math.max(0, idealIdx - 1);
  const hi = Math.min(pool.length - 1, idealIdx + 1);
  return pool[randInt(lo, hi)]!;
}

function generateShopStock(floorNumber: number, zone: ZoneId = 'stone_depths'): ShopItem[] {
  const stock: ShopItem[] = [];
  const zoneFood = getZoneFood(zone);
  const foodPool = [...FOOD_TEMPLATES, ...zoneFood];

  // Always sell food — food is affordable! (0.8x multiplier instead of 1.5x)
  const food1 = pick(foodPool);
  const food2 = pick(foodPool);
  stock.push({ item: { ...food1, id: uid() }, price: Math.floor(food1.value * 0.8) });
  stock.push({ item: { ...food2, id: uid() }, price: Math.floor(food2.value * 0.8) });

  // Always sell a health potion
  stock.push({ item: { ...POTION_TEMPLATES[0]!, id: uid() }, price: 15 });

  // Deeper floors get better potions
  if (floorNumber >= 3) {
    stock.push({ item: { ...POTION_TEMPLATES[1]!, id: uid() }, price: 35 });
  }
  // Full heal potion available on very deep floors
  if (floorNumber >= 8) {
    stock.push({ item: { ...POTION_TEMPLATES[6]!, id: uid() }, price: 80 });
  }

  // Sell a scroll — deeper floors get access to better scrolls
  const scrollIdx = Math.min(SCROLL_TEMPLATES.length - 1, Math.floor(floorNumber / 3));
  const scrollPool = SCROLL_TEMPLATES.slice(0, scrollIdx + 1);
  stock.push({ item: { ...pick(scrollPool), id: uid() }, price: 25 + floorNumber * 3 });

  // Sell a weapon scaled to floor (includes necropolis + zone weapons)
  const allWeapons = getAllWeapons(zone);
  const weapon = pickScaled(allWeapons, floorNumber, 2);
  stock.push({ item: { ...weapon, id: uid() }, price: Math.floor(weapon.value * 2) });

  // On deeper floors, offer a second weapon option for more choice
  if (floorNumber >= 5) {
    const weapon2 = pickScaled(allWeapons, floorNumber, 1.5);
    stock.push({ item: { ...weapon2, id: uid() }, price: Math.floor(weapon2.value * 2.2) });
  }

  // Sell armor scaled to floor (includes necropolis + zone armor)
  const allArmor = getAllArmor(zone);
  const armor = pickScaled(allArmor, floorNumber, 3);
  stock.push({ item: { ...armor, id: uid() }, price: Math.floor(armor.value * 2) });

  // On deeper floors, offer a second armor option
  if (floorNumber >= 6) {
    const armor2 = pickScaled(allArmor, floorNumber, 2);
    stock.push({ item: { ...armor2, id: uid() }, price: Math.floor(armor2.value * 2.2) });
  }

  // Chance for a ring on deeper floors
  if (floorNumber >= 4) {
    const ring = pickScaled(RING_TEMPLATES, floorNumber, 3);
    stock.push({ item: { ...ring, id: uid() }, price: Math.floor(ring.value * 2.5) });
  }

  // Amulets available on deeper floors
  if (floorNumber >= 7) {
    const amulet = pickScaled(AMULET_TEMPLATES, floorNumber - 7, 2);
    stock.push({ item: { ...amulet, id: uid() }, price: Math.floor(amulet.value * 2.5) });
  }

  // Necropolis items in shops on deeper floors
  const extraItems = getExtraItems();
  if (extraItems.length > 0 && floorNumber >= 3) {
    const necroItem = pick(extraItems);
    stock.push({ item: { ...necroItem, id: uid() }, price: Math.floor(necroItem.value * 2) });
  }

  // Sell keys — offer the appropriate key tier for this floor depth
  const keyColors = Object.entries(KEY_COLORS) as [KeyColor, typeof KEY_COLORS[KeyColor]][];
  const eligibleKeys = keyColors.filter(([, cfg]) => floorNumber >= cfg.minFloor);
  if (eligibleKeys.length > 0) {
    // Always stock the highest-tier key available for this floor
    const [bestColor, bestCfg] = eligibleKeys[eligibleKeys.length - 1]!;
    stock.push({
      item: {
        id: uid(),
        name: bestCfg.name,
        type: 'key',
        char: bestCfg.char,
        color: bestCfg.color,
        value: 0,
        description: `Unlocks ${bestColor} doors`,
        keyColor: bestColor,
      },
      price: bestCfg.shopPrice,
    });
  }

  return stock;
}

export function spawnShop(floor: DungeonFloor, floorNumber: number, occupied: Set<string>, zone: ZoneId = 'stone_depths'): Shop | null {
  const pos = randomWalkable(floor, occupied);
  if (!pos) return null;
  return { pos, stock: generateShopStock(floorNumber, zone) };
}

/** Search all item template arrays for a template by name. */
export function findItemTemplate(name: string): Omit<Item, 'id'> | undefined {
  const necroDeaths = getNecropolisState().communalDeaths;
  const allTemplates = [
    ...WEAPON_TEMPLATES,
    ...ARMOR_TEMPLATES,
    ...RING_TEMPLATES,
    ...AMULET_TEMPLATES,
    ...POTION_TEMPLATES,
    ...SCROLL_TEMPLATES,
    ...FOOD_TEMPLATES,
    ...BOSS_LOOT_TEMPLATES,
    ...VAULT_TREASURE_TEMPLATES,
    ...ZONE_BOSS_LOOT,
    ...getNecropolisWeapons(necroDeaths),
    ...getNecropolisArmor(necroDeaths),
    ...getNecropolisItems(necroDeaths),
  ];
  return allTemplates.find((t) => t.name === name);
}
