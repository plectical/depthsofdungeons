import { Tile, type GameState, type Pos } from './types';
import { getTile, isWalkableTile } from './dungeon';
import { movePlayer, useItem, equipItem, waitTurn } from './engine';
import { findPath, manhattan } from './utils';
import { HUNGER_WARNING } from './constants';

/**
 * Run one auto-play step. Returns the new state if an action was taken, or null if nothing to do.
 */
export function autoplayStep(state: GameState): GameState | null {
  if (state.gameOver) return null;

  const next = structuredClone(state);

  // 1. Survival: eat food if hungry
  if (next.hunger.current <= HUNGER_WARNING) {
    const foodIdx = next.player.inventory.findIndex((i) => i.type === 'food');
    if (foodIdx >= 0) {
      useItem(next, foodIdx);
      return next;
    }
  }

  // 2. Survival: use health potion if low HP
  const hpRatio = next.player.stats.hp / next.player.stats.maxHp;
  if (hpRatio <= 0.35) {
    const potionIdx = next.player.inventory.findIndex((i) => i.type === 'potion' && i.name.includes('Health'));
    if (potionIdx >= 0) {
      useItem(next, potionIdx);
      return next;
    }
  }

  // 3. Auto-equip better gear
  if (tryAutoEquip(next)) return next;

  // 4. Fight visible monsters — move toward the nearest one
  const visibleMonsters = next.monsters.filter(
    (m) => !m.isDead && isVisible(next, m.pos),
  );

  if (visibleMonsters.length > 0) {
    // Pick weakest visible monster to focus
    visibleMonsters.sort((a, b) => a.stats.hp - b.stats.hp);
    const target = visibleMonsters[0]!;
    const step = pathTo(next, target.pos);
    if (step) {
      const dx = step.x - next.player.pos.x;
      const dy = step.y - next.player.pos.y;
      if (movePlayer(next, dx, dy)) return next;
    }
  }

  // 5. Pick up nearby consumables & useful items on the ground
  if (next.player.inventory.length < 20) {
    const pickupTarget = findNearbyItem(next);
    if (pickupTarget) {
      const step = pathTo(next, pickupTarget);
      if (step) {
        const dx = step.x - next.player.pos.x;
        const dy = step.y - next.player.pos.y;
        if (movePlayer(next, dx, dy)) return next;
      }
    }
  }

  // 6. Go unlock a locked door if we have the key
  const lockedDoorTarget = findLockedDoor(next);
  if (lockedDoorTarget) {
    const step = pathTo(next, lockedDoorTarget);
    if (step) {
      const dx = step.x - next.player.pos.x;
      const dy = step.y - next.player.pos.y;
      if (movePlayer(next, dx, dy)) return next;
    }
  }

  // 7. Go to nearest unexplored visible walkable tile
  const exploreTarget = findExploreTarget(next);
  if (exploreTarget) {
    const step = pathTo(next, exploreTarget);
    if (step) {
      const dx = step.x - next.player.pos.x;
      const dy = step.y - next.player.pos.y;
      if (movePlayer(next, dx, dy)) return next;
    }
  }

  // 8. Head to stairs down
  const stairsPos = findStairs(next);
  if (stairsPos) {
    const step = pathTo(next, stairsPos);
    if (step) {
      const dx = step.x - next.player.pos.x;
      const dy = step.y - next.player.pos.y;
      if (movePlayer(next, dx, dy)) return next;
    }
  }

  // 9. Nothing useful to do — just wait
  waitTurn(next);
  return next;
}

function isVisible(state: GameState, pos: Pos): boolean {
  const row = state.floor.visible[pos.y];
  return row ? row[pos.x] === true : false;
}

function pathTo(state: GameState, target: Pos): Pos | null {
  const isWalkable = (x: number, y: number) => {
    if (x < 0 || x >= state.floor.width || y < 0 || y >= state.floor.height) return false;
    // Allow walking into monsters (to attack them)
    if (state.monsters.some((m) => !m.isDead && m.pos.x === x && m.pos.y === y)) {
      return x === target.x && y === target.y;
    }
    // Avoid NPC tiles (don't trigger dialogue during autoplay)
    if (state.npcs?.some((n) => !n.talked && n.pos.x === x && n.pos.y === y)) {
      return false;
    }
    const tile = getTile(state.floor, x, y);
    // Allow pathing through locked doors if we hold the matching key
    if (tile === Tile.LockedDoor) {
      return canUnlockAt(state, x, y);
    }
    return isWalkableTile(tile);
  };
  return findPath(state.player.pos, target, isWalkable, 40);
}

/** Check if the player holds the right key for a locked door at (x, y) */
function canUnlockAt(state: GameState, x: number, y: number): boolean {
  const vault = state.floor.rooms.find(r => r.isVault &&
    x >= r.x - 1 && x <= r.x + r.w && y >= r.y - 1 && y <= r.y + r.h);
  const keyColor = vault?.keyColor;
  return !!keyColor && state.keysHeld[keyColor] > 0;
}

function findExploreTarget(state: GameState): Pos | null {
  const { floor, player } = state;
  let bestPos: Pos | null = null;
  let bestDist = Infinity;

  // Look for unexplored tiles adjacent to explored walkable tiles
  for (let y = 0; y < floor.height; y++) {
    for (let x = 0; x < floor.width; x++) {
      const explored = floor.explored[y]?.[x];
      if (explored) continue; // Skip already-explored

      const tile = getTile(floor, x, y);
      if (tile === Tile.Void || tile === Tile.Wall) continue;

      // Check if any neighbor is explored (so we can actually reach it)
      const hasExploredNeighbor = [
        [x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1],
      ].some(([nx, ny]) => {
        if (nx === undefined || ny === undefined) return false;
        return floor.explored[ny]?.[nx] === true;
      });

      if (!hasExploredNeighbor) continue;

      const dist = manhattan(player.pos, { x, y });
      if (dist < bestDist) {
        bestDist = dist;
        bestPos = { x, y };
      }
    }
  }

  // If no edge tiles found, look for any explored walkable tile near an unexplored area
  if (!bestPos) {
    for (let y = 0; y < floor.height; y++) {
      for (let x = 0; x < floor.width; x++) {
        if (!floor.explored[y]?.[x]) continue;
        const tile = getTile(floor, x, y);
        if (!isWalkableTile(tile)) continue;

        const hasUnexploredNeighbor = [
          [x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1],
        ].some(([nx, ny]) => {
          if (nx === undefined || ny === undefined) return false;
          if (nx < 0 || nx >= floor.width || ny < 0 || ny >= floor.height) return false;
          const t = getTile(floor, nx, ny);
          if (t === Tile.Void || t === Tile.Wall) return false;
          return floor.explored[ny]?.[nx] !== true;
        });

        if (!hasUnexploredNeighbor) continue;

        const dist = manhattan(player.pos, { x, y });
        if (dist < bestDist) {
          bestDist = dist;
          bestPos = { x, y };
        }
      }
    }
  }

  return bestPos;
}

const PICKUP_TYPES = new Set(['food', 'potion', 'scroll', 'gold', 'weapon', 'armor', 'ring', 'amulet', 'key']);

function findNearbyItem(state: GameState): Pos | null {
  const { items, player } = state;
  let bestPos: Pos | null = null;
  let bestDist = Infinity;

  for (const mi of items) {
    // Only pick up useful item types
    if (!PICKUP_TYPES.has(mi.item.type)) continue;

    // Only go to items in explored areas
    if (!state.floor.explored[mi.pos.y]?.[mi.pos.x]) continue;

    const dist = manhattan(player.pos, mi.pos);
    // Don't wander too far for items — keep it within a reasonable range
    if (dist < bestDist && dist <= 20) {
      bestDist = dist;
      bestPos = mi.pos;
    }
  }

  return bestPos;
}

function findLockedDoor(state: GameState): Pos | null {
  const { floor, player } = state;
  let bestPos: Pos | null = null;
  let bestDist = Infinity;

  for (let y = 0; y < floor.height; y++) {
    for (let x = 0; x < floor.width; x++) {
      if (getTile(floor, x, y) !== Tile.LockedDoor) continue;
      if (!floor.explored[y]?.[x]) continue;
      if (!canUnlockAt(state, x, y)) continue;

      const dist = manhattan(player.pos, { x, y });
      if (dist < bestDist) {
        bestDist = dist;
        bestPos = { x, y };
      }
    }
  }

  return bestPos;
}

function findStairs(state: GameState): Pos | null {
  const { floor } = state;
  for (let y = 0; y < floor.height; y++) {
    for (let x = 0; x < floor.width; x++) {
      if (getTile(floor, x, y) === Tile.StairsDown && floor.explored[y]?.[x]) {
        return { x, y };
      }
    }
  }
  return null;
}

function tryAutoEquip(state: GameState): boolean {
  const player = state.player;

  for (let i = 0; i < player.inventory.length; i++) {
    const item = player.inventory[i];
    if (!item || !item.equipSlot) continue;

    const current = player.equipment[item.equipSlot];
    if (!current) {
      // Empty slot — equip it
      equipItem(state, i);
      return true;
    }

    // Compare stat bonuses — equip if total bonus is higher
    const currentTotal = sumBonus(current.statBonus);
    const newTotal = sumBonus(item.statBonus);
    if (newTotal > currentTotal) {
      equipItem(state, i);
      return true;
    }
  }
  return false;
}

function sumBonus(bonus: Partial<Record<string, number>> | undefined): number {
  if (!bonus) return 0;
  let total = 0;
  for (const v of Object.values(bonus)) {
    if (typeof v === 'number') total += v;
  }
  return total;
}
