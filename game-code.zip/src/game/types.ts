// ── Tile types ──
export enum Tile {
  Wall = '#',
  Floor = '.',
  Corridor = '+',
  Door = 'D',
  StairsDown = '>',
  StairsUp = '<',
  Void = ' ',
  LockedDoor = 'L',
  BossGate = 'G',
}

// ── Zone system ──
export type ZoneId = 'stone_depths' | 'frozen_caverns' | 'fungal_marsh' | 'infernal_pit' | 'crystal_sanctum' | 'shadow_realm';

export interface ZoneDef {
  id: ZoneId;
  name: string;
  description: string;
  color: string;
  icon: string;
  /** Boss names + class combos required to unlock. Empty = always available. */
  unlockRequirements: ZoneUnlockReq[];
  /** Terrain types that appear in this zone */
  terrainPool: TerrainType[];
  /** Floor range this zone spans */
  floorRange: { min: number; max: number };
  /** Wall/floor color overrides */
  palette: { wall: string; wallBg: string; floor: string; floorBg: string };
}

export interface ZoneUnlockReq {
  bossName: string;
  withClass: PlayerClass;
}

// ── Terrain types (environmental overlay on walkable tiles) ──
export type TerrainType = 'water' | 'lava' | 'poison' | 'ice' | 'tall_grass' | 'mud' | 'holy' | 'shadow'
  | 'frozen' | 'spore' | 'brimstone' | 'crystal' | 'void_rift' | 'mycelium';

export interface TerrainDef {
  type: TerrainType;
  name: string;
  color: string;       // foreground dot color
  bg: string;          // background tint
  glow?: string;       // optional glow
  minFloor: number;    // earliest floor this terrain can appear
}

// ── Terrain map — stores terrain overlays per-tile (sparse) ──
export type TerrainMap = Record<string, TerrainType>; // key = "x,y"

// ── Position ──
export interface Pos {
  x: number;
  y: number;
}

// ── Room for dungeon generation ──
export interface Room {
  x: number;
  y: number;
  w: number;
  h: number;
  centerX: number;
  centerY: number;
  isVault?: boolean;
  isBossArena?: boolean;
  keyColor?: KeyColor;
}

// ── Key colors for locked doors ──
export type KeyColor = 'iron' | 'gold' | 'crystal' | 'blood' | 'void';

// ── Stats ──
export interface Stats {
  hp: number;
  maxHp: number;
  attack: number;
  defense: number;
  speed: number;
}

// ── Equipment slots ──
export type EquipSlot = 'weapon' | 'armor' | 'ring' | 'amulet';

// ── Item types ──
export type ItemType = 'weapon' | 'armor' | 'ring' | 'amulet' | 'potion' | 'scroll' | 'gold' | 'food' | 'key';

export interface Item {
  id: string;
  name: string;
  type: ItemType;
  char: string;
  color: string;
  value: number;
  equipSlot?: EquipSlot;
  statBonus?: Partial<Stats>;
  description: string;
  keyColor?: KeyColor;
  onHitEffect?: ItemEffect;
  onDefendEffect?: ItemEffect;
}

// ── Special item effects ──
export type ItemEffect =
  | { type: 'lifesteal'; percent: number }
  | { type: 'poison'; damage: number; turns: number }
  | { type: 'stun'; chance: number }
  | { type: 'thorns'; damage: number }
  | { type: 'fireball'; damage: number; chance: number }
  | { type: 'freeze'; chance: number; turns: number }
  | { type: 'bleed'; damage: number; turns: number }
  | { type: 'execute'; hpThreshold: number; chance: number };

// ── Monster innate abilities (non-boss) ──
export type MonsterAbility =
  | { type: 'poisonAttack'; damage: number; turns: number; chance: number }
  | { type: 'stunAttack'; chance: number }
  | { type: 'bleedAttack'; damage: number; turns: number; chance: number }
  | { type: 'freezeAttack'; chance: number; turns: number }
  | { type: 'chargeAttack'; multiplier: number; chance: number }
  | { type: 'selfHeal'; amount: number; hpThreshold: number; cooldown: number }
  | { type: 'enrage'; hpThreshold: number; atkMultiplier: number }
  | { type: 'dodge'; chance: number }
  | { type: 'callForHelp'; monsterName: string; chance: number; cooldown: number }
  | { type: 'drainLife'; percent: number; chance: number };

// ── Monster definitions ──
export interface MonsterDef {
  name: string;
  char: string;
  color: string;
  stats: Stats;
  xpValue: number;
  minFloor: number;
  lootChance: number;
  isBoss?: boolean;
  bossAbility?: BossAbility;
  guaranteedLoot?: string;
  /** When this monster attacks, it creates terrain around the target */
  terrainOnHit?: { terrain: TerrainType; radius: number; chance: number };
  /** Innate combat abilities for non-boss monsters */
  abilities?: MonsterAbility[];
}

export type BossAbility =
  | { type: 'summon'; monsterName: string; count: number; cooldown: number }
  | { type: 'rage'; hpThreshold: number; atkMultiplier: number }
  | { type: 'heal'; amount: number; cooldown: number }
  | { type: 'aoe'; damage: number; radius: number; cooldown: number }
  | { type: 'teleport'; cooldown: number }
  | { type: 'terrain_attack'; terrain: TerrainType; radius: number; count: number; cooldown: number }
  | { type: 'multi'; abilities: BossAbility[] };

// ── Entity on the map ──
export interface Entity {
  id: string;
  pos: Pos;
  name: string;
  char: string;
  color: string;
  stats: Stats;
  xp: number;
  level: number;
  inventory: Item[];
  equipment: Partial<Record<EquipSlot, Item>>;
  isPlayer: boolean;
  isDead: boolean;
  isBoss?: boolean;
  bossAbility?: BossAbility;
  bossAbilityCooldown?: number;
  isEnraged?: boolean;
  statusEffects?: StatusEffect[];
  isMercenary?: boolean;
  mercName?: string;
  /** When this monster attacks, it creates terrain around the target */
  terrainOnHit?: { terrain: TerrainType; radius: number; chance: number };
  /** Innate combat abilities for non-boss monsters */
  abilities?: MonsterAbility[];
  /** Per-ability cooldown tracking */
  abilityCooldowns?: Record<string, number>;
  /** Whether this monster is enraged */
  isMonsterEnraged?: boolean;
}

// ── Status effects ──
export interface StatusEffect {
  type: 'poison' | 'stun' | 'bleed' | 'freeze';
  turnsRemaining: number;
  damage?: number;
}

// ── Mercenary definitions ──
export interface MercenaryDef {
  id: string;
  name: string;
  title: string;
  char: string;
  color: string;
  hireCost: number;
  stats: Stats;
  minFloor: number;
  description: string;
  specialAbility: string;
}

// ── Item on the map ──
export interface MapItem {
  id: string;
  pos: Pos;
  item: Item;
}

// ── Dungeon floor data ──
export interface DungeonFloor {
  width: number;
  height: number;
  tiles: Tile[][];
  rooms: Room[];
  visible: boolean[][];
  explored: boolean[][];
  terrain: TerrainMap;
}

// ── Message log entry ──
export interface LogMessage {
  text: string;
  color: string;
  turn: number;
}

// ── Hunger state ──
export interface HungerState {
  current: number;
  max: number;
}

// ── Player classes ──
export type PlayerClass = 'warrior' | 'rogue' | 'mage' | 'ranger' | 'necromancer' | 'revenant';

export interface PassiveAbility {
  name: string;
  description: string;
  unlockLevel: number;
}

export interface ClassDef {
  id: PlayerClass;
  name: string;
  char: string;
  color: string;
  description: string;
  baseStats: Stats;
  levelBonusHp: number;
  levelBonusAtk: number;
  levelBonusDef: number;
  passives: PassiveAbility[];
  requiresBestFloor: number;
}

// ── Shop ──
export interface ShopItem {
  item: Item;
  price: number;
}

export interface Shop {
  pos: Pos;
  stock: ShopItem[];
}

// ── Bloodline: persists across all runs ──

export interface RunStats {
  kills: number;
  damageDealt: number;
  damageTaken: number;
  potionsUsed: number;
  foodEaten: number;
  scrollsUsed: number;
  itemsFound: number;
  goldEarned: number;
  floorsCleared: number;
  npcsTalkedTo: number;
  monsterKills: Record<string, number>;
  bossesKilled: number;
  keysUsed: number;
  mercenariesHired: number;
}

export interface AncestorRecord {
  name: string;
  class: PlayerClass;
  floorReached: number;
  level: number;
  score: number;
  killCount: number;
  causeOfDeath: string;
  turnsLived: number;
}

export interface BloodlineData {
  version: number;
  generation: number;
  ancestors: AncestorRecord[];
  cumulative: {
    totalDeaths: number;
    totalKills: number;
    totalDamageDealt: number;
    totalDamageTaken: number;
    totalFloors: number;
    totalScore: number;
    totalTurns: number;
    totalPotionsUsed: number;
    totalFoodEaten: number;
    totalScrollsUsed: number;
    totalItemsFound: number;
    totalGoldEarned: number;
    totalNpcsTalkedTo: number;
    totalMonsterKills: Record<string, number>;
    classDeaths: Record<PlayerClass, number>;
    highestFloor: number;
    highestScore: number;
  };
  unlockedTraits: string[];
  npcChoicesMade: Record<string, string>;
  /** Tracks which bosses were killed with which classes for zone unlocks. Key = "bossName|classId" */
  bossKillLog: string[];
}

// ── Trait system ──

export type TraitEffect =
  | { type: 'statBonus'; stat: keyof Stats; value: number }
  | { type: 'startingItem'; itemName: string }
  | { type: 'startingGold'; amount: number }
  | { type: 'hungerBonus'; value: number }
  | { type: 'xpMultiplier'; value: number }
  | { type: 'multi'; effects: TraitEffect[] };

export interface TraitDef {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  category: 'death' | 'combat' | 'exploration' | 'class' | 'npc' | 'legacy';
  condition: (b: BloodlineData) => boolean;
  effect: TraitEffect;
}

// ── NPC encounters ──

export type DialogueEffect =
  | { type: 'heal'; amount: number }
  | { type: 'gold'; amount: number }
  | { type: 'item'; itemName: string }
  | { type: 'statBuff'; stat: keyof Stats; amount: number }
  | { type: 'hunger'; amount: number }
  | { type: 'npcChoice'; eventId: string; choiceId: string }
  | { type: 'message'; text: string; color: string };

export interface DialogueChoice {
  label: string;
  responseText: string;
  effects: DialogueEffect[];
}

export interface DialogueNode {
  text: string;
  choices: DialogueChoice[];
}

export interface NPCDef {
  id: string;
  name: string;
  char: string;
  color: string;
  minFloor: number;
  spawnChance: number;
  requiresGeneration?: number;
  dialogue: DialogueNode | ((bloodline: BloodlineData) => DialogueNode);
}

export interface MapNPC {
  id: string;
  pos: Pos;
  defId: string;
  talked: boolean;
}

// ── Mercenary on the map ──
export interface MapMercenary {
  id: string;
  pos: Pos;
  defId: string;
  hired: boolean;
}

// ── Full game state ──
export interface GameState {
  player: Entity;
  playerClass: PlayerClass;
  zone: ZoneId;
  monsters: Entity[];
  items: MapItem[];
  floor: DungeonFloor;
  floorNumber: number;
  turn: number;
  messages: LogMessage[];
  gameOver: boolean;
  score: number;
  hunger: HungerState;
  survivalUsedThisFloor?: boolean;
  undyingWillUsedThisFloor?: boolean;
  beyondDeathUsedThisFloor?: boolean;
  shop: Shop | null;
  runStats: RunStats;
  npcs: MapNPC[];
  pendingNPC: string | null;
  xpMultiplier: number;
  _bloodlineRef?: BloodlineData;
  keysHeld: Record<KeyColor, number>;
  mercenaries: Entity[];
  mapMercenaries: MapMercenary[];
  pendingMercenary: string | null;
  bossesDefeatedThisRun: string[];
  premiumActive?: boolean;
}
