import { useRef, useEffect, useCallback, useState } from 'react';
import type { CSSProperties } from 'react';
import type { GameState } from './types';
import { renderView, viewToMap } from './renderer';
import { handleTapMove } from './engine';

const CELL_W = 12;
const CELL_H = 18;

interface GameViewProps {
  state: GameState;
  onChange: (s: GameState) => void;
}

export function GameView({ state, onChange }: GameViewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [viewSize, setViewSize] = useState({ w: 30, h: 20 });

  useEffect(() => {
    const measure = () => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const w = Math.floor(rect.width / CELL_W);
      const h = Math.floor(rect.height / CELL_H);
      setViewSize({ w: Math.max(10, w), h: Math.max(8, h) });
    };
    measure();
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const pixelW = viewSize.w * CELL_W;
    const pixelH = viewSize.h * CELL_H;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = pixelW * dpr;
    canvas.height = pixelH * dpr;
    canvas.style.width = `${pixelW}px`;
    canvas.style.height = `${pixelH}px`;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.scale(dpr, dpr);

    // Clear to black
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, pixelW, pixelH);

    const grid = renderView(state, viewSize.w, viewSize.h);

    // Pass 1: Draw background tiles
    for (let vy = 0; vy < viewSize.h; vy++) {
      for (let vx = 0; vx < viewSize.w; vx++) {
        const cell = grid[vy]?.[vx];
        if (!cell || cell.bg === '#000000' || cell.bg === '#000') continue;

        ctx.fillStyle = cell.bg;
        ctx.fillRect(vx * CELL_W, vy * CELL_H, CELL_W, CELL_H);
      }
    }

    // Pass 2: Draw glow halos behind special entities
    for (let vy = 0; vy < viewSize.h; vy++) {
      for (let vx = 0; vx < viewSize.w; vx++) {
        const cell = grid[vy]?.[vx];
        if (!cell?.glow) continue;

        const cx = vx * CELL_W + CELL_W / 2;
        const cy = vy * CELL_H + CELL_H / 2;
        const radius = Math.max(CELL_W, CELL_H) * 1.2;

        const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
        grad.addColorStop(0, hexToRgba(cell.glow, 0.2));
        grad.addColorStop(0.5, hexToRgba(cell.glow, 0.08));
        grad.addColorStop(1, 'rgba(0,0,0,0)');

        ctx.fillStyle = grad;
        ctx.fillRect(cx - radius, cy - radius, radius * 2, radius * 2);
      }
    }

    // Pass 3: Draw characters
    ctx.font = `bold ${CELL_H - 2}px monospace`;
    ctx.textBaseline = 'top';

    for (let vy = 0; vy < viewSize.h; vy++) {
      for (let vx = 0; vx < viewSize.w; vx++) {
        const cell = grid[vy]?.[vx];
        if (!cell || cell.char === ' ') continue;

        ctx.fillStyle = cell.color;
        ctx.fillText(cell.char, vx * CELL_W, vy * CELL_H + 1);
      }
    }
  }, [state, viewSize]);

  const handleTap = useCallback(
    (e: React.MouseEvent | React.TouchEvent) => {
      if (state.gameOver) return;
      const canvas = canvasRef.current;
      if (!canvas) return;

      let clientX: number;
      let clientY: number;
      if ('touches' in e) {
        const touch = e.touches[0];
        if (!touch) return;
        clientX = touch.clientX;
        clientY = touch.clientY;
      } else {
        clientX = e.clientX;
        clientY = e.clientY;
      }

      const rect = canvas.getBoundingClientRect();
      const vx = Math.floor((clientX - rect.left) / CELL_W);
      const vy = Math.floor((clientY - rect.top) / CELL_H);

      const mapPos = viewToMap(state, viewSize.w, viewSize.h, vx, vy);

      const next = structuredClone(state);
      if (handleTapMove(next, mapPos.x, mapPos.y)) {
        onChange(next);
      }
    },
    [state, viewSize, onChange],
  );

  return (
    <div ref={containerRef} style={containerStyle}>
      <canvas
        ref={canvasRef}
        style={canvasStyle}
        onClick={handleTap}
        onTouchStart={(e) => {
          e.preventDefault();
          handleTap(e);
        }}
      />
    </div>
  );
}

/** Convert a hex color to rgba string */
function hexToRgba(hex: string, alpha: number): string {
  // Already rgba?
  if (hex.startsWith('rgb')) return hex;
  const r = parseInt(hex.slice(1, 3), 16) || 0;
  const g = parseInt(hex.slice(3, 5), 16) || 0;
  const b = parseInt(hex.slice(5, 7), 16) || 0;
  return `rgba(${r},${g},${b},${alpha})`;
}

const containerStyle: CSSProperties = {
  flex: 1,
  width: '100%',
  overflow: 'hidden',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  background: '#000',
};

const canvasStyle: CSSProperties = {
  imageRendering: 'pixelated',
  touchAction: 'none',
};
