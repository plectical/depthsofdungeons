import { useState } from 'react';
import type { CSSProperties } from 'react';
import type { GameState, BloodlineData, DialogueChoice } from './types';
import { getNPCDef, getNPCDialogue } from './npcs';
import { applyDialogueEffects } from './engine';

interface NPCDialogueProps {
  state: GameState;
  bloodline: BloodlineData;
  onChange: (s: GameState) => void;
  onBloodlineChange: (b: BloodlineData) => void;
  onClose: () => void;
}

export function NPCDialogue({ state, bloodline, onChange, onBloodlineChange, onClose }: NPCDialogueProps) {
  const [response, setResponse] = useState<string | null>(null);

  const npc = state.npcs.find((n) => n.id === state.pendingNPC);
  if (!npc) return null;

  const def = getNPCDef(npc.defId);
  if (!def) return null;

  const dialogue = getNPCDialogue(def, bloodline);

  const handleChoice = (choice: DialogueChoice) => {
    const next = structuredClone(state);
    const bl = structuredClone(bloodline);

    // Check if merchant trade and player can't afford
    const goldCost = choice.effects.find((e) => e.type === 'gold');
    if (goldCost && goldCost.type === 'gold' && goldCost.amount < 0 && next.score < Math.abs(goldCost.amount)) {
      setResponse("You don't have enough gold!");
      return;
    }

    applyDialogueEffects(next, choice.effects, bl);

    // Mark NPC as talked
    const npcRef = next.npcs.find((n) => n.id === npc.id);
    if (npcRef) npcRef.talked = true;
    next.pendingNPC = null;

    setResponse(choice.responseText);
    onBloodlineChange(bl);

    setTimeout(() => {
      onChange(next);
      onClose();
    }, 1500);
  };

  return (
    <div style={overlayStyle}>
      <div style={panelStyle}>
        <div style={headerStyle}>
          <span style={{ color: def.color, fontSize: 20, fontWeight: 'bold', marginRight: 8, textShadow: `0 0 8px ${def.color}44` }}>
            {def.char}
          </span>
          <span style={{ ...titleStyle, color: def.color }}>{def.name}</span>
        </div>

        <div style={dialogueStyle}>
          <span style={quoteStyle}>"</span>
          {response ?? dialogue.text}
          <span style={quoteStyle}>"</span>
        </div>

        {!response && (
          <div style={choicesStyle}>
            {dialogue.choices.map((choice, i) => (
              <button
                key={i}
                style={choiceBtnStyle}
                onClick={() => handleChoice(choice)}
              >
                {choice.label}
              </button>
            ))}
          </div>
        )}

        {response && (
          <div style={{ color: '#1a6a2a', fontSize: 10, textAlign: 'center', padding: '8px 0', fontFamily: 'monospace' }}>
            ...
          </div>
        )}
      </div>
    </div>
  );
}

const overlayStyle: CSSProperties = {
  position: 'absolute',
  inset: 0,
  background: 'rgba(0,0,0,0.92)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 50,
  padding: 12,
};

const panelStyle: CSSProperties = {
  width: '100%',
  maxWidth: 340,
  background: '#000',
  border: '1px solid #3a3a5a',
  borderRadius: 0,
  display: 'flex',
  flexDirection: 'column',
  overflow: 'hidden',
};

const headerStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  padding: '10px 12px',
  borderBottom: '1px solid #2a2a4a',
};

const titleStyle: CSSProperties = {
  fontFamily: 'monospace',
  fontSize: 14,
  fontWeight: 'bold',
};

const dialogueStyle: CSSProperties = {
  padding: '14px 16px',
  color: '#aaccaa',
  fontFamily: 'monospace',
  fontSize: 12,
  lineHeight: '18px',
};

const quoteStyle: CSSProperties = {
  color: '#3a6a3a',
  fontSize: 14,
};

const choicesStyle: CSSProperties = {
  display: 'flex',
  gap: 8,
  padding: '8px 16px 14px',
  justifyContent: 'center',
};

const choiceBtnStyle: CSSProperties = {
  padding: '8px 14px',
  fontSize: 12,
  fontFamily: 'monospace',
  fontWeight: 'bold',
  background: '#000',
  color: '#33ff66',
  border: '1px solid #1a5a2a',
  borderRadius: 0,
  cursor: 'pointer',
  letterSpacing: 1,
  minWidth: 100,
  touchAction: 'none',
};
