import { useState, useCallback, useEffect, useRef } from 'react';
import type { CSSProperties } from 'react';
import RundotGameAPI from '@series-inc/rundot-game-sdk/api';
import type { GameState, PlayerClass, BloodlineData, AncestorRecord, TraitDef, ZoneId } from './types';
import { newGame, waitTurn, movePlayer, isAtShop, extractCauseOfDeath } from './engine';
import { CLASS_DEFS } from './constants';
import { createDefaultBloodline, mergeRunIntoBloodline, checkForNewTraits, generateAncestorName, computeBloodlineBonuses } from './traits';
import { GameView } from './GameView';
import { HUD } from './HUD';
import { MessageLog } from './MessageLog';
import { Inventory } from './Inventory';
import { DPad } from './DPad';
import { Shop } from './Shop';
import { NPCDialogue } from './NPCDialogue';
import { BloodlineView } from './BloodlineView';
import { MercenaryHire } from './MercenaryHire';
import { autoplayStep } from './autoplay';
import { Leaderboard } from './Leaderboard';
import { NecropolisView } from './NecropolisView';
import { getNecropolisClasses } from './necropolis';
import { reportDeath, getNecropolisState, connectToNecropolis } from './necropolisService';
import { ZONE_DEFS, isZoneUnlocked } from './zones';

type Screen = 'title' | 'classSelect' | 'zoneSelect' | 'game' | 'gameover';

interface DeathInfo {
  ancestor: AncestorRecord;
  newTraits: TraitDef[];
  generation: number;
}

export function Game() {
  const [screen, setScreen] = useState<Screen>('title');
  const [state, setState] = useState<GameState | null>(null);
  const [showInventory, setShowInventory] = useState(false);
  const [showShop, setShowShop] = useState(false);
  const [showNPCDialogue, setShowNPCDialogue] = useState(false);
  const [showMercHire, setShowMercHire] = useState(false);
  const [showBloodline, setShowBloodline] = useState(false);
  const [autoPlay, setAutoPlay] = useState(false);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [showNecropolis, setShowNecropolis] = useState(false);
  const [bestFloor, setBestFloor] = useState(1);
  const [bloodline, setBloodline] = useState<BloodlineData>(createDefaultBloodline());
  const [deathInfo, setDeathInfo] = useState<DeathInfo | null>(null);
  const [isPremium, setIsPremium] = useState(false);
  const [selectedClass, setSelectedClass] = useState<PlayerClass>('warrior');
  const startTimeRef = useRef(0);
  const autoTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const bloodlineRef = useRef<BloodlineData>(createDefaultBloodline());

  // Keep ref in sync
  useEffect(() => {
    bloodlineRef.current = bloodline;
  }, [bloodline]);

  // Load best floor + bloodline on mount, and connect to necropolis
  useEffect(() => {
    async function loadData() {
      try {
        const val = await RundotGameAPI.appStorage.getItem('bestFloor');
        if (val) setBestFloor(parseInt(val, 10) || 1);
      } catch { /* first time */ }
      try {
        const raw = await RundotGameAPI.appStorage.getItem('bloodline');
        if (raw) {
          const bl = JSON.parse(raw) as BloodlineData;
          // Backward compat: ensure bossKillLog exists for older saves
          if (!bl.bossKillLog) bl.bossKillLog = [];
          setBloodline(bl);
          bloodlineRef.current = bl;
        }
      } catch { /* first time */ }
      // Pre-connect to necropolis in the background
      connectToNecropolis().catch(() => {});
      // Check premium subscription status
      try {
        const status = await RundotGameAPI.iap.getUserSubscriptionStatus('CORE');
        setIsPremium(status != null);
      } catch { /* not subscribed */ }
    }
    loadData();
  }, []);

  const saveBloodline = useCallback((bl: BloodlineData) => {
    setBloodline(bl);
    bloodlineRef.current = bl;
    RundotGameAPI.appStorage.setItem('bloodline', JSON.stringify(bl)).catch(() => {});
  }, []);

  const startGame = useCallback(() => {
    setScreen('classSelect');
  }, []);

  const handlePremiumPurchase = useCallback(async () => {
    try {
      const subs = await RundotGameAPI.iap.getSubscriptionsForOffering('CORE');
      const weekly = subs.find(s => s.packageType === 'weekly');
      if (!weekly) return;
      const result = await RundotGameAPI.iap.purchaseSubscriptionFromOffering('CORE', weekly.productId);
      if (result.success) {
        setIsPremium(true);
      }
    } catch {
      // Purchase cancelled or failed
    }
  }, []);

  const selectClassAndPickZone = useCallback((cls: PlayerClass) => {
    setSelectedClass(cls);
    setScreen('zoneSelect');
  }, []);

  const beginGame = useCallback((zone: ZoneId) => {
    const gs = newGame(selectedClass, bloodlineRef.current, zone);
    gs.premiumActive = isPremium;
    setState(gs);
    setScreen('game');
    setShowInventory(false);
    setShowShop(false);
    setShowNPCDialogue(false);
    setShowMercHire(false);
    setAutoPlay(false);
    startTimeRef.current = Date.now();
  }, [isPremium, selectedClass]);

  const processDeathBloodline = useCallback((finalState: GameState) => {
    const bl = structuredClone(bloodlineRef.current);

    // Merge run stats
    mergeRunIntoBloodline(bl, finalState.runStats);
    bl.cumulative.classDeaths[finalState.playerClass] =
      (bl.cumulative.classDeaths[finalState.playerClass] ?? 0) + 1;
    bl.cumulative.highestFloor = Math.max(bl.cumulative.highestFloor, finalState.floorNumber);
    bl.cumulative.highestScore = Math.max(bl.cumulative.highestScore, finalState.score);
    bl.cumulative.totalScore += finalState.score;
    bl.cumulative.totalTurns += finalState.turn;

    // Create ancestor
    const ancestor: AncestorRecord = {
      name: generateAncestorName(),
      class: finalState.playerClass,
      floorReached: finalState.floorNumber,
      level: finalState.player.level,
      score: finalState.score,
      killCount: finalState.runStats.kills,
      causeOfDeath: extractCauseOfDeath(finalState),
      turnsLived: finalState.turn,
    };

    bl.ancestors.push(ancestor);
    if (bl.ancestors.length > 5) bl.ancestors.shift();
    bl.generation++;

    // Merge NPC choices from the game state bloodline ref (they're written during dialogue)
    if (finalState._bloodlineRef) {
      Object.assign(bl.npcChoicesMade, finalState._bloodlineRef.npcChoicesMade);
    }

    // Record boss kills with class for zone unlocks
    for (const bossName of finalState.bossesDefeatedThisRun) {
      const key = `${bossName}|${finalState.playerClass}`;
      if (!bl.bossKillLog.includes(key)) {
        bl.bossKillLog.push(key);
      }
    }

    // Check for new traits
    const newTraits = checkForNewTraits(bl);
    for (const trait of newTraits) {
      bl.unlockedTraits.push(trait.id);
    }

    setDeathInfo({ ancestor, newTraits, generation: bl.generation });
    saveBloodline(bl);

    // Report death to the Necropolis for communal unlocks
    reportDeath().catch(() => {});
  }, [saveBloodline]);

  const handleChange = useCallback((next: GameState) => {
    // Track best floor reached during gameplay
    if (next.floorNumber > bestFloor) {
      setBestFloor(next.floorNumber);
      RundotGameAPI.appStorage.setItem('bestFloor', String(next.floorNumber)).catch(() => {});
    }
    if (next.gameOver) {
      setState(next);
      processDeathBloodline(next);
      setTimeout(async () => {
        // Show a forced ad on death — skipped for premium subscribers
        if (!isPremium) {
          try {
            await RundotGameAPI.ads.showInterstitialAd();
          } catch {
            // Ad failed or unavailable — continue to game over screen
          }
        }
        const duration = Math.floor((Date.now() - startTimeRef.current) / 1000);
        submitScore(next.score, duration);
        setScreen('gameover');
      }, 800);
      return;
    }
    // Auto-open shop when stepping on shopkeeper
    if (isAtShop(next) && next.shop && next.shop.stock.length > 0) {
      setShowShop(true);
    }
    // Auto-open NPC dialogue
    if (next.pendingNPC) {
      setShowNPCDialogue(true);
    }
    // Auto-open mercenary hire
    if (next.pendingMercenary) {
      setShowMercHire(true);
    }
    setState(next);
  }, [bestFloor, processDeathBloodline, isPremium]);

  const handleWait = useCallback(() => {
    if (!state || state.gameOver) return;
    const next = structuredClone(state);
    waitTurn(next);
    handleChange(next);
  }, [state, handleChange]);

  const handleDPad = useCallback(
    (dx: number, dy: number) => {
      if (!state || state.gameOver) return;
      const next = structuredClone(state);
      if (movePlayer(next, dx, dy)) {
        handleChange(next);
      }
    },
    [state, handleChange],
  );

  useEffect(() => {
    if (screen !== 'game' || !state) return;
    const handleKey = (e: KeyboardEvent) => {
      let dx = 0;
      let dy = 0;
      switch (e.key) {
        case 'ArrowUp':
        case 'w':
          dy = -1;
          break;
        case 'ArrowDown':
        case 's':
          dy = 1;
          break;
        case 'ArrowLeft':
        case 'a':
          dx = -1;
          break;
        case 'ArrowRight':
        case 'd':
          dx = 1;
          break;
        case 'i':
          setShowInventory((v) => !v);
          return;
        case '.':
          handleWait();
          return;
        default:
          return;
      }
      if (dx !== 0 || dy !== 0) {
        const next = structuredClone(state);
        if (movePlayer(next, dx, dy)) {
          handleChange(next);
        }
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [screen, state, handleChange, handleWait]);

  // Auto-play loop
  useEffect(() => {
    if (!autoPlay || screen !== 'game' || !state || state.gameOver) {
      if (autoTimerRef.current) {
        clearInterval(autoTimerRef.current);
        autoTimerRef.current = null;
      }
      if (state?.gameOver) setAutoPlay(false);
      return;
    }

    autoTimerRef.current = setInterval(() => {
      setState((prev) => {
        if (!prev || prev.gameOver) {
          setAutoPlay(false);
          return prev;
        }
        const next = autoplayStep(prev);
        if (next) {
          if (next.gameOver) {
            processDeathBloodline(next);
            setTimeout(async () => {
              // Show a forced ad on death — skipped for premium subscribers
              if (!isPremium) {
                try {
                  await RundotGameAPI.ads.showInterstitialAd();
                } catch {
                  // Ad failed or unavailable — continue to game over screen
                }
              }
              const duration = Math.floor((Date.now() - startTimeRef.current) / 1000);
              submitScore(next.score, duration);
              setScreen('gameover');
              setAutoPlay(false);
            }, 800);
          }
          return next;
        }
        return prev;
      });
    }, 200);

    return () => {
      if (autoTimerRef.current) {
        clearInterval(autoTimerRef.current);
        autoTimerRef.current = null;
      }
    };
  }, [autoPlay, screen, state?.gameOver, processDeathBloodline, isPremium]);

  async function submitScore(score: number, duration: number) {
    try {
      const token = await RundotGameAPI.leaderboard.createScoreToken();
      await RundotGameAPI.leaderboard.submitScore({
        token: token.token,
        score,
        duration,
      });
    } catch {
      // Score submission is best-effort
    }
  }

  // ── Bloodline bonus summary for class select ──
  const bonuses = computeBloodlineBonuses(bloodline);
  const bonusParts: string[] = [];
  if (bonuses.statBonuses.maxHp) bonusParts.push(`+${bonuses.statBonuses.maxHp} HP`);
  if (bonuses.statBonuses.attack) bonusParts.push(`+${bonuses.statBonuses.attack} Atk`);
  if (bonuses.statBonuses.defense) bonusParts.push(`+${bonuses.statBonuses.defense} Def`);
  if (bonuses.statBonuses.speed) bonusParts.push(`+${bonuses.statBonuses.speed} Spd`);
  if (bonuses.hungerBonus) bonusParts.push(`+${bonuses.hungerBonus} Hunger`);
  if (bonuses.startingGold) bonusParts.push(`+${bonuses.startingGold}g`);
  if (bonuses.startingItems.length) bonusParts.push(`+${bonuses.startingItems.length} items`);

  // ── SCREENS ──

  if (screen === 'title') {
    return (
      <div style={titleScreenStyle}>
        <img
          src="/title-bg.jpg"
          alt=""
          style={titleBgImageStyle}
        />
        <div style={titleOverlayStyle}>
          <div style={titleTextStyle}>ASCII DUNGEON</div>
          <div style={subtitleStyle}>{'~ An ASCII Roguelike ~'}</div>
          {bloodline.generation > 0 && (
            <div style={{ color: '#c49eff', fontFamily: 'monospace', fontSize: 11, opacity: 0.7 }}>
              Generation {bloodline.generation} | {bloodline.unlockedTraits.length} traits unlocked
            </div>
          )}
          <button style={playBtnStyle} onClick={startGame}>
            {'[ Enter the Dungeon ]'}
          </button>
          <button style={necropolisBtnStyle} onClick={() => setShowNecropolis(true)}>
            {'[ Necropolis ]'}
          </button>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={secondaryBtnStyle} onClick={() => setShowLeaderboard(true)}>
              {'[ Leaderboard ]'}
            </button>
            <button style={bloodlineBtnStyle} onClick={() => setShowBloodline(true)}>
              {'[ Bloodline ]'}
            </button>
          </div>
          <div style={hintStyle}>{'Tap to move . Find the stairs > . Survive .'}</div>
          {isPremium ? (
            <div style={premiumActiveLabelStyle}>&#x2B50; Premium Active</div>
          ) : (
            <button style={premiumBtnStyle} onClick={handlePremiumPurchase}>
              {'⭐ [ No Ads + Slower Hunger — $1.99/wk ]'}
            </button>
          )}
        </div>
        {showLeaderboard && <Leaderboard onClose={() => setShowLeaderboard(false)} />}
        {showBloodline && <BloodlineView bloodline={bloodline} onClose={() => setShowBloodline(false)} />}
        {showNecropolis && <NecropolisView onClose={() => setShowNecropolis(false)} />}
      </div>
    );
  }

  if (screen === 'classSelect') {
    return (
      <div style={fullScreenStyle}>
        <div style={{ ...titleTextStyle, fontSize: 20 }}>Choose Your Class</div>
        <div style={{ color: '#1a8a3a', fontFamily: 'monospace', fontSize: 11, marginBottom: 2 }}>
          Deepest floor reached: {bestFloor}
        </div>
        {bloodline.generation > 0 && (
          <div style={{ color: '#c49eff', fontFamily: 'monospace', fontSize: 10, marginBottom: 4 }}>
            Gen {bloodline.generation} | Traits: {bloodline.unlockedTraits.length}/20
            {bonusParts.length > 0 && <> | {bonusParts.join(' ')}</>}
          </div>
        )}
        <div style={classGridStyle}>
          {[...CLASS_DEFS, ...getNecropolisClasses(getNecropolisState().communalDeaths)].map((cls) => {
            const locked = bestFloor < cls.requiresBestFloor;
            return (
              <button
                key={cls.id}
                style={locked ? classCardLockedStyle : classCardStyle}
                onClick={() => { if (!locked) selectClassAndPickZone(cls.id); }}
                disabled={locked}
              >
                {locked ? (
                  <>
                    <div style={{ color: cls.color, fontSize: 20, fontWeight: 'bold', opacity: 0.4 }}>
                      [x] {cls.name}
                    </div>
                    <div style={{ color: '#1a5a2a', fontSize: 10, marginTop: 4 }}>{cls.description}</div>
                    <div style={{ color: '#33ff66', fontSize: 10, marginTop: 6, opacity: 0.5 }}>
                      HP:?? Atk:?? Def:?? Spd:??
                    </div>
                    <div style={{ color: '#ffd700', fontSize: 10, marginTop: 6, fontWeight: 'bold' }}>
                      Reach floor {cls.requiresBestFloor} to unlock
                    </div>
                  </>
                ) : (
                  <>
                    <div style={{ color: cls.color, fontSize: 20, fontWeight: 'bold', textShadow: `0 0 8px ${cls.color}44` }}>
                      {cls.char} {cls.name}
                    </div>
                    <div style={{ color: '#1a8a3a', fontSize: 10, marginTop: 4 }}>{cls.description}</div>
                    <div style={{ color: '#33ff66', fontSize: 10, marginTop: 6 }}>
                      HP:{cls.baseStats.hp} Atk:{cls.baseStats.attack} Def:{cls.baseStats.defense} Spd:{cls.baseStats.speed}
                    </div>
                    <div style={{ marginTop: 6 }}>
                      {cls.passives.map((p) => (
                        <div key={p.name} style={{ color: p.unlockLevel <= 1 ? '#33ff66' : '#0a5a1a', fontSize: 9, lineHeight: '13px' }}>
                          Lv{p.unlockLevel}: {p.name}
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </button>
            );
          })}
        </div>
        <button style={secondaryBtnStyle} onClick={() => setScreen('title')}>
          {'[ Back ]'}
        </button>
      </div>
    );
  }

  if (screen === 'zoneSelect') {
    const bossLog = bloodline.bossKillLog ?? [];
    return (
      <div style={{ ...fullScreenStyle, overflowY: 'auto', justifyContent: 'flex-start', paddingTop: 20 }}>
        <div style={{ ...titleTextStyle, fontSize: 20 }}>Choose Your Zone</div>
        <div style={{ color: '#1a8a3a', fontFamily: 'monospace', fontSize: 11, marginBottom: 4 }}>
          Defeat bosses with specific characters to unlock new zones
        </div>
        <div style={classGridStyle}>
          {ZONE_DEFS.map((zone) => {
            const unlocked = isZoneUnlocked(zone.id, bossLog);
            return (
              <button
                key={zone.id}
                style={unlocked ? { ...classCardStyle, borderColor: zone.color + '66' } : classCardLockedStyle}
                onClick={() => { if (unlocked) beginGame(zone.id); }}
                disabled={!unlocked}
              >
                {unlocked ? (
                  <>
                    <div style={{ color: zone.color, fontSize: 18, fontWeight: 'bold', textShadow: `0 0 8px ${zone.color}44` }}>
                      {zone.icon} {zone.name}
                    </div>
                    <div style={{ color: '#1a8a3a', fontSize: 10, marginTop: 4, lineHeight: '14px' }}>
                      {zone.description}
                    </div>
                    <div style={{ color: zone.color, fontSize: 9, marginTop: 6, opacity: 0.7 }}>
                      Floors {zone.floorRange.min}-{zone.floorRange.max}
                    </div>
                  </>
                ) : (
                  <>
                    <div style={{ color: zone.color, fontSize: 18, fontWeight: 'bold', opacity: 0.4 }}>
                      [x] {zone.name}
                    </div>
                    <div style={{ color: '#1a5a2a', fontSize: 10, marginTop: 4, lineHeight: '14px' }}>
                      {zone.description}
                    </div>
                    <div style={{ marginTop: 6 }}>
                      {zone.unlockRequirements.map((req, i) => {
                        const done = bossLog.includes(`${req.bossName}|${req.withClass}`);
                        return (
                          <div key={i} style={{ color: done ? '#33ff66' : '#ffd700', fontSize: 9, lineHeight: '13px' }}>
                            {done ? '✓' : '○'} Beat {req.bossName} as {req.withClass.charAt(0).toUpperCase() + req.withClass.slice(1)}
                          </div>
                        );
                      })}
                    </div>
                  </>
                )}
              </button>
            );
          })}
        </div>
        <button style={secondaryBtnStyle} onClick={() => setScreen('classSelect')}>
          {'[ Back ]'}
        </button>
      </div>
    );
  }

  if (screen === 'gameover' && state) {
    return (
      <div style={{ ...fullScreenStyle, overflowY: 'auto', justifyContent: 'flex-start', paddingTop: 30 }}>
        <div style={asciiBoxStyle}>
          <pre style={asciiFrameStyle}>{'+-====== GAME OVER ======-+'}</pre>
          <div style={gameOverTitleStyle}>YOU HAVE PERISHED</div>
          <div style={scoreLineStyle}>{'Floor Reached .. '}{state.floorNumber}</div>
          <div style={scoreLineStyle}>{'Level .......... '}{state.player.level}</div>
          <div style={scoreLineStyle}>{'Turns Survived . '}{state.turn}</div>
          <div style={scoreLineStyle}>{'Kills .......... '}{state.runStats.kills}</div>
          <div style={{ ...scoreLineStyle, color: '#ffd700' }}>{'Score .......... '}{state.score}</div>
          <pre style={asciiFrameStyle}>{'+-========================-+'}</pre>
        </div>

        {deathInfo && (
          <div style={bloodlineBoxStyle}>
            <div style={{ color: '#c49eff', fontSize: 12, fontWeight: 'bold', marginBottom: 6, fontFamily: 'monospace', textShadow: '0 0 6px #c49eff33' }}>
              ~ BLOODLINE ~
            </div>
            <div style={{ color: '#8a7aaa', fontSize: 11, fontFamily: 'monospace' }}>
              + Ancestor Added:
            </div>
            <div style={{ color: '#c49eff', fontSize: 11, fontFamily: 'monospace', marginLeft: 8 }}>
              "{deathInfo.ancestor.name}" ({deathInfo.ancestor.class.charAt(0).toUpperCase() + deathInfo.ancestor.class.slice(1)})
            </div>

            {deathInfo.newTraits.length > 0 && (
              <>
                <div style={{ color: '#33ff66', fontSize: 11, fontFamily: 'monospace', marginTop: 8, fontWeight: 'bold' }}>
                  + NEW TRAITS UNLOCKED:
                </div>
                {deathInfo.newTraits.map((t) => (
                  <div key={t.id} style={{ marginLeft: 8, marginTop: 4 }}>
                    <div style={{ color: t.color, fontSize: 11, fontFamily: 'monospace', fontWeight: 'bold' }}>
                      [{t.icon}] {t.name}
                    </div>
                    <div style={{ color: '#1a6a2a', fontSize: 9, fontFamily: 'monospace', marginLeft: 16 }}>
                      {t.description}
                    </div>
                  </div>
                ))}
              </>
            )}

            <div style={{ color: '#6a5a8a', fontSize: 10, fontFamily: 'monospace', marginTop: 8 }}>
              Generation: {deathInfo.generation} | Traits: {bloodline.unlockedTraits.length}/20
            </div>
          </div>
        )}

        <button style={playBtnStyle} onClick={startGame}>
          {'[ Try Again ]'}
        </button>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'center' }}>
          <button style={necropolisBtnStyle} onClick={() => setShowNecropolis(true)}>
            {'[ Necropolis ]'}
          </button>
          <button style={secondaryBtnStyle} onClick={() => setShowLeaderboard(true)}>
            {'[ Leaderboard ]'}
          </button>
          <button style={bloodlineBtnStyle} onClick={() => setShowBloodline(true)}>
            {'[ Bloodline ]'}
          </button>
        </div>
        {showLeaderboard && <Leaderboard onClose={() => setShowLeaderboard(false)} />}
        {showBloodline && <BloodlineView bloodline={bloodline} onClose={() => setShowBloodline(false)} />}
        {showNecropolis && <NecropolisView onClose={() => setShowNecropolis(false)} />}
      </div>
    );
  }

  if (!state) return null;

  return (
    <div style={gameContainerStyle}>
      <HUD state={state} generation={bloodline.generation} isPremium={isPremium} />
      <GameView state={state} onChange={handleChange} />
      <MessageLog messages={state.messages} />
      <div style={bottomBarStyle}>
        <DPad onMove={handleDPad} />
        <div style={sideButtonsStyle}>
          <button style={actionBtnStyle} onClick={() => setShowInventory(true)}>
            {'[ Bag ]'}
          </button>
          {isAtShop(state) && state.shop && state.shop.stock.length > 0 && (
            <button style={shopBtnStyle} onClick={() => setShowShop(true)}>
              {'[ Shop ]'}
            </button>
          )}
          <button style={actionBtnStyle} onClick={handleWait}>
            {'[ Wait ]'}
          </button>
          <button
            style={autoPlay ? autoBtnActiveStyle : actionBtnStyle}
            onClick={() => setAutoPlay((v) => !v)}
          >
            {autoPlay ? '[ Stop ]' : '[ Auto ]'}
          </button>
        </div>
      </div>
      {showInventory && <Inventory state={state} onChange={handleChange} onClose={() => setShowInventory(false)} />}
      {showShop && <Shop state={state} onChange={handleChange} onClose={() => setShowShop(false)} />}
      {showNPCDialogue && state.pendingNPC && (
        <NPCDialogue
          state={state}
          bloodline={bloodline}
          onChange={(next) => {
            setShowNPCDialogue(false);
            handleChange(next);
          }}
          onBloodlineChange={saveBloodline}
          onClose={() => {
            setShowNPCDialogue(false);
            setState((prev) => {
              if (!prev) return prev;
              const next = structuredClone(prev);
              next.pendingNPC = null;
              return next;
            });
          }}
        />
      )}
      {showMercHire && state.pendingMercenary && (
        <MercenaryHire
          state={state}
          onChange={(next) => {
            setShowMercHire(false);
            handleChange(next);
          }}
          onClose={() => {
            setShowMercHire(false);
            setState((prev) => {
              if (!prev) return prev;
              const next = structuredClone(prev);
              next.pendingMercenary = null;
              return next;
            });
          }}
        />
      )}
    </div>
  );
}

const titleScreenStyle: CSSProperties = {
  position: 'relative',
  width: '100%',
  height: '100%',
  overflow: 'hidden',
  background: '#000',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
};

const titleBgImageStyle: CSSProperties = {
  display: 'block',
  maxWidth: '100%',
  maxHeight: '60%',
  objectFit: 'contain',
  marginTop: 20,
};

const titleOverlayStyle: CSSProperties = {
  flex: 1,
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 12,
  paddingBottom: 40,
};

const titleTextStyle: CSSProperties = {
  color: '#33ff66',
  fontFamily: 'monospace',
  fontSize: 28,
  fontWeight: 'bold',
  letterSpacing: 6,
  textShadow: '0 0 20px #33ff6666, 0 2px 4px #000',
};

const fullScreenStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  width: '100%',
  height: '100%',
  background: '#000',
  padding: 20,
  gap: 16,
};

const subtitleStyle: CSSProperties = {
  color: '#1a8a3a',
  fontFamily: 'monospace',
  fontSize: 14,
  letterSpacing: 4,
};

const playBtnStyle: CSSProperties = {
  padding: '10px 20px',
  fontSize: 16,
  fontFamily: 'monospace',
  fontWeight: 'bold',
  background: '#000',
  color: '#33ff66',
  border: '1px solid #33ff66',
  borderRadius: 0,
  cursor: 'pointer',
  marginTop: 8,
  letterSpacing: 2,
  textShadow: '0 0 8px #33ff6644',
  boxShadow: '0 0 10px #33ff6622',
};

const secondaryBtnStyle: CSSProperties = {
  padding: '8px 16px',
  fontSize: 13,
  fontFamily: 'monospace',
  fontWeight: 'bold',
  background: '#000',
  color: '#1a8a3a',
  border: '1px solid #1a5a2a',
  borderRadius: 0,
  cursor: 'pointer',
  letterSpacing: 2,
  textShadow: '0 0 4px #33ff6633',
};

const bloodlineBtnStyle: CSSProperties = {
  padding: '8px 16px',
  fontSize: 13,
  fontFamily: 'monospace',
  fontWeight: 'bold',
  background: '#000',
  color: '#c49eff',
  border: '1px solid #4a3a6a',
  borderRadius: 0,
  cursor: 'pointer',
  letterSpacing: 2,
  textShadow: '0 0 4px #c49eff33',
};

const necropolisBtnStyle: CSSProperties = {
  padding: '8px 16px',
  fontSize: 13,
  fontFamily: 'monospace',
  fontWeight: 'bold',
  background: '#000',
  color: '#cc44ff',
  border: '1px solid #6a2a8a',
  borderRadius: 0,
  cursor: 'pointer',
  letterSpacing: 2,
  textShadow: '0 0 6px #cc44ff44',
  boxShadow: '0 0 8px #cc44ff22',
};

const hintStyle: CSSProperties = {
  color: '#1a6a2a',
  fontFamily: 'monospace',
  fontSize: 11,
  marginTop: 4,
  letterSpacing: 1,
};

const asciiBoxStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  gap: 6,
  padding: '8px 20px',
  fontFamily: 'monospace',
};

const asciiFrameStyle: CSSProperties = {
  color: '#1a8a3a',
  fontSize: 13,
  margin: 0,
  fontFamily: 'monospace',
  textShadow: '0 0 6px #33ff6622',
};

const gameOverTitleStyle: CSSProperties = {
  color: '#ff3333',
  fontFamily: 'monospace',
  fontSize: 18,
  fontWeight: 'bold',
  letterSpacing: 4,
  marginBottom: 8,
  textShadow: '0 0 12px #ff333344',
};

const scoreLineStyle: CSSProperties = {
  color: '#33ff66',
  fontFamily: 'monospace',
  fontSize: 13,
  letterSpacing: 1,
};

const bloodlineBoxStyle: CSSProperties = {
  border: '1px solid #4a3a6a',
  padding: '10px 14px',
  maxWidth: 320,
  width: '100%',
};

const gameContainerStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  width: '100%',
  height: '100%',
  background: '#000',
  position: 'relative',
  overflow: 'hidden',
};

const bottomBarStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 16,
  padding: '4px 12px 8px',
  background: '#000',
  borderTop: '1px solid #1a5a2a',
};

const sideButtonsStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 8,
};

const actionBtnStyle: CSSProperties = {
  padding: '8px 14px',
  fontSize: 13,
  fontFamily: 'monospace',
  fontWeight: 'bold',
  background: '#000',
  color: '#33ff66',
  border: '1px solid #1a5a2a',
  borderRadius: 0,
  cursor: 'pointer',
  minWidth: 80,
  touchAction: 'none',
  letterSpacing: 1,
  textShadow: '0 0 4px #33ff6633',
};

const autoBtnActiveStyle: CSSProperties = {
  ...actionBtnStyle,
  color: '#66ffaa',
  border: '1px solid #33ff66',
  boxShadow: '0 0 8px #33ff6633',
  textShadow: '0 0 6px #66ffaa44',
};

const shopBtnStyle: CSSProperties = {
  ...actionBtnStyle,
  color: '#ffd700',
  border: '1px solid #8a6a1a',
  textShadow: '0 0 4px #ffd70044',
};

const classGridStyle: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(2, 1fr)',
  gap: 8,
  padding: '0 12px',
  maxWidth: 360,
  width: '100%',
};

const classCardStyle: CSSProperties = {
  background: '#000',
  border: '1px solid #1a5a2a',
  borderRadius: 0,
  padding: '10px 10px',
  cursor: 'pointer',
  textAlign: 'left',
  fontFamily: 'monospace',
  display: 'flex',
  flexDirection: 'column',
};

const classCardLockedStyle: CSSProperties = {
  ...classCardStyle,
  opacity: 0.7,
  cursor: 'not-allowed',
  border: '1px solid #0a2a0a',
  background: '#060606',
};

const premiumBtnStyle: CSSProperties = {
  padding: '8px 14px',
  fontSize: 11,
  fontFamily: 'monospace',
  fontWeight: 'bold',
  background: '#000',
  color: '#ffd700',
  border: '1px solid #8a6a1a',
  borderRadius: 0,
  cursor: 'pointer',
  letterSpacing: 1,
  textShadow: '0 0 6px #ffd70044',
  boxShadow: '0 0 8px #ffd70022',
  marginTop: 4,
};

const premiumActiveLabelStyle: CSSProperties = {
  color: '#ffd700',
  fontFamily: 'monospace',
  fontSize: 11,
  fontWeight: 'bold',
  textShadow: '0 0 6px #ffd70044',
  marginTop: 4,
  opacity: 0.8,
};
