import type { MonsterDef, Item, ClassDef, PlayerClass } from './types';

// ── Necropolis Unlock Categories ──

export type UnlockCategory = 'item' | 'enemy' | 'dungeon' | 'class' | 'weapon' | 'armor' | 'zone';

export interface NecropolisUnlock {
  id: string;
  name: string;
  description: string;
  category: UnlockCategory;
  deathsRequired: number;
  icon: string;
  color: string;
}

// ── Communal death state (synced via multiplayer room) ──

export interface NecropolisState {
  communalDeaths: number;
  unlockedIds: string[];
  lastUpdated: number;
}

export function createDefaultNecropolisState(): NecropolisState {
  return {
    communalDeaths: 0,
    unlockedIds: [],
    lastUpdated: Date.now(),
  };
}

// ── All Necropolis Unlocks ──
// Players collectively die to unlock new content for everyone

export const NECROPOLIS_UNLOCKS: NecropolisUnlock[] = [
  // ─── WEAPONS (unlocked early to mid) ───
  {
    id: 'weapon_bone_club',
    name: 'Bone Club',
    description: 'Forged from the fallen. +3 attack.',
    category: 'weapon',
    deathsRequired: 5,
    icon: ')',
    color: '#e8d8b8',
  },
  {
    id: 'weapon_soul_reaper',
    name: 'Soul Reaper',
    description: 'Feeds on death energy. +9 attack.',
    category: 'weapon',
    deathsRequired: 50,
    icon: ')',
    color: '#cc44ff',
  },
  {
    id: 'weapon_death_scythe',
    name: "Death's Scythe",
    description: 'The ultimate reaping tool. +17 attack.',
    category: 'weapon',
    deathsRequired: 200,
    icon: ')',
    color: '#ff2222',
  },

  // ─── ARMOR (early to mid) ───
  {
    id: 'armor_bone_mail',
    name: 'Bone Mail',
    description: 'Woven from ancestral bones. +3 defense.',
    category: 'armor',
    deathsRequired: 10,
    icon: '[',
    color: '#d8c8a8',
  },
  {
    id: 'armor_spectral_shroud',
    name: 'Spectral Shroud',
    description: 'Ghosts protect you. +6 defense.',
    category: 'armor',
    deathsRequired: 75,
    icon: '[',
    color: '#aaaaff',
  },
  {
    id: 'armor_necro_plate',
    name: 'Necropolis Plate',
    description: 'Forged in mass sacrifice. +13 defense.',
    category: 'armor',
    deathsRequired: 250,
    icon: '[',
    color: '#8822cc',
  },

  // ─── ITEMS (consumables/accessories) ───
  {
    id: 'item_death_ward',
    name: 'Death Ward',
    description: 'A charm that restores 20 HP when used.',
    category: 'item',
    deathsRequired: 15,
    icon: '"',
    color: '#55ffaa',
  },
  {
    id: 'item_ghost_lantern',
    name: 'Ghost Lantern',
    description: 'See 4 tiles further in darkness.',
    category: 'item',
    deathsRequired: 40,
    icon: '"',
    color: '#88ddff',
  },
  {
    id: 'item_soul_gem',
    name: 'Soul Gem',
    description: '+4 to all stats when equipped.',
    category: 'item',
    deathsRequired: 150,
    icon: '=',
    color: '#ff66dd',
  },

  // ─── ENEMIES (new monsters added to the pool) ───
  {
    id: 'enemy_bone_walker',
    name: 'Bone Walker',
    description: 'Risen from communal graves. Appears on floor 2+.',
    category: 'enemy',
    deathsRequired: 20,
    icon: 'B',
    color: '#e8d8b8',
  },
  {
    id: 'enemy_shade',
    name: 'Shade',
    description: 'A shadow born of many deaths. Floor 4+.',
    category: 'enemy',
    deathsRequired: 60,
    icon: 'H',
    color: '#6644aa',
  },
  {
    id: 'enemy_death_knight',
    name: 'Death Knight',
    description: 'Champion of the Necropolis. Floor 8+.',
    category: 'enemy',
    deathsRequired: 175,
    icon: 'K',
    color: '#cc2255',
  },
  {
    id: 'enemy_lich',
    name: 'Lich',
    description: 'Master of undeath. Floor 11+.',
    category: 'enemy',
    deathsRequired: 350,
    icon: 'L',
    color: '#aa00ff',
  },

  // ─── DUNGEONS (modifiers that change floor generation) ───
  {
    id: 'dungeon_catacombs',
    name: 'The Catacombs',
    description: 'Narrow tunnels with more monsters. Appears as floor variant.',
    category: 'dungeon',
    deathsRequired: 30,
    icon: '#',
    color: '#aa8855',
  },
  {
    id: 'dungeon_ossuary',
    name: 'The Ossuary',
    description: 'Bone-filled halls with extra loot but tougher foes.',
    category: 'dungeon',
    deathsRequired: 100,
    icon: '#',
    color: '#ddbb88',
  },
  {
    id: 'dungeon_void_pit',
    name: 'The Void Pit',
    description: 'A dark abyss. Reduced visibility, powerful enemies.',
    category: 'dungeon',
    deathsRequired: 300,
    icon: '#',
    color: '#4422aa',
  },

  // ─── CLASSES ───
  {
    id: 'class_necromancer',
    name: 'Necromancer',
    description: 'Draws power from the dead. Gains HP on kills.',
    category: 'class',
    deathsRequired: 25,
    icon: '@',
    color: '#aa44dd',
  },
  {
    id: 'class_revenant',
    name: 'Revenant',
    description: 'Came back from death. Starts with low HP but immense attack.',
    category: 'class',
    deathsRequired: 125,
    icon: '@',
    color: '#ff4444',
  },

  // ─── ZONES (entirely new areas that appear after certain floors) ───
  {
    id: 'zone_graveyard',
    name: 'The Graveyard',
    description: 'An open graveyard zone appears every 5 floors. More food, more undead.',
    category: 'zone',
    deathsRequired: 45,
    icon: '+',
    color: '#55aa55',
  },
  {
    id: 'zone_necropolis_depths',
    name: 'Necropolis Depths',
    description: 'The deep Necropolis. Appears after floor 10. Extreme danger, extreme rewards.',
    category: 'zone',
    deathsRequired: 225,
    icon: '+',
    color: '#cc33ff',
  },
  {
    id: 'zone_throne_of_bones',
    name: 'Throne of Bones',
    description: 'The final zone. A boss arena unlocked by massive sacrifice.',
    category: 'zone',
    deathsRequired: 500,
    icon: '+',
    color: '#ff3333',
  },
];

// ── Helper: get unlocked content by current death count ──

export function getUnlockedIds(communalDeaths: number): string[] {
  return NECROPOLIS_UNLOCKS
    .filter((u) => communalDeaths >= u.deathsRequired)
    .map((u) => u.id);
}

export function getNextUnlocks(communalDeaths: number, count = 3): NecropolisUnlock[] {
  return NECROPOLIS_UNLOCKS
    .filter((u) => communalDeaths < u.deathsRequired)
    .sort((a, b) => a.deathsRequired - b.deathsRequired)
    .slice(0, count);
}

export function isUnlocked(id: string, communalDeaths: number): boolean {
  const unlock = NECROPOLIS_UNLOCKS.find((u) => u.id === id);
  return unlock ? communalDeaths >= unlock.deathsRequired : false;
}

// ── Necropolis Monster Definitions ──

export function getNecropolisMonsters(communalDeaths: number): MonsterDef[] {
  const monsters: MonsterDef[] = [];

  if (isUnlocked('enemy_bone_walker', communalDeaths)) {
    monsters.push({
      name: 'Bone Walker',
      char: 'B',
      color: '#e8d8b8',
      stats: { hp: 10, maxHp: 10, attack: 5, defense: 2, speed: 6 },
      xpValue: 12,
      minFloor: 2,
      lootChance: 0.25,
    });
  }

  if (isUnlocked('enemy_shade', communalDeaths)) {
    monsters.push({
      name: 'Shade',
      char: 'H',
      color: '#6644aa',
      stats: { hp: 14, maxHp: 14, attack: 8, defense: 2, speed: 11 },
      xpValue: 28,
      minFloor: 4,
      lootChance: 0.35,
    });
  }

  if (isUnlocked('enemy_death_knight', communalDeaths)) {
    monsters.push({
      name: 'Death Knight',
      char: 'K',
      color: '#cc2255',
      stats: { hp: 35, maxHp: 35, attack: 14, defense: 8, speed: 6 },
      xpValue: 55,
      minFloor: 8,
      lootChance: 0.5,
    });
  }

  if (isUnlocked('enemy_lich', communalDeaths)) {
    monsters.push({
      name: 'Lich',
      char: 'L',
      color: '#aa00ff',
      stats: { hp: 50, maxHp: 50, attack: 20, defense: 8, speed: 8 },
      xpValue: 90,
      minFloor: 11,
      lootChance: 0.55,
    });
  }

  return monsters;
}

// ── Necropolis Weapon Templates ──

export function getNecropolisWeapons(communalDeaths: number): Omit<Item, 'id'>[] {
  const weapons: Omit<Item, 'id'>[] = [];

  if (isUnlocked('weapon_bone_club', communalDeaths)) {
    weapons.push({
      name: 'Bone Club',
      type: 'weapon',
      char: ')',
      color: '#e8d8b8',
      value: 8,
      equipSlot: 'weapon',
      statBonus: { attack: 3 },
      description: 'Forged from the fallen',
    });
  }

  if (isUnlocked('weapon_soul_reaper', communalDeaths)) {
    weapons.push({
      name: 'Soul Reaper',
      type: 'weapon',
      char: ')',
      color: '#cc44ff',
      value: 45,
      equipSlot: 'weapon',
      statBonus: { attack: 9 },
      description: 'Feeds on death energy',
    });
  }

  if (isUnlocked('weapon_death_scythe', communalDeaths)) {
    weapons.push({
      name: "Death's Scythe",
      type: 'weapon',
      char: ')',
      color: '#ff2222',
      value: 95,
      equipSlot: 'weapon',
      statBonus: { attack: 17 },
      description: 'The ultimate reaping tool',
    });
  }

  return weapons;
}

// ── Necropolis Armor Templates ──

export function getNecropolisArmor(communalDeaths: number): Omit<Item, 'id'>[] {
  const armor: Omit<Item, 'id'>[] = [];

  if (isUnlocked('armor_bone_mail', communalDeaths)) {
    armor.push({
      name: 'Bone Mail',
      type: 'armor',
      char: '[',
      color: '#d8c8a8',
      value: 12,
      equipSlot: 'armor',
      statBonus: { defense: 3 },
      description: 'Woven from ancestral bones',
    });
  }

  if (isUnlocked('armor_spectral_shroud', communalDeaths)) {
    armor.push({
      name: 'Spectral Shroud',
      type: 'armor',
      char: '[',
      color: '#aaaaff',
      value: 35,
      equipSlot: 'armor',
      statBonus: { defense: 6 },
      description: 'Ghosts protect you',
    });
  }

  if (isUnlocked('armor_necro_plate', communalDeaths)) {
    armor.push({
      name: 'Necropolis Plate',
      type: 'armor',
      char: '[',
      color: '#8822cc',
      value: 75,
      equipSlot: 'armor',
      statBonus: { defense: 13 },
      description: 'Forged in mass sacrifice',
    });
  }

  return armor;
}

// ── Necropolis Item Templates (consumables / accessories) ──

export function getNecropolisItems(communalDeaths: number): Omit<Item, 'id'>[] {
  const items: Omit<Item, 'id'>[] = [];

  if (isUnlocked('item_death_ward', communalDeaths)) {
    items.push({
      name: 'Death Ward',
      type: 'potion',
      char: '"',
      color: '#55ffaa',
      value: 20,
      description: 'Restores 20 HP',
    });
  }

  if (isUnlocked('item_ghost_lantern', communalDeaths)) {
    items.push({
      name: 'Ghost Lantern',
      type: 'amulet',
      char: '"',
      color: '#88ddff',
      value: 40,
      equipSlot: 'amulet',
      statBonus: { speed: 2 },
      description: 'See further in darkness',
    });
  }

  if (isUnlocked('item_soul_gem', communalDeaths)) {
    items.push({
      name: 'Soul Gem',
      type: 'ring',
      char: '=',
      color: '#ff66dd',
      value: 50,
      equipSlot: 'ring',
      statBonus: { attack: 4, defense: 4, speed: 4 },
      description: '+4 to all stats',
    });
  }

  return items;
}

// ── Necropolis Class Definitions ──

export function getNecropolisClasses(communalDeaths: number): ClassDef[] {
  const classes: ClassDef[] = [];

  if (isUnlocked('class_necromancer', communalDeaths)) {
    classes.push({
      id: 'necromancer' as PlayerClass,
      name: 'Necromancer',
      char: '@',
      color: '#aa44dd',
      description: 'Draws power from the dead. Gains HP on kills.',
      baseStats: { hp: 22, maxHp: 22, attack: 7, defense: 1, speed: 9 },
      levelBonusHp: 4,
      levelBonusAtk: 2,
      levelBonusDef: 1,
      requiresBestFloor: 0,
      passives: [
        { name: 'Life Drain', description: 'Heal 3 HP on every kill', unlockLevel: 1 },
        { name: 'Death Aura', description: 'Nearby enemies take 1 damage per turn', unlockLevel: 3 },
        { name: 'Undying Will', description: 'Survive a fatal blow once per floor with 1 HP', unlockLevel: 6 },
      ],
    });
  }

  if (isUnlocked('class_revenant', communalDeaths)) {
    classes.push({
      id: 'revenant' as PlayerClass,
      name: 'Revenant',
      char: '@',
      color: '#ff4444',
      description: 'Came back from death. Low HP, immense power.',
      baseStats: { hp: 15, maxHp: 15, attack: 12, defense: 2, speed: 10 },
      levelBonusHp: 2,
      levelBonusAtk: 3,
      levelBonusDef: 1,
      requiresBestFloor: 0,
      passives: [
        { name: 'Deathless Fury', description: '+100% damage when below 20% HP', unlockLevel: 1 },
        { name: 'Soul Siphon', description: '10% chance to fully restore HP on kill', unlockLevel: 3 },
        { name: 'Beyond Death', description: 'Start each floor with a free revive', unlockLevel: 6 },
      ],
    });
  }

  return classes;
}

// ── Category labels and colors ──

export const CATEGORY_INFO: Record<UnlockCategory, { label: string; color: string }> = {
  item: { label: 'Items', color: '#55ffaa' },
  enemy: { label: 'Enemies', color: '#ff6644' },
  dungeon: { label: 'Dungeons', color: '#aa8855' },
  class: { label: 'Classes', color: '#aa44dd' },
  weapon: { label: 'Weapons', color: '#ffe44d' },
  armor: { label: 'Armor', color: '#88aaff' },
  zone: { label: 'Zones', color: '#55cc55' },
};
