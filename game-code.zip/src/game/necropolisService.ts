import RundotGameAPI from '@series-inc/rundot-game-sdk/api';
import type { NecropolisState } from './necropolis';
import { createDefaultNecropolisState, getUnlockedIds } from './necropolis';

const NECROPOLIS_GAME_TYPE = 'necropolis';
const NECROPOLIS_ROOM_NAME = 'The Necropolis';
const LOCAL_CACHE_KEY = 'necropolis_state';

// We use a single shared multiplayer room for all players.
// Deaths are reported as moves, and the room's gameSpecificState
// tracks the communal death count.

let currentRoom: any = null;
let unsubscribeFn: (() => void) | null = null;
let cachedState: NecropolisState = createDefaultNecropolisState();
let stateListeners: Array<(state: NecropolisState) => void> = [];

function notifyListeners() {
  for (const listener of stateListeners) {
    listener(cachedState);
  }
}

export function onNecropolisStateChange(listener: (state: NecropolisState) => void): () => void {
  stateListeners.push(listener);
  return () => {
    stateListeners = stateListeners.filter((l) => l !== listener);
  };
}

export function getNecropolisState(): NecropolisState {
  return cachedState;
}

/** Load cached state from local storage */
async function loadLocalCache(): Promise<NecropolisState> {
  try {
    const raw = await RundotGameAPI.appStorage.getItem(LOCAL_CACHE_KEY);
    if (raw) {
      return JSON.parse(raw) as NecropolisState;
    }
  } catch { /* first time */ }
  return createDefaultNecropolisState();
}

/** Save state to local storage for offline access */
async function saveLocalCache(state: NecropolisState) {
  try {
    await RundotGameAPI.appStorage.setItem(LOCAL_CACHE_KEY, JSON.stringify(state));
  } catch { /* best effort */ }
}

/** Parse room data into NecropolisState */
function parseRoomData(roomData: any): NecropolisState {
  const gameState = roomData?.customMetadata?.rules?.gameState;
  const communalDeaths = gameState?.gameSpecificState?.communalDeaths ?? 0;
  return {
    communalDeaths,
    unlockedIds: getUnlockedIds(communalDeaths),
    lastUpdated: Date.now(),
  };
}

/** Connect to or create the Necropolis room */
export async function connectToNecropolis(): Promise<NecropolisState> {
  // Load local cache first for instant display
  cachedState = await loadLocalCache();
  notifyListeners();

  try {
    // Join or create the shared necropolis room
    const result = await RundotGameAPI.rooms.joinOrCreateRoomAsync({
      matchCriteria: { gameType: NECROPOLIS_GAME_TYPE, hasSpace: true },
      createOptions: {
        maxPlayers: 1000,
        gameType: NECROPOLIS_GAME_TYPE,
        name: NECROPOLIS_ROOM_NAME,
        isPrivate: false,
      },
    });

    currentRoom = result.room;

    // Get initial room data
    const roomData = await RundotGameAPI.rooms.getRoomDataAsync(currentRoom);
    cachedState = parseRoomData(roomData);
    await saveLocalCache(cachedState);
    notifyListeners();

    // Subscribe to real-time updates
    const unsub = await RundotGameAPI.rooms.subscribeAsync(currentRoom, {
      onData(event: any) {
        cachedState = parseRoomData(event.roomData);
        saveLocalCache(cachedState);
        notifyListeners();
      },
      onGameEvents(event: any) {
        // When moves are validated, update state from the event data
        if (event.proposedMoveData?.gameSpecificState?.communalDeaths != null) {
          const deaths = event.proposedMoveData.gameSpecificState.communalDeaths;
          cachedState = {
            communalDeaths: deaths,
            unlockedIds: getUnlockedIds(deaths),
            lastUpdated: Date.now(),
          };
          saveLocalCache(cachedState);
          notifyListeners();
        }
      },
    });

    unsubscribeFn = unsub;

    return cachedState;
  } catch {
    // If multiplayer fails, use local-only mode
    return cachedState;
  }
}

/** Report a player death to the Necropolis */
export async function reportDeath(): Promise<void> {
  // Always increment local cache immediately for responsiveness
  cachedState = {
    communalDeaths: cachedState.communalDeaths + 1,
    unlockedIds: getUnlockedIds(cachedState.communalDeaths + 1),
    lastUpdated: Date.now(),
  };
  await saveLocalCache(cachedState);
  notifyListeners();

  if (!currentRoom) {
    // Not connected to multiplayer, just local tracking
    return;
  }

  try {
    await RundotGameAPI.rooms.proposeMoveAsync(currentRoom, {
      moveType: 'death_report',
      gameSpecificState: {
        communalDeaths: cachedState.communalDeaths,
        reportedAt: Date.now(),
      },
    });
  } catch {
    // Best effort - local state already updated
  }
}

/** Disconnect from the Necropolis room */
export async function disconnectFromNecropolis(): Promise<void> {
  if (unsubscribeFn) {
    unsubscribeFn();
    unsubscribeFn = null;
  }
  if (currentRoom) {
    try {
      await RundotGameAPI.rooms.leaveRoomAsync(currentRoom);
    } catch { /* best effort */ }
    currentRoom = null;
  }
}
